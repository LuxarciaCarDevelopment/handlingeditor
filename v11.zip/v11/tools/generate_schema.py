"""Single source for Lua validation and NUI metadata. No default physics values."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
# Field | group | English explanation | Turkish explanation | constraint
rows = '''fMass|mass|Vehicle mass in kilograms; affects momentum and estimated power.|Kilogram cinsinden kütle; momentumu ve tahmini gücü etkiler.|positive
fInitialDragCoeff|aero|Aerodynamic drag coefficient; increasing it resists high speed.|Hava direnci katsayısı; artışı yüksek hıza karşı direnci artırır.|nonnegative
fPercentSubmerged|mass|Submersion percentage used by buoyancy behavior.|Yüzme davranışında kullanılan batma yüzdesi.|percent
vecCentreOfMassOffset|mass|Local center of mass offset in metres; x right, y forward, z up.|Yerel ağırlık merkezi metre cinsinden; x sağ, y ileri, z yukarı.|vector
vecInertiaMultiplier|mass|Rotational inertia multipliers for the three local axes.|Üç yerel eksen için dönme ataleti çarpanları.|positiveVector
fDriveBiasFront|engine|Front drive share: 0 rear drive, 1 front drive; intermediate native values must be 0.1–0.9.|Ön tahrik payı: 0 arkadan, 1 önden; ara yerel değerler 0,1–0,9 olmalıdır.|driveBias
nInitialDriveGears|transmission|Forward gear count; the FiveM handling setter caps it at 7; road verification is required.|İleri vites sayısı; FiveM handling setter en fazla 7 uygular; yol testi gerekir.|gears
fInitialDriveForce|engine|Drive force multiplier; influences acceleration, not measured horsepower.|Tahrik kuvveti çarpanı; ivmeyi etkiler, ölçülmüş beygir gücü değildir.|nonnegative
fDriveInertia|engine|Engine rotational response; higher values change rev response.|Motorun devir tepkisini belirleyen atalet katsayısı.|positive
fClutchChangeRateScaleUpShift|transmission|Upshift clutch change rate multiplier.|Vites yükseltirken debriyaj geçiş hızı çarpanı.|positive
fClutchChangeRateScaleDownShift|transmission|Downshift clutch change rate multiplier.|Vites düşürürken debriyaj geçiş hızı çarpanı.|positive
fInitialDriveMaxFlatVel|transmission|Engine gearing speed reference; not a guaranteed road top speed.|Aktarma hız referansı; gerçek azami yol hızı garantisi değildir.|positive
fBrakeForce|brakes|Service brake force multiplier; tyre grip still limits braking.|Servis freni kuvveti çarpanı; lastik tutuşu frenlemeyi sınırlar.|nonnegative
fBrakeBiasFront|brakes|Front brake share between zero and one.|Sıfır ile bir arasında ön fren payı.|bias
fHandBrakeForce|brakes|Handbrake force multiplier.|El freni kuvveti çarpanı.|nonnegative
fSteeringLock|steering|Maximum steering lock in degrees; does not represent current wheel angle.|Derece cinsinden azami direksiyon açısı; anlık teker açısı değildir.|positive
fTractionCurveMax|traction|Peak traction curve coefficient.|Tutuş eğrisinin tepe katsayısı.|positive
fTractionCurveMin|traction|Sliding traction curve coefficient.|Kayma sırasındaki tutuş eğrisi katsayısı.|positive
fTractionCurveLateral|traction|Lateral traction curve angle in degrees.|Derece cinsinden yanal tutuş eğrisi açısı.|positive
fTractionSpringDeltaMax|traction|Suspension travel contribution to traction response.|Süspansiyon hareketinin tutuş tepkisine katkısı.|positive
fLowSpeedTractionLossMult|traction|Low speed traction loss multiplier.|Düşük hızda tutuş kaybı çarpanı.|nonnegative
fCamberStiffnesss|traction|Camber stiffness coefficient; native field intentionally has three s letters.|Kamber sertliği katsayısı; yerel alan adında üç s harfi vardır.|finite
fTractionBiasFront|traction|Front traction distribution fraction.|Ön aks tutuş dağılımı oranı.|bias
fTractionLossMult|traction|Traction loss multiplier across surfaces.|Zeminler üzerindeki tutuş kaybı çarpanı.|nonnegative
fSuspensionForce|suspension|Spring force multiplier.|Yay kuvveti çarpanı.|positive
fSuspensionCompDamp|suspension|Compression damping coefficient.|Sıkışma sönümleme katsayısı.|nonnegative
fSuspensionReboundDamp|suspension|Rebound damping coefficient.|Geri açılma sönümleme katsayısı.|nonnegative
fSuspensionUpperLimit|suspension|Upper suspension travel limit in metres.|Metre cinsinden üst süspansiyon hareket sınırı.|finite
fSuspensionLowerLimit|suspension|Lower suspension travel limit in metres.|Metre cinsinden alt süspansiyon hareket sınırı.|finite
fSuspensionRaise|suspension|Suspension ride height offset in metres.|Metre cinsinden süspansiyon sürüş yüksekliği farkı.|finite
fSuspensionBiasFront|suspension|Front spring distribution fraction.|Ön yay dağılımı oranı.|bias
fAntiRollBarForce|suspension|Anti-roll force multiplier; higher is not always better.|Viraj demiri kuvvet çarpanı; yüksek değer her zaman daha iyi değildir.|nonnegative
fAntiRollBarBiasFront|suspension|Front anti-roll distribution fraction.|Ön viraj demiri dağılımı oranı.|bias
fRollCentreHeightFront|mass|Front roll center height in metres; not static axle weight.|Metre cinsinden ön yatma merkezi yüksekliği; statik aks ağırlığı değildir.|finite
fRollCentreHeightRear|mass|Rear roll center height in metres.|Metre cinsinden arka yatma merkezi yüksekliği.|finite
fCollisionDamageMult|damage|Collision damage multiplier.|Çarpışma hasarı çarpanı.|nonnegative
fWeaponDamageMult|damage|Weapon damage multiplier.|Silah hasarı çarpanı.|nonnegative
fDeformationDamageMult|damage|Body deformation multiplier.|Gövde deformasyonu çarpanı.|nonnegative
fEngineDamageMult|damage|Engine damage multiplier.|Motor hasarı çarpanı.|nonnegative
fPetrolTankVolume|damage|Fuel tank capacity metadata; fuel resources may override behavior.|Yakıt deposu kapasitesi; yakıt kaynakları davranışı değiştirebilir.|nonnegative
fOilVolume|damage|Oil volume metadata; physical effect needs in-game verification.|Yağ hacmi verisi; fiziksel etkisi oyun içi doğrulama gerektirir.|nonnegative
fSeatOffsetDistX|mass|Seat position offset on the local x axis.|Yerel x eksenindeki koltuk konumu farkı.|finite
fSeatOffsetDistY|mass|Seat position offset on the local y axis.|Yerel y eksenindeki koltuk konumu farkı.|finite
fSeatOffsetDistZ|mass|Seat position offset on the local z axis.|Yerel z eksenindeki koltuk konumu farkı.|finite
fDownforceModifier|aero|Downforce modifier; effects depend on the vehicle and game build.|Yere basma çarpanı; etkisi araç ve oyun sürümüne bağlıdır.|nonnegative
nMonetaryValue|damage|Vehicle monetary value metadata; does not change driving physics.|Araç parasal değer verisi; sürüş fiziğini değiştirmez.|integer'''
schema=[]
for row in rows.splitlines():
    field,group,en,tr,rule=row.split('|')
    schema.append(dict(field=field,group=group,en=en,tr=tr,rule=rule,type='vector' if 'Vector' in rule or rule=='vector' else 'int' if rule in ('gears','integer') else 'float'))
assert len(schema)==46
(ROOT/'web/schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2),encoding='utf-8')
lua=['-- Generated by tools/generate_schema.py; do not edit independently.','HandlingSchema = {']
for f in schema:
    lua.append('    { field = %s, type = %s, rule = %s },' % tuple(json.dumps(f[k]) for k in ('field','type','rule')))
lua.append('}')
lua.append('''HandlingFields = {}
for _, field in ipairs(HandlingSchema) do HandlingFields[field.field] = field end
function HandlingFinite(n)
    return type(n) == 'number' and n == n and math.abs(n) < 3.4028234e38
end
function ValidateHandling(values, partial)
    if type(values) ~= 'table' then return nil, 'invalidValues' end
    local result, count = {}, 0
    for name, value in pairs(values) do
        local spec = HandlingFields[name]
        if not spec then return nil, 'unknownField:' .. tostring(name) end
        count = count + 1
        if spec.type == 'vector' then
            if type(value) ~= 'table' then return nil, 'invalidVector:' .. name end
            for key in pairs(value) do if key ~= 'x' and key ~= 'y' and key ~= 'z' then return nil, 'invalidVector:' .. name end end
            for _, axis in ipairs({'x','y','z'}) do
                if not HandlingFinite(value[axis]) or (spec.rule == 'positiveVector' and value[axis] <= 0) then return nil, 'invalidVector:' .. name end
            end
            result[name] = { x=value.x, y=value.y, z=value.z }
        else
            if not HandlingFinite(value) then return nil, 'invalidNumber:' .. name end
            local r = spec.rule
            if spec.type == 'int' and (value % 1 ~= 0 or value < 0 or value > 2147483647) then return nil, 'invalidInteger:' .. name end
            if (r == 'positive' and value <= 0) or (r == 'nonnegative' and value < 0)
                or (r == 'bias' and (value < 0 or value > 1)) or (r == 'percent' and (value <= 0 or value > 2550))
                or (r == 'driveBias' and not (value == 0 or value == 1 or (value >= 0.1 and value <= 0.9)))
                or (r == 'gears' and (value % 1 ~= 0 or value < 1 or value > 255)) then return nil, 'invalidRange:' .. name end
            result[name] = value
        end
    end
    if count == 0 or (not partial and count ~= #HandlingSchema) then return nil, 'invalidCount' end
    return result
end''')
lua.append('''function ValidateHandlingChanges(values)
    local valid,err=ValidateHandling(values,true)
    if not valid then return nil,err end
    if valid.nInitialDriveGears and valid.nInitialDriveGears>7 then return nil,'invalidRange:nInitialDriveGears' end
    return valid
end''')
(ROOT/'shared/schema.lua').write_text('\n'.join(lua)+'\n',encoding='utf-8')
matrix=['# 46-field catalog and native verification matrix','',
    'Generated from the shared catalog. Every row has passed mocked typed read/write/restore checks. Actual native readback and physical behavior remain pending real-server verification for every row.','',
    'The two vector fields expose x/y/z; 46 counts native fields, not scalar inputs. Native identifiers and their bilingual explanations are in web/schema.json.','',
    'Validation: finite = finite float32-representable; positive >0; nonnegative ≥0; bias 0–1; driveBias exactly 0, 0.1–0.9, or 1; percent >0–100; integer nonnegative signed-32-bit range; vector exactly finite x/y/z; positiveVector additionally requires positive components. Gear snapshots accept uint8 counts 1–255 to preserve native reads, but runtime changes are limited to 1–7 by the official setter. Captured stock counts above 7 remain readable/exportable and cannot be edited through this setter.','',
    'For each field record: original → change → readback → physical observation → undo → redo → reset → XML → reimport. Metadata such as monetary value is not a physics control. A successful readback is not evidence of a changed physical effect.','',
    '| # | Field | Native type | Validation | Explanation | In-game verified |',
    '|---:|---|---|---|---|---|']
for index,spec in enumerate(schema,1):
    matrix.append(f"| {index} | `{spec['field']}` | {spec['type']} | {spec['rule']} | {spec['en']} | [ ] |")
(ROOT/'docs/PARAMETERS.md').write_text('\n'.join(matrix)+'\n',encoding='utf-8')
