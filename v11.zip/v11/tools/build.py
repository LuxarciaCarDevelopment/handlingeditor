"""Package runtime + technical docs, excluding tools, fixtures and dependencies."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
files=[ROOT/'fxmanifest.lua',ROOT/'config.lua',ROOT/'README.md']
for folder in ('client','server','shared','web','docs'):
    files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file())
files.sort()
out=ROOT/'dist';out.mkdir(exist_ok=True)
manifest={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(out/'luxarcia_handling_v2.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p in files:archive.write(p,'luxarcia_handling_v2/'+p.relative_to(ROOT).as_posix())
    archive.writestr('luxarcia_handling_v2/SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out/'luxarcia_handling_v2.zip') as archive:
    assert archive.testzip() is None
    assert not any('/tests/' in p or '/node_modules/' in p for p in archive.namelist())
print(f'Packaged {len(files)} files: {out / "luxarcia_handling_v2.zip"}')
