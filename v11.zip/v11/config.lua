Config = Config or {}
-- Server-only; add your own Discord IDs as strings. Empty lists deny everyone.
Config.DiscordWhitelist = Config.DiscordWhitelist or {}
Config.AllowedDiscordIDs = Config.AllowedDiscordIDs or {}
Config.HistoryLimit = Config.HistoryLimit or 100
Config.MaxSavedEntries = Config.MaxSavedEntries or 100
Config.MaxStorageBytes = Config.MaxStorageBytes or 2000000
Config.EnablePresets = Config.EnablePresets ~= false
Config.EnableAI = Config.EnableAI or false -- Legacy option; convar is authoritative.
Config.AIModel = Config.AIModel or 'openai/gpt-oss-120b'
Config.AICooldown = Config.AICooldown or 15000
Config.AITimeout = Config.AITimeout or 20000
return Config
