local Config = require 'config'

local function GetPlayerDiscordIdentifier(playerId)
    if not playerId or playerId == 0 then
        return nil
    end

    local identifiers = GetPlayerIdentifiers(playerId)
    if not identifiers then
        return nil
    end

    for _, identifier in ipairs(identifiers) do
        if type(identifier) == 'string' and identifier:sub(1, 8) == 'discord:' then
            return identifier
        end
    end

    return nil
end

local function CanPlayerOpenHandlingEditor(playerId)
    local discordId = GetPlayerDiscordIdentifier(playerId)
    if not discordId then
        return false, 'Your FiveM account does not expose a Discord identifier. Please connect Discord to use /handling.'
    end

    local allowed = Config and Config.DiscordWhitelist and Config.DiscordWhitelist[discordId] == true
    for _, id in ipairs(Config.AllowedDiscordIDs or {}) do
        if type(id) == 'string' and 'discord:' .. id == discordId then allowed = true end
    end
    if not allowed then
        return false, 'You are not whitelisted to use the Luxarcia Handling Editor.'
    end

    return true
end

return {
    CanPlayerOpenHandlingEditor = CanPlayerOpenHandlingEditor
}
