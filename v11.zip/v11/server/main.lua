local permissions = require 'server.permissions'
local aiRequests = {}
local aiLastRequest = {}
local playerSessions = {}
local requestWindows = {}
local function aiEnabled() return GetConvar('luxarcia_ai_enabled', 'false') == 'true' end

local function sendReply(playerId, requestId, payload)
    TriggerClientEvent('luxarcia:reply', playerId, requestId, payload)
end

local function sendLargeReply(playerId, requestId, payload)
    if TriggerLatentClientEvent then
        TriggerLatentClientEvent('luxarcia:reply', playerId, 500000, requestId, payload)
    else
        sendReply(playerId, requestId, payload)
    end
end

local function getLibraryKey(playerId)
    local ids = GetPlayerIdentifiers(playerId)
    if not ids then
        return nil
    end

    for _, identifier in ipairs(ids) do
        if type(identifier) == 'string' and identifier:sub(1, 8) == 'discord:' then
            return 'luxarcia:v2:' .. identifier
        end
    end

    return 'luxarcia:v2:' .. tostring(playerId)
end

local function finiteNumber(value)
    return type(value) == 'number' and value == value and value ~= math.huge and value ~= -math.huge
end

local function arrayLength(value)
    if type(value) ~= 'table' then return nil end
    local count, maximum = 0, 0
    for key in pairs(value) do
        if type(key) ~= 'number' or key < 1 or key % 1 ~= 0 then return nil end
        count = count + 1
        maximum = math.max(maximum, key)
    end
    if count ~= maximum then return nil end
    return count
end

local function onlyKeys(value, allowed)
    if type(value) ~= 'table' then return false end
    for key in pairs(value) do
        if type(key) ~= 'string' or not allowed[key] then return false end
    end
    return true
end

local function validModel(value)
    return value == nil or (type(value) == 'string' and #value <= 120) or finiteNumber(value)
end

local function validSnapshot(value)
    return type(value) == 'table' and ValidateHandling(value, false) ~= nil
end

local function validHistory(history)
    local count = arrayLength(history)
    if not count or count > (Config.HistoryLimit or 100) then return false end
    for _, entry in ipairs(history) do
        if not onlyKeys(entry, { label=true, time=true, model=true, values=true })
            or type(entry.label) ~= 'string' or #entry.label > 120
            or not finiteNumber(entry.time) or not validModel(entry.model)
            or not validSnapshot(entry.values) then return false end
    end
    return true
end

local function validPreset(entry, ids)
    if not onlyKeys(entry, { id=true, name=true, model=true, vehicleName=true, style=true, values=true, created=true })
        or type(entry.id) ~= 'string' or #entry.id == 0 or #entry.id > 120
        or type(entry.name) ~= 'string' or #entry.name == 0 or #entry.name > 120
        or not validModel(entry.model)
        or (entry.vehicleName ~= nil and (type(entry.vehicleName) ~= 'string' or #entry.vehicleName > 120))
        or (entry.style ~= nil and (type(entry.style) ~= 'string' or #entry.style > 40))
        or (entry.created ~= nil and type(entry.created) ~= 'string')
        or not validSnapshot(entry.values) or ids[entry.id] then return false end
    ids[entry.id] = true
    return true
end

local function validResultEntry(entry)
    if not onlyKeys(entry, { kind=true, seconds=true, metres=true, maxSpeed=true, measured=true, values=true }) then return false end
    if entry.kind ~= nil and type(entry.kind) ~= 'string' then return false end
    for _, key in ipairs({ 'seconds', 'metres', 'maxSpeed' }) do
        if entry[key] ~= nil and (not finiteNumber(entry[key]) or entry[key] < 0) then return false end
    end
    if entry.measured ~= nil and type(entry.measured) ~= 'boolean' then return false end
    if entry.values == nil or not validSnapshot(entry.values) then return false end
    return entry.seconds ~= nil
end

local function validResults(results)
    if type(results) ~= 'table' then return false end
    local known = { maxSpeed=true, peakAcceleration=true, peakBraking=true, accel100=true, accel200=true, brake=true, drag=true }
    for key, value in pairs(results) do
        if not known[key] then return false end
        if key == 'maxSpeed' or key == 'peakAcceleration' or key == 'peakBraking' then
            if not finiteNumber(value) or value < 0 then return false end
        elseif not validResultEntry(value) then
            return false
        end
    end
    return true
end

local function validSample(sample)
    if not onlyKeys(sample, { time=true, speed=true, x=true, y=true, z=true, distance=true, acceleration=true, rpm=true,
        longG=true, latG=true, yaw=true, steering=true, roll=true, pitch=true, invalid=true, entityInvalid=true,
        vx=true,vy=true,vz=true,gear=true,engineHealth=true,bodyHealth=true }) then return false end
    for _, key in ipairs({ 'time', 'speed', 'x', 'y', 'z', 'distance', 'acceleration', 'rpm' }) do
        if not finiteNumber(sample[key]) then return false end
    end
    for _, key in ipairs({ 'longG', 'latG', 'yaw', 'steering', 'roll', 'pitch', 'vx','vy','vz','gear','engineHealth','bodyHealth' }) do
        if sample[key] ~= nil and not finiteNumber(sample[key]) then return false end
    end
    for _, key in ipairs({ 'invalid', 'entityInvalid' }) do
        if sample[key] ~= nil and type(sample[key]) ~= 'boolean' then return false end
    end
    return true
end

local function validRun(entry, ids)
    if not onlyKeys(entry, { id=true, name=true, model=true, vehicleName=true, style=true, values=true, created=true,
        samples=true, results=true, setupChanges=true, laps=true, checkpoints=true })
        or type(entry.id) ~= 'string' or #entry.id == 0 or #entry.id > 120
        or type(entry.name) ~= 'string' or #entry.name == 0 or #entry.name > 120
        or not validModel(entry.model) or not validSnapshot(entry.values) or ids[entry.id] then return false end
    local sampleCount = arrayLength(entry.samples)
    if not sampleCount or sampleCount > 1200 or not validResults(entry.results) then return false end
    local previousTime = -math.huge
    for _, sample in ipairs(entry.samples) do
        if not validSample(sample) or sample.time <= previousTime then return false end
        previousTime = sample.time
    end
    if entry.setupChanges ~= nil then
        local count = arrayLength(entry.setupChanges)
        if not count or count > 100 then return false end
        for _, change in ipairs(entry.setupChanges) do
            if not onlyKeys(change, { time=true, values=true }) or not finiteNumber(change.time) or not validSnapshot(change.values) then return false end
        end
    end
    if entry.laps ~= nil then
        local count = arrayLength(entry.laps)
        if not count then return false end
        for _, lap in ipairs(entry.laps) do
            if not onlyKeys(lap, { seconds=true, invalid=true }) or not finiteNumber(lap.seconds) or lap.seconds < 0
                or (lap.invalid ~= nil and type(lap.invalid) ~= 'boolean') then return false end
        end
    end
    if entry.checkpoints ~= nil then
        local count = arrayLength(entry.checkpoints)
        if not count or count > 64 then return false end
        for _, checkpoint in ipairs(entry.checkpoints) do
            if not onlyKeys(checkpoint, { x=true, y=true, z=true, radius=true })
                or not finiteNumber(checkpoint.x) or not finiteNumber(checkpoint.y) or not finiteNumber(checkpoint.z)
                or (checkpoint.radius ~= nil and (not finiteNumber(checkpoint.radius) or checkpoint.radius <= 0)) then return false end
        end
    end
    ids[entry.id] = true
    return true
end

local function validateLibrary(data)
    if not onlyKeys(data, { version=true, presets=true, backups=true, reports=true, runs=true, feedback=true, history=true })
        or data.version ~= 2 then return false, 'invalidLibrary' end

    local ids = {}
    local collections = { 'presets', 'backups', 'reports', 'runs', 'feedback', 'history' }
    for _, collection in ipairs(collections) do
        local count = arrayLength(data[collection])
        if not count or count > (Config.MaxSavedEntries or 100) then return false, 'invalidLibrary' end
    end
    for _, collection in ipairs({ 'presets', 'backups' }) do
        for _, entry in ipairs(data[collection]) do
            if not validPreset(entry, ids) then return false, 'invalidPreset' end
        end
    end
    for _, entry in ipairs(data.runs) do
        if not validRun(entry, ids) then return false, 'invalidRun' end
    end
    for _, entry in ipairs(data.reports) do
        if not onlyKeys(entry, { id=true, name=true, model=true, vehicleName=true, original=true, values=true, profile=true,
            diagnostics=true, history=true, recordedResults=true, savedResults=true, changes=true, notes=true,
            aiExplanation=true, limitations=true, created=true, version=true })
            or type(entry.id) ~= 'string' or type(entry.name) ~= 'string' or not validModel(entry.model)
            or not validSnapshot(entry.original) or not validSnapshot(entry.values) or ids[entry.id] then return false, 'invalidReport' end
        if entry.history ~= nil and not validHistory(entry.history) then return false, 'invalidReport' end
        if entry.recordedResults ~= nil and not validResults(entry.recordedResults) then return false, 'invalidReport' end
        if entry.savedResults ~= nil then
            local count = arrayLength(entry.savedResults)
            if not count then return false, 'invalidReport' end
            for _, saved in ipairs(entry.savedResults) do
                if not onlyKeys(saved, { name=true, results=true }) or type(saved.name) ~= 'string' or not validResults(saved.results) then return false, 'invalidReport' end
            end
        end
        ids[entry.id] = true
    end
    for _, entry in ipairs(data.feedback) do
        if not onlyKeys(entry, { id=true, name=true, model=true, style=true, vote=true, values=true })
            or type(entry.id) ~= 'string' or type(entry.name) ~= 'string' or not validModel(entry.model)
            or type(entry.style) ~= 'string' or (entry.vote ~= 1 and entry.vote ~= -1)
            or not validSnapshot(entry.values) or ids[entry.id] then return false, 'invalidFeedback' end
        ids[entry.id] = true
    end
    if not validHistory(data.history) then return false, 'invalidHistory' end
    return true
end

local function finishAiRequest(playerId, session, requestId, payload)
    local pending = aiRequests[playerId]
    if not pending or pending.session ~= session or pending.finished then return end
    pending.finished = true
    aiRequests[playerId] = nil
    if (playerSessions[playerId] or 0) == session then
        sendReply(playerId, requestId, payload)
    end
end

local function handleAiRequest(playerId, requestId, request)
    if not aiEnabled() then
        sendReply(playerId, requestId, { ok = false, error = 'aiDisabled' })
        return
    end
    if aiRequests[playerId] then
        sendReply(playerId, requestId, { ok = false, error = 'busy' })
        return
    end
    if (aiLastRequest[playerId] and GetGameTimer() - aiLastRequest[playerId] < math.max(1000,Config.AICooldown or 15000)) then
        sendReply(playerId, requestId, { ok = false, error = 'rateLimit' })
        return
    end

    local prompt = request.prompt
    if type(prompt) ~= 'string' or #prompt == 0 or #prompt > 4000 then
        sendReply(playerId, requestId, { ok = false, error = 'invalidValues' })
        return
    end
    local values, validationError = ValidateHandling(request.values or {}, true)
    if not values then
        sendReply(playerId, requestId, { ok = false, error = validationError or 'invalidValues' })
        return
    end
    local apiKey = GetConvar('luxarcia_groq_api_key', '')
    if type(apiKey) ~= 'string' or apiKey == '' then
        sendReply(playerId, requestId, { ok = false, error = 'aiUnavailable' })
        return
    end

    local session = playerSessions[playerId] or 0
    local pending = { session = session, finished = false }
    aiRequests[playerId] = pending
    aiLastRequest[playerId] = GetGameTimer()
    local timeoutMs = math.min(Config.AITimeout or 20000, 20000)

    SetTimeout(timeoutMs, function()
        finishAiRequest(playerId, session, requestId, { ok = false, error = 'aiTimeout' })
    end)

    local language = request.language == 'tr' and 'tr' or 'en'
    local context = type(request.context) == 'string' and request.context:sub(1, 12000) or ''
    local body = {
        model = Config.AIModel or 'openai/gpt-oss-120b',
        temperature = 0.2,
        response_format = { type = 'json_object' },
        messages = {
            { role = 'system', content = 'Return JSON with string explanation and object changes. Only suggest validated vehicle handling fields. Language: ' .. language },
            { role = 'user', content = json.encode({ prompt = prompt, values = values, context = context }) },
        },
    }
    local encodeOk, encoded = pcall(json.encode, body)
    if not encodeOk or type(encoded) ~= 'string' then
        finishAiRequest(playerId, session, requestId, { ok = false, error = 'aiInvalid' })
        return
    end

    PerformHttpRequest('https://api.groq.com/openai/v1/chat/completions', function(status, responseBody)
        if not aiRequests[playerId] or aiRequests[playerId] ~= pending or pending.finished then return end
        if type(status)~='number' or status < 200 or status >= 300 or type(responseBody) ~= 'string' or #responseBody>100000 then
            finishAiRequest(playerId, session, requestId, { ok = false, error = 'aiUnavailable' })
            return
        end

        local responseOk, response = pcall(json.decode, responseBody)
        local choice = responseOk and type(response) == 'table' and type(response.choices) == 'table' and response.choices[1] or nil
        local message = type(choice) == 'table' and choice.message or nil
        local content = type(message) == 'table' and message.content or nil
        if type(content) ~= 'string' then
            finishAiRequest(playerId, session, requestId, { ok = false, error = 'aiInvalid' })
            return
        end

        local contentOk, result = pcall(json.decode, content)
        if not contentOk or type(result) ~= 'table' or not onlyKeys(result, { explanation = true, changes = true })
            or type(result.explanation) ~= 'string' or #result.explanation > 4000 or type(result.changes) ~= 'table' then
            finishAiRequest(playerId, session, requestId, { ok = false, error = 'aiInvalid' })
            return
        end

        local validatedChanges = {}
        if next(result.changes) then
            validatedChanges, validationError = ValidateHandlingChanges(result.changes)
            if not validatedChanges then
                finishAiRequest(playerId, session, requestId, { ok = false, error = 'aiInvalid' })
                return
            end
        end
        finishAiRequest(playerId, session, requestId, {
            ok = true,
            explanation = result.explanation,
            changes = validatedChanges,
        })
    end, 'POST', encoded, {
        ['Content-Type'] = 'application/json',
        Authorization = 'Bearer ' .. apiKey,
    })
end

AddEventHandler('playerDropped', function()
    local playerId = source
    playerSessions[playerId] = (playerSessions[playerId] or 0) + 1
    aiRequests[playerId] = nil
    aiLastRequest[playerId] = nil
    requestWindows[playerId] = nil
end)

local function loadLibrary(playerId)
    local key = getLibraryKey(playerId)
    if not key then
        return nil, 'invalidStorage'
    end

    local payload = GetResourceKvpString(key)
    if payload == nil or payload == '' then
        return nil
    end

    local ok, decoded = pcall(json.decode, payload)
    if not ok or type(decoded) ~= 'table' then
        return nil, 'invalidStorage'
    end

    local valid, err = validateLibrary(decoded)
    if not valid then
        return nil, 'invalidStorage'
    end

    return decoded
end

local function saveLibrary(playerId, library)
    local key = getLibraryKey(playerId)
    if not key then
        return false, 'invalidStorage'
    end

    for _, collection in ipairs({ 'presets', 'backups', 'reports', 'runs', 'feedback', 'history' }) do
        if library[collection] == nil then
            library[collection] = {}
        end
    end

    local valid, err = validateLibrary(library)
    if not valid then
        return false, err
    end

    local encodeOk, encoded = pcall(json.encode, library)
    if not encodeOk or type(encoded) ~= 'string' then
        return false, 'invalidStorage'
    end

    local size = string.len(encoded)
    if size > (Config.MaxStorageBytes or 500000) then
        return false, 'invalidStorage'
    end

    local previous = GetResourceKvpString(key)
    if previous and previous ~= '' then
        local decodeOk, decoded = pcall(json.decode, previous)
        if decodeOk and type(decoded) == 'table' then
            local previousValid = validateLibrary(decoded)
            if previousValid then
                SetResourceKvp(key .. ':previous', previous)
            end
        end
    end
    SetResourceKvp(key, encoded)
    return true
end

RegisterNetEvent('luxarcia:request')
AddEventHandler('luxarcia:request', function(requestId, action, payload)
    if type(requestId)~='number' or requestId%1~=0 or requestId<1 or requestId>2147483647
        or type(action)~='string' or #action>30 or (payload~=nil and type(payload)~='table') then return end
    local now=GetGameTimer()
    local window=requestWindows[source]
    if not window or now-window.started>=1000 then window={started=now,count=0};requestWindows[source]=window end
    window.count=window.count+1
    if window.count>30 then sendReply(source,requestId,{ok=false,error='rateLimit'});return end
    local request = payload or {}

    if action == 'authorize' then
        local allowed, reason = permissions.CanPlayerOpenHandlingEditor(source)
        sendReply(source, requestId, {
            ok = allowed,
            error = reason,
            flags = {
                ai = allowed and aiEnabled(),
                smart = true,
                telemetry = true,
                tests = true,
                presets = Config.EnablePresets ~= false,
                interval = 100,
                historyLimit = math.max(1,math.min(500,Config.HistoryLimit or 100)),
                restore = true,
            },
        })
        return
    end

    local allowed, reason = permissions.CanPlayerOpenHandlingEditor(source)
    if not allowed then
        sendReply(source, requestId, { ok = false, error = reason or 'unauthorized' })
        return
    end
    local encodeOk, encoded = pcall(json.encode, request)
    if not encodeOk or type(encoded)~='string' or #encoded>(Config.MaxStorageBytes or 2000000)+20000 then
        sendReply(source,requestId,{ok=false,error='invalidValues'});return
    end

    if action == 'validate' then
        local valid, err = ValidateHandlingChanges(request.values or {})
        sendReply(source, requestId, {
            ok = valid ~= nil,
            values = valid,
            error = err,
        })
        return
    end

    if action == 'saveHistory' then
        if Config.EnablePresets == false then
            sendReply(source, requestId, { ok = false, error = 'disabled' })
            return
        end

        local history = request.history or {}
        if type(history) ~= 'table' then
            sendReply(source, requestId, { ok = false, error = 'invalidHistory' })
            return
        end

        local library, loadError = loadLibrary(source)
        if not library then
            if loadError then
                sendReply(source, requestId, { ok = false, error = loadError })
                return
            end

            library = {
                version = 2,
                presets = {},
                backups = {},
                reports = {},
                runs = {},
                feedback = {},
                history = {},
            }
        end

        library.history = history
        local ok, err = saveLibrary(source, library)
        sendReply(source, requestId, { ok = ok, error = err, data = library })
        return
    end

    if action == 'load' then
        local library, err = loadLibrary(source)
        if not library then
            if not err then
                sendReply(source, requestId, { ok = true, data = nil })
                return
            end
            sendReply(source, requestId, { ok = false, error = err or 'empty' })
            return
        end
        sendLargeReply(source, requestId, { ok = true, data = library })
        return
    end

    if action == 'save' then
        if Config.EnablePresets == false then
            sendReply(source, requestId, { ok = false, error = 'disabled' })
            return
        end

        local ok, err = saveLibrary(source, request.data or request)
        sendReply(source, requestId, { ok = ok, error = err })
        return
    end

    if action == 'recover' then
        if Config.EnablePresets == false then
            sendReply(source, requestId, { ok = false, error = 'disabled' })
            return
        end

        local key = getLibraryKey(source)
        if not key then sendReply(source,requestId,{ok=false,error='invalidStorage'});return end
        local previous = GetResourceKvpString(key .. ':previous')
        if not previous or previous == '' then
            sendReply(source, requestId, { ok = false, error = 'empty' })
            return
        end

        local ok, decoded = pcall(json.decode, previous)
        if not ok or type(decoded) ~= 'table' then
            sendReply(source, requestId, { ok = false, error = 'invalidStorage' })
            return
        end

        local valid, err = validateLibrary(decoded)
        if not valid then
            sendReply(source, requestId, { ok = false, error = err or 'invalidStorage' })
            return
        end

        sendLargeReply(source, requestId, { ok = true, data = decoded })
        return
    end

    if action == 'ai' then
        handleAiRequest(source, requestId, request)
        return
    end

    sendReply(source, requestId, { ok = false, error = 'unsupportedRequest' })
end)


