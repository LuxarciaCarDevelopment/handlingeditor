fx_version 'cerulean'
game 'gta5'

author 'Luxarcia'
description 'Luxarcia Handling Editor V2.0'
version '2.0.0'

lua54 'yes'

escrow_ignore {
    'config.lua'
}

client_scripts {
    'client/main.lua',
    'client/handling.lua',
    'client/telemetry.lua',
    'client/performance.lua',
    'client/laps.lua',
    'client/tuning.lua',
    'client/presets.lua',
    'client/vehicle.lua'
}

server_scripts {
    'config.lua',
    'server/main.lua',
    'server/permissions.lua',
    'server/ai.lua',
    'server/storage.lua'
}

shared_scripts {
    'shared/schema.lua',
    'shared/parameters.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/tools.html',
    'web/app.js',
    'web/schema.json',
    'web/style.css',
    'web/core.js',
    'web/locales.js',
    'web/css/*.css',
    'web/js/*.js'
}
