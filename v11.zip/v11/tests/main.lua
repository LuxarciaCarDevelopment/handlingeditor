nativeValues=baseValues()
local monitor=threads[#threads]
assert(coroutine.resume(monitor))
commands.handling(0);resumeLatest();assert(focus and lastMessage.type=='open')
assert(lastMessage.telemetry~=nil)
assert(lastMessage.telemetry.normalizedRpm==.5)
assert(callback('saveHistory',{history={}}).ok and lastServerAction=='saveHistory')
assert(callback('applyHandling',{generation=Handling.generation,values={fMass=1800},label='manual'}).ok)
assert(nativeValues.fMass==1800)
assert(not callback('applyHandling',{generation=Handling.generation-1,values={fMass=1900}}).ok)
owner=false
assert(callback('applyHandling',{generation=Handling.generation,values={fMass=1900}}).error=='noControl')
owner=true
vehicle=2
assert(callback('resetAll',{}).error=='staleVehicle')
assert(coroutine.resume(monitor));assert(not focus and Handling.vehicle==1)
vehicle=1
callback('closeEditor',{});assert(not focus)
assert(callback('applyHandling',{values={fMass=1900}}).error=='unauthorized')
-- ESC/second command cancels an opening that is still awaiting authorization.
delayedAuth=true;local openingThread=coroutine.create(function()commands.handling(0)end)
assert(coroutine.resume(openingThread))
commands.handling(0);assert(not focus)
delayedAuth=false;local reply=waitingReplies[#waitingReplies];source=65535;events['luxarcia:reply'](reply.id,reply.result)
assert(coroutine.resume(openingThread));assert(not focus)
-- A subsequent command opens cleanly and resource stop releases focus/restores.
commands.handling(0);resumeLatest();assert(focus)
local originalBeforeCleanup=Handling.original.fMass
assert(callback('applyHandling',{generation=Handling.generation,values={fMass=1700}}).ok)
events.onResourceStop('luxarcia_test');assert(not focus and nativeValues.fMass==originalBeforeCleanup)
print('PASS Lua: command/focus, telemetry open snapshot, stale callback, idle vehicle exit, pending-open cancellation, resource cleanup')
