'use strict';
// Inspect Chromium's composited PNG alpha: transparent CSS alone does not prove
// that the NUI canvas is transparent (root color-scheme can still make it opaque).
const {chromium}=require('playwright');
const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const zlib=require('node:zlib'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../web');
function alphaRange(png){
  let width,height,channels;const chunks=[];
  for(let offset=8;offset<png.length;){
    const length=png.readUInt32BE(offset),type=png.toString('ascii',offset+4,offset+8);
    const data=png.subarray(offset+8,offset+8+length);
    if(type==='IHDR'){
      width=data.readUInt32BE(0);height=data.readUInt32BE(4);
      assert.equal(data[8],8,'PNG must use 8-bit channels');
      assert([2,6].includes(data[9]),'PNG must be RGB or RGBA');
      assert.equal(data[12],0,'PNG must not be interlaced');
      channels=data[9]===6?4:3;
    }
    if(type==='IDAT')chunks.push(data);
    offset+=12+length;
  }
  const raw=zlib.inflateSync(Buffer.concat(chunks)),stride=width*channels;
  let previous=Buffer.alloc(stride),offset=0,min=255,max=0,opaque=0,firstPixel,different=0;
  const paeth=(a,b,c)=>{const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c;};
  for(let y=0;y<height;y++){
    const filter=raw[offset++],line=Buffer.alloc(stride);
    for(let x=0;x<stride;x++){
      const a=x>=channels?line[x-channels]:0,b=previous[x],c=x>=channels?previous[x-channels]:0;
      const predictor=[0,a,b,Math.floor((a+b)/2),paeth(a,b,c)][filter];
      assert.notEqual(predictor,undefined,'Unsupported PNG filter');
      line[x]=(raw[offset++]+predictor)&255;
      if(x%channels===channels-1){
        const rgba=[...line.subarray(x-channels+1,x-channels+4),channels===4?line[x]:255];
        const alpha=rgba[3];min=Math.min(min,alpha);max=Math.max(max,alpha);if(alpha)opaque++;
        if(!firstPixel)firstPixel=rgba;else if(rgba.some((value,i)=>value!==firstPixel[i]))different++;
      }
    }
    previous=line;
  }
  return {min,max,opaque,firstPixel,different};
}
const server=http.createServer((req,res)=>{
  if(req.url==='/frame'){
    res.setHeader('Content-Type','text/html');
    res.end('<!doctype html><html style="color-scheme:light"><head><style>html,body{margin:0;width:100%;height:100%;background:rgb(211,42,129)}iframe{display:block;width:100%;height:100%;border:0}</style></head><body><iframe src="/"></iframe></body></html>');
    return;
  }
  const file=path.resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]==='/'?'/tools.html':req.url.split('?')[0]));
  if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  try{res.setHeader('Content-Type',file.endsWith('.css')?'text/css':file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file));}catch{res.writeHead(404).end();}
});
(async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
  try{
    fs.mkdirSync(path.resolve(__dirname,'../test-results'),{recursive:true});
    const themes=['Neon','Emerald','Midnight','Sunset','Arctic'];
    for(const stylesheet of [true,false]){
      const page=await browser.newPage({viewport:{width:640,height:360}});
      // Keep the editor closed even if application JavaScript fails to start.
      await page.route('**/*.js',route=>route.abort());
      if(!stylesheet)await page.route('**/style.css',route=>route.abort());
      await page.goto(`http://127.0.0.1:${server.address().port}/`);
      for(const theme of themes){
        await page.evaluate(theme=>{document.body.className=theme.toLowerCase();},theme);
        assert(await page.locator('#app').isHidden());
        for(const selector of ['html','body'])assert.equal(await page.locator(selector).evaluate(el=>getComputedStyle(el).colorScheme),'normal',`${selector} must not set a canvas color scheme`);
        const png=await page.screenshot({omitBackground:true,path:path.resolve(__dirname,`../test-results/hidden-${theme.toLowerCase()}-${stylesheet?'styled':'unstyled'}.png`)});
        const alpha=alphaRange(png);
        assert.equal(alpha.max,0,`${theme}, stylesheet ${stylesheet?'loaded':'failed'}: ${alpha.opaque} painted pixels in closed NUI`);
        if(stylesheet){
          await page.locator('#app').evaluate(el=>{el.hidden=false;});
          const visible=alphaRange(await page.screenshot({omitBackground:true}));
          assert.equal(visible.max,255,'Visible app must actually paint opaque pixels');
          assert(visible.min<255,'Visible app must preserve transparency outside the frame and its shadow');
          assert.equal(await page.locator('#app').evaluate(el=>getComputedStyle(el).colorScheme),theme==='Arctic'?'light':'dark');
          await page.locator('#app').evaluate(el=>{el.hidden=true;});
          await page.locator('#proposal').evaluate(el=>el.showModal());
          await page.locator('#proposal').evaluate(el=>el.close());
          assert.equal(alphaRange(await page.screenshot({omitBackground:true})).max,0,'Closed app and dialog must leave no painted backdrop');
        }
      }
      await page.close();
    }
    // FiveM embeds NUI as a fullscreen iframe. A mismatched root color scheme
    // can paint a child Canvas despite transparent computed html/body backgrounds.
    const embedded=await browser.newPage({viewport:{width:640,height:360}});
    await embedded.route('**/*.js',route=>route.abort());
    await embedded.goto(`http://127.0.0.1:${server.address().port}/frame`);
    const frame=embedded.frames().find(frame=>frame!==embedded.mainFrame());
    await frame.locator('#app').waitFor({state:'hidden'});
    const scene=[211,42,129,255],evidence=[];
    for(const theme of themes){
      await frame.evaluate(theme=>{document.body.className=theme.toLowerCase();},theme);
      const clear=alphaRange(await embedded.screenshot({omitBackground:true,path:path.resolve(__dirname,`../test-results/iframe-fixed-${theme.toLowerCase()}.png`)}));
      assert.deepEqual(clear.firstPixel,scene,`${theme}: parent scene must remain visible through the closed NUI`);
      assert.equal(clear.different,0,`${theme}: closed NUI must not tint any part of the parent scene`);
      const legacy=await frame.addStyleTag({content:`html{color-scheme:dark!important}body{color-scheme:${theme==='Arctic'?'light':'dark'}!important}`});
      for(const selector of ['html','body'])assert.equal(await frame.locator(selector).evaluate(el=>getComputedStyle(el).backgroundColor),'rgba(0, 0, 0, 0)');
      const painted=alphaRange(await embedded.screenshot({omitBackground:true,path:path.resolve(__dirname,`../test-results/iframe-legacy-color-scheme-${theme.toLowerCase()}.png`)}));
      assert.notDeepEqual(painted.firstPixel,scene,`${theme}: legacy mismatch must reproduce the opaque Canvas`);
      assert.equal(painted.different,0,'The old iframe Canvas covers the complete viewport');
      evidence.push({theme,fixed:clear.firstPixel,legacy:painted.firstPixel});
      await legacy.evaluate(el=>el.remove());
      const restored=alphaRange(await embedded.screenshot({omitBackground:true}));
      assert.deepEqual(restored.firstPixel,scene);
      assert.equal(restored.different,0,'Removing root color-scheme must restore the parent scene');
    }
    console.log('Iframe canvas evidence:',JSON.stringify(evidence));
    await embedded.close();
    console.log('PASS transparency: zero painted pixels while closed in all five themes, failed CSS/JS, and fullscreen iframe Canvas reproduction/fix');
  }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;}).finally(()=>server.close());

