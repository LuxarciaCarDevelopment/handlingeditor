nativeValues=baseValues();assert(Handling.capture(1))
local sampler=threads[#threads]
local initialThreadCount=#threads
local initialWaitCount=#waitCalls
local initialMessageCount=#nuiMessages
assert(sampler and initialThreadCount==1)

vehicle=0
assert(Telemetry.snapshot()==nil)
assert(StartTelemetry()==nil)
local unavailable
nuiCallbacks.getTelemetry({},function(data)unavailable=data end)
assert(type(unavailable)=='table' and next(unavailable)==nil)

vehicle=1
frame={speed=36,engineHealth=875}
nuiFocused=false
local ok,delay=coroutine.resume(sampler)
assert(ok and delay==250)
assert(#nuiMessages==initialMessageCount)

nuiFocused=true
frame={speed=72,engineHealth=920}
ok,delay=coroutine.resume(sampler)
assert(ok and delay==250)
assert(#nuiMessages==initialMessageCount+1)
assert(lastMessage.type=='telemetry')
assert(lastMessage.data.speed==72)
assert(lastMessage.data.normalizedRpm==.5)
assert(lastMessage.data.gear==2)
assert(lastMessage.data.engineHealth==920)
assert(lastMessage.data.modelHash==123 and lastMessage.data.modelName=='TEST_ONLY' and lastMessage.data.class==7)

local snapshot=Telemetry.snapshot()
assert(snapshot.speed==72 and snapshot.engineHealth==920)
snapshot.speed=-1
assert(Telemetry.snapshot().speed==72)
local started=StartTelemetry()
assert(started.speed==72 and started.normalizedRpm==.5)
local callbackData
nuiCallbacks.getTelemetry({},function(data)callbackData=data end)
assert(callbackData.speed==72 and callbackData.gear==2)

local messageCount=#nuiMessages
vehicle=0
ok,delay=coroutine.resume(sampler)
assert(ok and delay==250)
assert(#nuiMessages==messageCount)
assert(Telemetry.snapshot()==nil)

vehicle=1
frame={speed=54,engineHealth=810}
assert(Telemetry.snapshot().speed==54)
local cachedSnapshot
for index=1,8 do
    local name,value=debug.getupvalue(StopTelemetry,index)
    if not name then break end
    if name=='telemetryData' then cachedSnapshot=value end
end
assert(cachedSnapshot~=nil)
StopTelemetry()
cachedSnapshot=nil
for index=1,8 do
    local name,value=debug.getupvalue(StopTelemetry,index)
    if not name then break end
    if name=='telemetryData' then cachedSnapshot=value end
end
assert(cachedSnapshot==nil)
assert(#threads==initialThreadCount)
assert(#waitCalls==initialWaitCount+3)
assert(waitCalls[#waitCalls]==250)

print('PASS Lua: production telemetry initialization, fixed-interval sampling, focused NUI delivery, snapshot/start/stop, callback, invalid vehicles, and bounded scheduling')