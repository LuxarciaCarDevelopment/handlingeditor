'use strict';

const { chromium } = require('playwright');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const projectRoot = path.resolve(__dirname, '..');
const root = path.join(projectRoot, 'web');
const schema = require('../web/schema.json');
const original = Object.fromEntries(schema.map((field) => [field.field,
    field.type === 'vector' ? { x: 1, y: 1, z: 1 } : field.rule === 'bias' ? 0.5 : field.rule === 'gears' ? 6 : 1
]));
original.fMass = 1500;
let values = structuredClone(original);
let history = [structuredClone(values)];
let cursor = 0;
let generation = 1;
const requests = [];

const server = http.createServer((request, response) => {
    const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
    const file = path.resolve(root, `.${pathname === '/' ? '/index.html' : pathname}`);
    if (!file.startsWith(root + path.sep) && file !== path.join(root, 'index.html')) {
        response.writeHead(403).end();
        return;
    }
    try {
        const content = fs.readFileSync(file);
        const contentType = file.endsWith('.js') ? 'application/javascript' : file.endsWith('.css') ? 'text/css' : file.endsWith('.json') ? 'application/json' : 'text/html';
        response.writeHead(200, { 'Content-Type': contentType });
        response.end(content);
    } catch (_) {
        response.writeHead(404).end();
    }
});

async function main() {
    const callbacks = ['closeEditor', 'applyHandling', 'undoHandling', 'redoHandling', 'resetField', 'resetAll'];
    const clientMain = fs.readFileSync(path.join(projectRoot, 'client/main.lua'), 'utf8');
    for (const callback of callbacks) {
        assert(clientMain.includes(`RegisterNUICallback('${callback}'`), `Missing NUI callback ${callback}`);
    }

    await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
    const browser = await chromium.launch({
        executablePath: process.env.CHROME_PATH || 'C:/Program Files/Google/Chrome/Application/chrome.exe',
        headless: true
    });

    try {
        const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
        const errors = [];
        page.on('pageerror', (error) => errors.push(error.message));
        await page.addInitScript(() => {
            window.GetParentResourceName = () => 'luxarcia-phase3-test';
            window.confirm = () => true;
        });
        await page.route('https://luxarcia-phase3-test/**', async (route) => {
            const action = new URL(route.request().url()).pathname.split('/').pop();
            const body = route.request().postDataJSON() || {};
            requests.push(action);
            let result = { ok: true };
            if (action === 'applyHandling') {
                values = { ...values, ...body.values };
                history = history.slice(0, cursor + 1);
                history.push(structuredClone(values));
                cursor = history.length - 1;
                generation += 1;
                result = { ok: true, generation, changed: structuredClone(values) };
            } else if (action === 'undoHandling') {
                cursor = Math.max(0, cursor - 1);
                values = structuredClone(history[cursor]);
                generation += 1;
                result = { ok: true, generation, values: structuredClone(values) };
            } else if (action === 'redoHandling') {
                cursor = Math.min(history.length - 1, cursor + 1);
                values = structuredClone(history[cursor]);
                generation += 1;
                result = { ok: true, generation, values: structuredClone(values) };
            } else if (action === 'resetField') {
                values[body.fieldName] = structuredClone(original[body.fieldName]);
                generation += 1;
                result = { ok: true, generation, values: structuredClone(values) };
            } else if (action === 'resetAll') {
                values = structuredClone(original);
                generation += 1;
                result = { ok: true, generation, values: structuredClone(values) };
            }
            await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(result) });
        });

        await page.goto(`http://127.0.0.1:${server.address().port}`);
        assert.equal(await page.locator('#vehicle-speed').innerText(), '—');
        await page.evaluate(({ schema: vehicleSchema, values: vehicleValues }) => {
            const payload = {
                ok: true,
                generation: 1,
                values: vehicleValues,
                original: vehicleValues,
                schema: vehicleSchema,
                vehicle: { modelHash: 12345, modelName: 'Fixture Sultan', class: 7 },
                telemetry: { speed: 82.4, normalizedRpm: 0.72, gear: 4, engineHealth: 947 }
            };
            window.postMessage({ action: 'openEditor', payload, telemetry: payload.telemetry }, '*');
        }, { schema, values: original });

        const app = page.locator('#luxarcia-app');
        await app.waitFor({ state: 'visible' });
        assert.equal(await page.locator('#module-navigation [data-panel]').count(), 22);
        assert.equal(await page.locator('#module-navigation [data-panel]:not([disabled])').count(), 22);
        assert.equal(await page.locator('#vehicle-speed').innerText(), '82.4');
        assert.equal(await page.locator('#vehicle-rpm').innerText(), '72');
        assert.equal(await page.locator('#vehicle-gear').innerText(), '4');
        assert.equal(await page.locator('#vehicle-health').innerText(), '947');
        assert.equal(await page.locator('#tuning-profile').innerText(), 'Not set');

        for (const theme of ['luxarcia-dark', 'midnight-black', 'neon-blue', 'racing-red', 'premium-purple']) {
            await page.locator('#theme-selector').selectOption(theme);
            assert.equal(await page.locator('html').getAttribute('data-theme'), theme);
        }
        assert.equal(await page.evaluate(() => localStorage.getItem('luxarcia-theme')), 'premium-purple');
        await page.locator('#language-selector').selectOption('tr');
        assert.equal(await page.locator('#dashboard-panel h2').innerText(), 'Ana Panel');
        assert.equal(await page.locator('.nav-state').count(), 0);
        await page.locator('#language-selector').selectOption('en');
        assert.equal(await page.evaluate(() => localStorage.getItem('luxarcia-language')), 'en');

        await page.locator('[data-panel="2"]').click();
        await page.locator('#tuning-intensity').fill('10');
        const requestsBeforePreview = requests.length;
        await page.locator('#preview-profile-button').click();
        await page.locator('#tuning-preview-dialog').waitFor({ state: 'visible' });
        assert.equal(await page.locator('#preview-fields tr').count(), 13);
        const driveForcePreview = page.locator('#preview-fields tr').filter({ hasText: 'fInitialDriveForce' });
        assert.equal((await driveForcePreview.locator('td').nth(2).innerText()).trim(), '1.0086');
        assert.equal(requests.length, requestsBeforePreview, 'opening a preview must not apply changes');
        await page.locator('#cancel-tuning-preview').click();
        assert.equal(requests.length, requestsBeforePreview, 'canceling preview must not apply changes');
        await page.locator('#preview-profile-button').click();
        await page.locator('#approve-tuning').click();
        await page.waitForFunction(() => document.querySelector('#tuning-preview-dialog').open === false);
        assert.equal(requests.filter(action => action === 'applyHandling').length, 1);
        assert.equal(values.fInitialDriveForce, 1.00864);
        await page.locator('[data-panel="0"]').click();
        assert.equal(await page.locator('#tuning-profile').innerText(), 'Race');
        await page.locator('[data-panel="2"]').click();
        await page.locator('[data-analysis="health"]').click();
        assert((await page.evaluate(() => document.getElementById('analysis-results')?.innerText || '')).length > 0);
        await page.locator('[data-analysis="conflicts"]').click();
        await page.locator('#analysis-goal-conflicts').waitFor({ state: 'visible' });
        assert((await page.evaluate(() => document.getElementById('analysis-results')?.innerText || '')).length > 0);
        await page.locator('[data-analysis-goal="Race"]').check();
        await page.locator('[data-analysis-goal="Comfort"]').check();
        assert((await page.evaluate(() => document.getElementById('analysis-results')?.innerText || '')).includes('Opposing tuning goals'));

        await page.locator('[data-panel="3"]').click();
        await page.locator('#wizard-goal').selectOption('Comfort');
        const wizardAppliesBefore = requests.filter(action => action === 'applyHandling').length;
        await page.locator('#wizard-analyze').click();
        await page.locator('#wizard-recommend').click();
        await page.locator('#wizard-preview').click();
        await page.locator('#tuning-preview-dialog').waitFor({ state: 'visible' });
        assert.equal(requests.filter(action => action === 'applyHandling').length, wizardAppliesBefore);
        await page.locator('#approve-tuning').click();
        await page.locator('#wizard-result').waitFor({ state: 'visible' });
        assert.equal(requests.filter(action => action === 'applyHandling').length, wizardAppliesBefore + 1);
        await page.locator('#wizard-undo').click();
        await page.waitForFunction(() => document.querySelector('#wizard-progress').innerText.includes('Step 2'));
        assert.equal(values.fInitialDriveForce, 1.00864, 'Wizard undo must restore the immediately preceding handling state');
        await page.locator('[data-panel="1"]').click();
        await page.waitForFunction(() => document.querySelector('input[data-field="fInitialDriveForce"]').value === '1.00864');

        await page.locator('[data-panel="1"]').click();
        await page.locator('input[data-field="fMass"]').fill('1650');
        await page.locator('input[data-field="fMass"]').press('Tab');
        await page.waitForFunction(() => document.querySelector('#editor-toast').classList.contains('visible'));
        assert(requests.includes('applyHandling'));
        await page.locator('#undo-button').click();
        await page.waitForFunction(() => document.querySelector('input[data-field="fMass"]').value === '1500');
        await page.locator('#redo-button').click();
        await page.waitForFunction(() => document.querySelector('input[data-field="fMass"]').value === '1650');
        await page.locator('.reset-field-btn[data-field="fMass"]').click();
        await page.waitForFunction(() => document.querySelector('input[data-field="fMass"]').value === '1500');
        await page.locator('input[data-field="fMass"]').fill('1650');
        await page.locator('input[data-field="fMass"]').press('Tab');
        await page.waitForFunction(() => document.querySelector('input[data-field="fMass"]').value === '1650');
        await page.locator('#reset-all-button').click();
        await page.waitForFunction(() => document.querySelector('input[data-field="fMass"]').value === '1500');
        assert(requests.includes('undoHandling') && requests.includes('redoHandling') && requests.includes('resetField') && requests.includes('resetAll'));

        await page.setViewportSize({ width: 2560, height: 1440 });
        assert(await page.locator('#luxarcia-app').evaluate((element) => element.clientWidth > 2000));
        assert(await page.locator('.main-scroll').evaluate((element) => element.scrollWidth <= element.clientWidth + 1));
        assert.equal(await page.evaluate(() => getComputedStyle(document.body).backgroundColor), 'rgba(0, 0, 0, 0)');
        assert.deepEqual(errors, []);
        console.log('PASS browser: 22 modules / 22 enabled, real telemetry, five themes, EN/TR, tuning preview approval, diagnostics, Wizard, undo/redo/reset, 1920x1080 and 2560x1440');
    } finally {
        await browser.close();
        await new Promise((resolve) => server.close(resolve));
    }
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});

