'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),vm=require('node:vm');
const parser=require('luaparse'),{lua,lauxlib,lualib,to_luastring,to_jsstring}=require('fengari');
const Core=require('../web/core.js'),schema=require('../web/schema.json');
require('./tuning.js');
for(const file of ['fxmanifest.lua','config.lua',...['shared','server','client'].flatMap(d=>fs.readdirSync(d).filter(f=>f.endsWith('.lua')).map(f=>d+'/'+f))]){parser.parse(fs.readFileSync(file,'utf8'),{luaVersion:'5.3'});}
console.log('PASS Lua syntax: all resource scripts');
const suiteFailures=[];
function runLua(name,files){const L=lauxlib.luaL_newstate();lualib.luaL_openlibs(L);try{for(const file of files){const code=fs.readFileSync(file,'utf8');if(lauxlib.luaL_dostring(L,to_luastring(code))!==lua.LUA_OK)throw Error(file+': '+to_jsstring(lua.lua_tostring(L,-1)));}}catch(error){suiteFailures.push(`${name}: ${error.message}`);console.error(`FAIL Lua ${name}: ${error.message}`);}finally{lua.lua_close(L);}}
const base=['tests/lua-harness.lua','shared/schema.lua'];
runLua('NUI security',[...base,'client/handling.lua','tests/main-prelude.lua','client/main.lua','tests/main-security.lua']);
runLua('handling',[...base,'client/handling.lua','tests/handling.lua']);
runLua('telemetry snapshot',[...base,'client/handling.lua','client/telemetry.lua','tests/telemetry-snapshot.lua']);
runLua('telemetry engine',[...base,'client/handling.lua','client/telemetry.lua','tests/telemetry.lua']);
runLua('main integration',[...base,'client/handling.lua','client/telemetry.lua','tests/main-prelude.lua','client/main.lua','tests/main.lua']);
runLua('server',[...base,'config.lua','server/main.lua','tests/server.lua']);
runLua('performance',[...base,'client/handling.lua','client/performance.lua','client/laps.lua','tests/performance.lua']);
const values=Object.fromEntries(schema.map(s=>[s.field,s.type==='vector'?{x:1,y:1,z:1}:s.rule==='bias'?.5:s.rule==='gears'?6:1]));values.fMass=1500;values.fSuspensionLowerLimit=-.1;values.fSuspensionUpperLimit=.1;
assert.equal(schema.length,46);assert.equal(new Set(schema.map(s=>s.field)).size,46);Core.validate(values,schema,true);
assert(Core.xmlExport({...values,nInitialDriveGears:8},schema).includes('<nInitialDriveGears value="8"'));
for(const profile of [...Object.keys(Core.profiles),...Object.keys(Core.quick)]){for(let percent=10;percent<=100;percent++)Core.validate(Core.tune(values,profile,percent/100),schema);}
for(const bad of [{fMass:NaN},{fMass:Infinity},{nInitialDriveGears:2.5},{nInitialDriveGears:256},{fDriveBiasFront:.05},{fDriveBiasFront:.95},{fPercentSubmerged:0},{fSteeringLock:0},{fBrakeBiasFront:2},{notAField:1},{vecInertiaMultiplier:{x:0,y:1,z:1}}])assert.throws(()=>Core.validate(bad,schema));
assert.equal(Core.dyno([{invalid:false,acceleration:2,speed:36,rpm:.5}],1500)[0].kw,30);
assert.equal(Core.ghost([{time:0,x:0,y:0,z:0,speed:20,distance:0},{time:100,x:0,y:1,z:0,speed:30,distance:1}],[{time:0,x:0,y:0,z:0,speed:10,distance:0},{time:100,x:0,y:1,z:0,speed:20,distance:1}]).speedDelta,10);
const ctx={};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/locales.js','utf8'),ctx);assert.deepEqual(Object.keys(ctx.Locales.en).sort(),Object.keys(ctx.Locales.tr).sort());assert.equal(ctx.Locales.en.panels.length,22);
const app=fs.readFileSync('web/app.js','utf8');const keys=[...app.matchAll(/\b(?:t|note|btn|metric|card)\('([A-Za-z]+)'/g)].map(m=>m[1]);for(const k of keys)assert(k in ctx.Locales.en||schema.some(s=>s.field===k),'Missing translation '+k);
console.log('PASS JS: schemas, profiles, input rejection, dyno, ghost, TR/EN parity and 22 panel labels');
if(suiteFailures.length){console.error(`FAIL: ${suiteFailures.length} Lua suite(s) failed; all suites were executed.`);process.exitCode=1;}else{console.log('PASS: all Lua suites');}
