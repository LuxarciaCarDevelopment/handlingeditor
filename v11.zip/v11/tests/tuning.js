'use strict';

const assert = require('node:assert/strict');
const Core = require('../web/core.js');
const schema = require('../web/schema.json');

const baseline = Object.fromEntries(schema.map((field) => [field.field,
    field.type === 'vector' ? { x: 1, y: 1, z: 1 } : field.rule === 'bias' ? 0.5 : field.rule === 'gears' ? 6 : 1
]));
Object.assign(baseline, {
    fMass: 1500,
    fInitialDriveForce: 0.3,
    fBrakeForce: 0.8,
    fTractionCurveMax: 2.5,
    fTractionCurveMin: 2.2,
    fSteeringLock: 35,
    fSuspensionLowerLimit: -0.1,
    fSuspensionUpperLimit: 0.1,
    fAntiRollBarForce: 0.8,
    fTractionLossMult: 1,
    vecCentreOfMassOffset: { x: 0, y: 0, z: -0.1 }
});

const profiles = ['Race', 'Drift', 'Sport', 'Realistic', 'Comfort'];
for (const profile of profiles) {
    for (const intensity of [0.1, 0.5, 1]) {
        const proposal = Core.tune(baseline, profile, intensity, 6, schema);
        Core.validate(proposal, schema);
        assert(Object.keys(proposal).length > 0, `${profile} must transform real handling fields`);
    }
}

const raceAtTen = Core.tune(baseline, 'Race', 0.1, 6, schema);
const raceAtHundred = Core.tune(baseline, 'Race', 1, 6, schema);
assert.equal(raceAtTen.fInitialDriveForce, Number((baseline.fInitialDriveForce * 1.00864).toFixed(6)));
assert.equal(raceAtHundred.fInitialDriveForce, Number((baseline.fInitialDriveForce * 1.0864).toFixed(6)));
assert.deepEqual(Core.tune(baseline, 'Race', 0.5, 6, schema), Core.tune(baseline, 'Race', 0.5, 6, schema));
assert.equal(baseline.fInitialDriveForce, 0.3, 'tuning must not mutate captured baseline values');

const heavyRace = Core.tune(baseline, 'Race', 1, 2, schema);
const sportsRace = Core.tune(baseline, 'Race', 1, 7, schema);
assert.notEqual(heavyRace.fInitialDriveForce, sportsRace.fInitialDriveForce, 'class must adapt recommendations');
assert.equal(Core.vehicleCategory(2), 'heavy');
assert.equal(Core.vehicleCategory(7), 'performance');
const rearDriveBaseline = { ...baseline, fDriveBiasFront: 0 };
const frontDriveBaseline = { ...baseline, fDriveBiasFront: 1 };
const rearDrift = Core.tune(rearDriveBaseline, 'Drift', 1, 6, schema);
const frontDrift = Core.tune(frontDriveBaseline, 'Drift', 1, 6, schema);
assert(rearDrift.fTractionCurveMin < frontDrift.fTractionCurveMin, 'drift traction changes must respect baseline drivetrain');
assert.equal({ ...rearDriveBaseline, ...rearDrift }.fDriveBiasFront, 0);
assert.equal({ ...frontDriveBaseline, ...frontDrift }.fDriveBiasFront, 1);

for (const action of ['improveAcceleration', 'increaseTopSpeed', 'improveBraking', 'improveCornering', 'reduceWheelspin', 'improveStability', 'improveSteering', 'balanceSuspension']) {
    const proposal = Core.tune(baseline, action, 0.75, 6, schema);
    Core.validate(proposal, schema);
    assert(Object.keys(proposal).length > 0, `${action} must produce supported changes`);
}

const preview = Core.tuningPreview(baseline, 'Sport', 0.6, 6, schema);
assert.equal(preview.name, 'Sport');
assert.equal(preview.intensity, 0.6);
assert(preview.changes.length > 0);
assert.deepEqual(preview.baseline, baseline);
assert.throws(() => Core.tune(baseline, 'Race', 0.05, 6, schema));
assert.throws(() => Core.tune(baseline, 'random', 0.5, 6, schema));

const healthy = Core.healthCheck(baseline, baseline, schema);
assert.equal(healthy.valid, true);
const unhealthy = Core.healthCheck({ ...baseline, fBrakeBiasFront: 0.95, fInitialDriveForce: 2 }, baseline, schema);
assert.equal(unhealthy.valid, false);
assert(unhealthy.issues.some(issue => issue.code === 'extremeBrakeBias'));
assert(unhealthy.issues.some(issue => issue.code === 'excessDriveForce'));
assert(Core.healthCheck({ ...baseline, fInitialDriveForce: 0.6 }, baseline, schema).issues.some(issue => issue.code === 'unrealisticChange'));
assert(Core.healthCheck({ ...baseline, notSupported: 1 }, baseline, schema).issues.some(issue => issue.code === 'unsupportedField'));

const problems = Core.troubleshoot({ ...baseline, fInitialDriveForce: 1.3, fTractionCurveMin: 0.8, fBrakeForce: 0.2, fSteeringLock: 50, fInitialDriveMaxFlatVel: 200 });
for (const code of ['excessiveWheelspin', 'weakBraking', 'highSpeedInstability']) assert(problems.issues.some(issue => issue.code === code));
const conflicts = Core.detectConflicts({ ...baseline, fInitialDriveForce: 1.3, fTractionCurveMin: 0.8, fBrakeForce: 1.8, fBrakeBiasFront: 0.9 });
assert(conflicts.some(issue => issue.code === 'driveTractionConflict'));
assert(conflicts.some(issue => issue.code === 'brakeBalanceConflict'));
assert(Core.detectConflicts(baseline, ['Race', 'Comfort']).some(issue => issue.code === 'goalConflict'));
assert(Core.detectConflicts(baseline, ['Drift', 'Realistic']).some(issue => issue.code === 'goalConflict'));

assert.equal(Core.stabilityScore(baseline), Core.stabilityScore(baseline));
assert(Core.stabilityScore(baseline) >= 0 && Core.stabilityScore(baseline) <= 100);
assert.match(Core.scoreFormula, /Start at 100/);
console.log('PASS JS: deterministic profiles, class scaling, intensity, baseline, eight Quick Tunes, preview, health, troubleshooter, conflicts and stability score');