nativeValues=baseValues();Handling.capture(1)
vehicle=0
assert(Telemetry.snapshot()==nil)
assert(StartTelemetry()==nil)

local threadCount=#threads
local waitCount=#waitCalls
nuiFocused=true
frame={speed=36,engineHealth=875}
vehicle=1
local sampler=threads[#threads]
assert(sampler and #threads==threadCount)
local ok,delay=coroutine.resume(sampler)
assert(ok and delay==250)
ok,delay=coroutine.resume(sampler)
assert(ok and delay==250)
assert(#threads==threadCount and #waitCalls==waitCount+2)
assert(lastMessage.type=='telemetry')
assert(lastMessage.data.speed==36)
assert(lastMessage.data.normalizedRpm==.5)
assert(lastMessage.data.gear==2)
assert(lastMessage.data.engineHealth==875)
assert(lastMessage.data.modelHash==123 and lastMessage.data.class==7)

local snapshot=Telemetry.snapshot()
assert(snapshot.speed==36 and snapshot.engineHealth==875)
local started=StartTelemetry()
assert(started.speed==36 and started.normalizedRpm==.5)
assert(type(nuiCallbacks.getTelemetry)=='function')
local callbackData
nuiCallbacks.getTelemetry({},function(data)callbackData=data end)
assert(callbackData.speed==36 and callbackData.gear==2)

local messageCount=#nuiMessages
local stableThreadCount=#threads
local stableWaitCount=#waitCalls
local telemetryCache
for index=1,8 do
 local name,value=debug.getupvalue(StopTelemetry,index)
 if not name then break end
 if name=='telemetryData'then telemetryCache=value end
end
assert(telemetryCache~=nil)
StopTelemetry()
assert(#threads==stableThreadCount and #waitCalls==stableWaitCount)
telemetryCache=nil
for index=1,8 do
 local name,value=debug.getupvalue(StopTelemetry,index)
 if not name then break end
 if name=='telemetryData'then telemetryCache=value end
end
assert(telemetryCache==nil)

vehicle=0
ok,delay=coroutine.resume(sampler)
assert(ok and delay==250)
assert(#nuiMessages==messageCount)
assert(Telemetry.snapshot()==nil)
local unavailable
nuiCallbacks.getTelemetry({},function(data)unavailable=data end)
assert(type(unavailable)=='table' and next(unavailable)==nil)
assert(#threads==stableThreadCount)

print('PASS Lua: telemetry sampler initialization, fixed-step sampling, snapshot/start/stop APIs, callback, invalid vehicle, and bounded coroutine scheduling')