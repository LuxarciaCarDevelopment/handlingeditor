-- Test doubles only; these do not ship as runtime vehicle data.
function deepcopy(v) if type(v)~='table' then return v end local t={} for k,x in pairs(v) do t[k]=deepcopy(x) end return t end
local encoded={}; local serial=0
json={encode=function(v) serial=serial+1;local key='json:'..serial;encoded[key]=deepcopy(v);return key end,
decode=function(s) assert(encoded[s],'invalid json');return deepcopy(encoded[s]) end}
local vectors={}
vectors.__sub=function(a,b)return vector3(a.x-b.x,a.y-b.y,a.z-b.z)end
vectors.__len=function(v)return math.sqrt(v.x*v.x+v.y*v.y+v.z*v.z)end
function vector3(x,y,z)return setmetatable({x=x,y=y,z=z},vectors)end
now=0; vehicle=1; owner=true; reject=nil; nativeValues={}; threads={}; events={}; timeouts={}; replies={}; kvp={}
waitCalls={}; nuiCallbacks={}; nuiMessages={}; nuiFocused=false
commands={}
function GetGameTimer()return now end
function PlayerPedId()return 10 end
function GetVehiclePedIsIn()return vehicle end
function GetPedInVehicleSeat()return 10 end
function DoesEntityExist(v)return v~=0 end
function NetworkHasControlOfEntity()return owner end
function NetworkRequestControlOfEntity()end
function GetEntityModel()return 123 end
function GetDisplayNameFromVehicleModel()return 'TEST_ONLY' end
function GetVehicleClass()return 7 end
function GetVehicleEngineHealth()return frame.engineHealth or 1000 end
function GetVehicleHandlingFloat(v,c,f)return nativeValues[f] end
GetVehicleHandlingInt=GetVehicleHandlingFloat
function GetVehicleHandlingVector(v,c,f)local x=nativeValues[f];return vector3(x.x,x.y,x.z)end
function SetVehicleHandlingFloat(v,c,f,x)if f~=reject then nativeValues[f]=x end end
SetVehicleHandlingInt=SetVehicleHandlingFloat
function SetVehicleHandlingVector(v,c,f,x)if f~=reject then nativeValues[f]={x=x.x,y=x.y,z=x.z}end end
function CreateThread(fn)local thread=coroutine.create(fn);threads[#threads+1]=thread;return thread end
function Wait(ms)waitCalls[#waitCalls+1]=ms;return coroutine.yield(ms)end
Citizen={
 CreateThread=function(fn)return CreateThread(fn)end,
 Wait=function(ms)return Wait(ms)end
}
function RegisterNUICallback(name,fn)nuiCallbacks[name]=fn end
function IsNuiFocused()return nuiFocused end
function IsControlJustPressed()return false end
function SendNUIMessage(data)lastMessage=data;nuiMessages[#nuiMessages+1]=deepcopy(data)end
frame={speed=0,x=0,y=0,z=0}
function GetEntityCoords()return vector3(frame.x,frame.y,frame.z)end
function GetEntityVelocity()return vector3(0,frame.speed/3.6,0)end
function GetEntityForwardVector()return vector3(0,1,0)end
function GetEntityRotation()return vector3(0,0,0)end
function GetEntitySpeed()return frame.speed/3.6 end
function GetVehicleCurrentRpm()return .5 end
function GetVehicleCurrentGear()return 2 end
function GetVehicleSteeringAngle()return 0 end
function IsEntityInAir()return frame.air==true end
function HasEntityCollidedWithAnything()return frame.collision==true end
function RegisterNetEvent(name,fn)events[name]=fn end
function AddEventHandler(name,fn)events[name]=fn end
function RegisterCommand(name,fn)commands[name]=fn end
function GetPlayerIdentifiers(src)return src==1 and {'license:test','discord:123456789012345678'} or {'discord:bad'}end
function TriggerClientEvent(name,src,id,data)replies[#replies+1]={src=src,id=id,data=data}end
function GetResourceKvpString(key)return kvp[key]end
function SetResourceKvp(key,value)kvp[key]=value end
function GetConvar()return 'SERVER_SECRET_TEST' end
function SetTimeout(ms,fn)timeouts[#timeouts+1]=fn end
function PerformHttpRequest(url,cb,method,body,headers)http={url=url,cb=cb,body=json.decode(body),headers=headers}end
function baseValues()
 local v={}
 for _,s in ipairs(HandlingSchema)do
  v[s.field]=s.type=='vector' and {x=1,y=1,z=1} or s.rule=='bias' and .5 or s.rule=='gears' and 6 or 1
 end
 v.fMass=1500;v.fSuspensionUpperLimit=.1;v.fSuspensionLowerLimit=-.1
 return v
end
