'use strict';
const fs=require('node:fs'),http=require('node:http'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const schema=require('../web/schema.json');
const values=Object.fromEntries(schema.map(s=>[s.field,s.type==='vector'?{x:1,y:1,z:1}:s.rule==='bias'?.5:s.rule==='gears'?6:1]));
Object.assign(values,{fMass:1500,fSuspensionLowerLimit:-.1,fSuspensionUpperLimit:.1});
const root=path.resolve(__dirname,'../web');
const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+(req.url==='/'?'/index.html':req.url));if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}try{res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':file.endsWith('.json')?'application/json':'text/html');res.end(fs.readFileSync(file));}catch{res.writeHead(404).end();}});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
 try{
 const page=await browser.newPage({viewport:{width:1920,height:1080}}),errors=[],calls=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>window.GetParentResourceName=()=> 'advanced-test');
 let library={version:2,presets:[],backups:[],reports:[],runs:[],feedback:[],history:[]};
 let state={generation:1,model:'123',name:'Test vehicle',class:7,values:structuredClone(values),original:values,history:[{label:'original',time:0,values}],cursor:1};
 await page.route('https://advanced-test/**',async route=>{
  const data=route.request().postDataJSON();calls.push(data);let result={ok:true};
  if(data.action==='load')result.data=library;
  if(data.action==='save')library=structuredClone(data.data);
  if(data.action==='saveHistory')library.history=data.history;
  if(data.action==='apply'){state.values={...state.values,...data.values};state.generation++;state.history.push({label:data.label,time:1,values:structuredClone(state.values)});state.cursor++;result.state=state;}
  if(data.action==='telemetry')result.active=data.enabled;
  await route.fulfill({contentType:'application/json',body:JSON.stringify(result)});
 });
 await page.goto(`http://127.0.0.1:${server.address().port}/`);
 await page.evaluate(({values,schema})=>window.postMessage({action:'openEditor',payload:{generation:1,values,original:values,schema,vehicle:{modelHash:123,modelName:'Test vehicle',class:7},flags:{ai:false,smart:true,telemetry:true,tests:true,presets:true}}},'*'),{values,schema});
 const frame=page.frameLocator('#advanced-tools');
 for(const lang of ['tr','en']){
  await page.locator('#language-selector').selectOption(lang);
  for(let panel=4;panel<22;panel++){
   await page.locator(`#module-navigation [data-panel="${panel}"]`).click();
   await frame.locator('#content .card').first().waitFor();
   await page.waitForTimeout(20);
   const content=await frame.locator('#content').innerText();assert(content.length>20);assert(!content.includes('undefined'));
  }
 }
 for(const theme of ['luxarcia-dark','midnight-black','neon-blue','racing-red','premium-purple']){
  await page.locator('#theme-selector').selectOption(theme);
  await page.waitForTimeout(20);
  assert.equal(await frame.locator('body').getAttribute('data-theme'),theme);
 }
 await page.locator('#module-navigation [data-panel="16"]').click();
 await frame.locator('[data-action="newPreset"]').click();await frame.locator('#modal-name').fill('Saved from integrated tools');await frame.locator('#approve').click();
 await page.waitForTimeout(100);assert.equal(library.presets.length,1);
 await page.locator('#module-navigation [data-panel="6"]').click();
 await frame.locator('input[type="number"][data-field="fBrakeForce"]').fill('1.2');await frame.locator('input[type="number"][data-field="fBrakeForce"]').press('Tab');
 await frame.locator('#proposal').waitFor({state:'visible'});assert(!calls.some(c=>c.action==='apply'));
 await frame.locator('#approve').click();await page.waitForTimeout(150);
 assert.equal(state.values.fBrakeForce,1.2);
 await page.locator('#module-navigation [data-panel="1"]').click();
 assert.equal(await page.locator('input[data-field="fBrakeForce"]').inputValue(),'1.2');
 await page.locator('#module-navigation [data-panel="9"]').click();
 await frame.locator('[data-action="record"]').click();
 await page.evaluate(()=>window.postMessage({type:'performance',data:{generation:2,active:true,sample:{time:100,speed:45,rpm:.5,gear:2,engineHealth:990,bodyHealth:980,acceleration:2,longG:.2,latG:.1,yaw:0,vx:0,vy:12.5,steering:0,x:0,y:0,z:0,distance:0},laps:[],checkpoints:[],results:{maxSpeed:45}}},'*'));
 await frame.locator('#telemetry').waitFor();
 assert((await frame.locator('#live-values').innerText()).includes('980'));
 fs.mkdirSync('test-results',{recursive:true});await page.screenshot({path:'test-results/advanced-integrated.png'});
 await page.locator('#module-navigation [data-panel="18"]').click();assert.equal(await frame.locator('#ai-prompt').count(),0);
 await page.evaluate(()=>window.postMessage({action:'closeEditor'},'*'));await page.locator('#luxarcia-app').waitFor({state:'hidden'});
 assert.deepEqual(errors,[]);
 console.log('PASS integrated browser: 18 advanced panels, TR/EN, five shell themes, persistence, brake approval, mutation/generation sync, native sample charts, AI disabled, cleanup');
 }finally{await browser.close();server.close();}
})().catch(e=>{console.error(e);process.exitCode=1;server.close();});
