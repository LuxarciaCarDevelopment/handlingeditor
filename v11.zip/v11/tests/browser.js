'use strict';
// Isolated browser fixtures. No simulated data is bundled with the FiveM resource.
const {chromium}=require('playwright'),http=require('node:http'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const schema=require('../web/schema.json'),Core=require('../web/core');
const values=Object.fromEntries(schema.map(s=>[s.field,s.type==='vector'?{x:1,y:1,z:1}:s.rule==='bias'?.5:s.rule==='gears'?6:1]));
Object.assign(values,{fMass:1500,fInitialDragCoeff:8,fInitialDriveForce:.3,fBrakeForce:.8,fTractionCurveMax:2.5,fTractionCurveMin:2.2,fSteeringLock:35,fSuspensionLowerLimit:-.1,fSuspensionUpperLimit:.1,vecCentreOfMassOffset:{x:0,y:0,z:-.1}});
const copy=x=>JSON.parse(JSON.stringify(x));let state={generation:1,model:'123',name:'TEST VEHICLE',class:7,values:copy(values),original:copy(values),history:[{values:copy(values),label:'original'}],cursor:1};
let library={version:2,presets:{},backups:{},reports:{},runs:{},feedback:{},history:{}},calls=[],nextRunSamples=null;
const delays=new Map();
function hold(action){let release,received;const pending=new Promise(resolve=>{release=resolve;}),seen=new Promise(resolve=>{received=resolve;});delays.set(action,{pending,received});return {release,seen};}
const flags={ai:true,smart:true,telemetry:true,tests:true,presets:true,interval:100,historyLimit:100};
const samples=[{time:0,speed:0,x:0,y:0,z:0,longG:0,latG:0,acceleration:0,distance:0,rpm:0,gear:1},{time:100,speed:10,x:0,y:1,z:0,longG:.2,latG:.1,acceleration:2,distance:1,rpm:.4,gear:1}];
const server=http.createServer((req,res)=>{const clean=decodeURIComponent(req.url.split('?')[0]);const file=path.join(__dirname,'../web',clean==='/'?'tools.html':clean);if(!file.startsWith(path.resolve(__dirname,'../web'))){res.writeHead(403).end();return;}try{res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':file.endsWith('.json')?'application/json':'text/html');res.end(fs.readFileSync(file));}catch{res.writeHead(404).end();}});
(async()=>{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
 try{
 const page=await browser.newPage({viewport:{width:1536,height:1024}}),errors=[];page.on('pageerror',error=>errors.push(error.message));
 await page.addInitScript(()=>{window.GetParentResourceName=()=> 'luxarcia-test';});
 await page.route('https://luxarcia-test/action',async route=>{
  const d=route.request().postDataJSON();calls.push(d);let result={ok:true};
  const delay=delays.get(d.action);if(delay){delays.delete(d.action);delay.received();await delay.pending;}
  if(d.action==='load')result.data=library;
  if(d.action==='save')library=copy(d.data);
  if(d.action==='saveHistory')library.history=copy(d.history);
  if(d.action==='apply'){Core.validate(d.values,schema);Object.assign(state.values,d.values);state.history=state.history.slice(0,state.cursor);state.history.push({values:copy(state.values),label:d.label});state.cursor=state.history.length;result.state=state;}
  if(d.action==='history'){state.cursor=d.index;state.values=copy(state.history[d.index-1].values);result.state=state;}
  if(d.action==='telemetry')result.active=d.enabled;
  if(d.action==='run'){Object.assign(result,{samples:nextRunSamples??samples,results:{maxSpeed:10},laps:[],checkpoints:[]});nextRunSamples=null;}
  if(d.action==='lap')Object.assign(result,{checkpoints:[{x:0,y:0,z:0}],laps:[]});
  if(d.action==='ai')Object.assign(result,{explanation:'Test-only response',changes:{fBrakeForce:1.1}});
  if(d.action==='recover')result.data=library;
  await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(result)});
 });
 await page.goto(`http://127.0.0.1:${server.address().port}`);
 assert(await page.locator('#app').isHidden());
 const open=()=>page.evaluate(({state,flags})=>window.postMessage({type:'open',state,flags},'*'),{state,flags});await open();await page.locator('#app').waitFor({state:'visible'});
 assert.equal(await page.locator('#nav button').count(),22);
 assert.equal(await page.evaluate(()=>getComputedStyle(document.body).backgroundColor),'rgba(0, 0, 0, 0)');
 for(let panel=0;panel<22;panel++){await page.locator(`[data-panel="${panel}"]`).click();assert((await page.locator('#content').innerText()).length>10);assert(!(await page.locator('#content').innerText()).includes('undefined'));}
 await page.locator('[data-panel="1"]').click();
 assert.equal(await page.locator('.field').count(),46);
 await page.locator('input[type=number][data-field=fMass]').fill('1600');await page.locator('input[type=number][data-field=fMass]').press('Tab');await page.waitForFunction(()=>document.querySelector('#status').textContent.includes('Applied'));
 assert.equal(state.values.fMass,1600);
 await page.locator('#undo').click();await page.waitForFunction(()=>document.querySelector('input[type=number][data-field=fMass]').value==='1500');
 await page.locator('#redo').click();await page.waitForFunction(()=>document.querySelector('input[type=number][data-field=fMass]').value==='1600');
 await page.locator('[data-panel="2"]').click();const count=calls.filter(c=>c.action==='apply').length;await page.locator('[data-action=tune]').click();await page.locator('#proposal').waitFor({state:'visible'});assert.equal(calls.filter(c=>c.action==='apply').length,count);await page.locator('#reject').click();assert.equal(calls.filter(c=>c.action==='apply').length,count);
 await page.locator('[data-action=tune]').click();await page.locator('#approve').click();await page.waitForFunction(()=>document.querySelector('#status').textContent.includes('Applied'));assert(calls.filter(c=>c.action==='apply').length>count);
 await page.locator('[data-panel="16"]').click();await page.locator('[data-action=newPreset]').click();await page.locator('#modal-name').fill('<img src=x onerror=alert(1)>');await page.locator('#approve').click();await page.waitForFunction(()=>document.querySelector('#content').textContent.includes('<img src=x'));assert.equal(await page.locator('#content img').count(),0);assert.equal(library.presets.length,1);
 await page.locator('[data-panel="1"]').click();const xml=Core.xmlExport(values,schema);await page.locator('#import-text').fill(xml);await page.locator('[data-action=import]').click();await page.locator('#proposal').waitFor({state:'visible'});await page.locator('#reject').click();
 await page.locator('#import-text').fill('<!DOCTYPE foo [<!ENTITY x SYSTEM "file:///secret">]><fMass value="2"/>');await page.locator('[data-action=import]').click();await page.waitForFunction(()=>document.querySelector('#status').textContent.includes('unsafe XML'));assert(!(await page.locator('#proposal').isVisible()));
 await page.locator('[data-panel="18"]').click();await page.locator('#ai-prompt').fill('Test advice');await page.locator('[data-kind=ask]').click();await page.locator('#proposal').waitFor({state:'visible'});await page.locator('#reject').click();
 await page.evaluate(samples=>{for(const sample of samples)window.postMessage({type:'telemetry',data:{generation:1,active:true,sample,results:{maxSpeed:10},laps:{},checkpoints:{}}},'*');},samples);
 for(const panel of [9,10,11,12,13,14]){await page.locator(`[data-panel="${panel}"]`).click();}
 await page.locator('[data-panel="8"]').click();await page.locator('[data-action=saveRun]').click();await page.locator('#modal-name').fill('Recorded fixture');await page.locator('#approve').click();await page.waitForFunction(()=>document.querySelector('#content').textContent.includes('Recorded fixture'));assert.equal(library.runs.length,1);
 // Readouts update while the panel stays open, and duplicate/stale packets cannot add samples.
 await page.locator('[data-panel="0"]').click();
 await page.evaluate(()=>window.postMessage({type:'telemetry',data:{generation:1,active:true,sample:{time:200,speed:80,rpm:.7,gear:3,x:0,y:3,z:0,distance:3,acceleration:2,longG:.2,latG:.1},results:{maxSpeed:80,peakAcceleration:4,peakBraking:5},laps:{},checkpoints:{}}},'*'));
 await page.waitForFunction(()=>document.querySelector('#dashboard-values').textContent.includes('80.00'));
 await page.locator('[data-panel="7"]').click();
 await page.evaluate(()=>window.postMessage({type:'telemetry',data:{generation:1,active:true,sample:{time:300,speed:85,rpm:.8,gear:4,x:0,y:4,z:0,distance:4,acceleration:2,longG:.2,latG:.1},results:{maxSpeed:85},laps:{},checkpoints:{}}},'*'));
 await page.waitForFunction(()=>document.querySelector('#gear-values').textContent.includes('0.800'));
 const beforeDuplicate=await page.evaluate(()=>S.samples.length);
 await page.evaluate(()=>{window.postMessage({type:'telemetry',data:{generation:1,sample:{time:300,speed:999}}},'*');window.postMessage({type:'telemetry',data:{generation:0,sample:{time:400,speed:999}}},'*');});
 await page.waitForTimeout(20);assert.equal(await page.evaluate(()=>S.samples.length),beforeDuplicate);
 assert.equal(await page.evaluate(()=>S.telemetry.sample.time),300);
 // The next vector component is built only after the preceding native reply is applied.
 await page.locator('[data-panel="1"]').click();const vectorHold=hold('apply');
 await page.evaluate(()=>{for(const [axis,value]of [['x','.1'],['y','.2']]){const el=document.querySelector(`input[type=number][data-field=vecCentreOfMassOffset][data-axis=${axis}]`);el.value=value;el.dispatchEvent(new Event('change',{bubbles:true}));}});
 await vectorHold.seen;vectorHold.release();await page.waitForFunction(()=>S.state.values.vecCentreOfMassOffset.y===.2);assert.equal(state.values.vecCentreOfMassOffset.x,.1);
 // Backups, preset CRUD and the export fallback each preserve actual saved values.
 await page.locator('[data-panel="16"]').click();await page.locator('[data-action=backup]').click();await page.locator('#modal-name').fill('Backup fixture');await page.locator('#approve').click();await page.waitForFunction(()=>S.library.backups.length===1);
 const backupMass=library.backups[0].values.fMass;
 await page.locator('[data-action=duplicateEntry][data-group=presets]').first().click();await page.locator('#modal-name').fill('Duplicate fixture');await page.locator('#approve').click();await page.waitForFunction(()=>S.library.presets.length===2);
 await page.locator('[data-action=renameEntry][data-group=presets]').last().click();await page.locator('#modal-name').fill('Renamed fixture');await page.locator('#approve').click();await page.waitForFunction(()=>S.library.presets.at(-1).name==='Renamed fixture');
 await page.locator('[data-action=exportEntry][data-group=backups]').click();await page.locator('#proposal').waitFor({state:'visible'});assert.equal(JSON.parse(await page.locator('#export-text').inputValue()).values.fMass,backupMass);await page.locator('#reject').click();
 await page.locator('[data-panel="1"]').click();await page.locator('input[type=number][data-field=fMass]').fill('1700');await page.locator('input[type=number][data-field=fMass]').press('Tab');await page.waitForFunction(()=>S.state.values.fMass===1700);
 await page.locator('[data-panel="16"]').click();await page.locator('[data-action=loadEntry][data-group=backups]').click();await page.locator('#approve').click();await page.waitForFunction(mass=>S.state.values.fMass===mass,backupMass);
 await page.locator('[data-action=deleteEntry][data-group=presets]').last().click();await page.locator('#approve').click();await page.waitForFunction(()=>S.library.presets.length===1);
 // An empty Lua run table yields an explicit empty result instead of a broken dialog.
 await page.locator('[data-panel="8"]').click();nextRunSamples={};await page.locator('[data-action=saveRun]').click();await page.waitForFunction(()=>document.querySelector('#status').textContent.includes('No recorded data'));assert(!(await page.locator('#proposal').isVisible()));
 const runHold=hold('run');await page.locator('[data-action=saveRun]').click();await runHold.seen;
 // Move to another vehicle while the old run reply is pending.
 state={generation:2,model:'456',name:'SECOND VEHICLE',class:6,values:copy(values),original:copy(values),history:[{values:copy(values),label:'original'}],cursor:1};
 const preservedPresets=library.presets.length,loadHold=hold('load');await open();await loadHold.seen;
 runHold.release();await page.waitForTimeout(20);assert(!(await page.locator('#proposal').isVisible()));
 await page.locator('[data-panel="16"]').click();await page.locator('[data-action=newPreset]').click();await page.locator('#modal-name').fill('Second vehicle fixture');await page.locator('#approve').click();
 const savesBeforeLoad=calls.filter(c=>c.action==='save').length;await page.waitForTimeout(20);assert.equal(calls.filter(c=>c.action==='save').length,savesBeforeLoad);
 loadHold.release();await page.waitForFunction(n=>S.library.presets.length===n,preservedPresets+1);assert.equal(library.presets.length,preservedPresets+1);
 assert.equal(await page.evaluate(()=>S.samples.length),0);assert.equal(await page.evaluate(()=>S.aiText),'');
 // An old AI response has no state payload: it still must never open a proposal on a new vehicle.
 await page.locator('[data-panel="18"]').click();const aiHold=hold('ai');await page.locator('[data-kind=ask]').click();await aiHold.seen;
 state={...state,generation:3,model:'789',name:'THIRD VEHICLE',values:copy(values),original:copy(values),history:[{values:copy(values),label:'original'}],cursor:1};
 await open();await page.waitForFunction(()=>S.state.generation===3);aiHold.release();await page.waitForTimeout(50);assert(!(await page.locator('#proposal').isVisible()));assert.equal(await page.evaluate(()=>S.aiText),'');
 // Native snapshots restore recordings after reopening or a NUI reload, with no duplicate last sample.
 await page.evaluate(({state,flags,samples})=>window.postMessage({type:'open',state,flags,telemetry:{generation:state.generation,active:true,samples,sample:samples.at(-1),results:{maxSpeed:10},laps:{},checkpoints:{}}},'*'),{state,flags,samples});
 await page.waitForFunction(()=>S.samples.length===2&&S.recording);await page.locator('[data-panel="9"]').click();assert.equal(await page.locator('[data-action=record]').innerText(),'Stop recording');
 await page.locator('[data-action=resetStats]').click();await page.waitForFunction(()=>S.samples.length===0&&!Object.keys(S.telemetry.results||{}).length);assert.equal(await page.locator('#telemetry').count(),0);
 assert.deepEqual(Core.dyno([{speed:36,acceleration:Infinity}],1500),[]);assert.deepEqual(Core.dyno(samples,NaN),[]);
 assert.equal(Core.ghost(samples,[...samples.slice(0,1),{...samples[1],invalid:true}]).invalid,true);
 for(const lang of ['tr','en']){await page.locator('#language').selectOption(lang);for(const theme of ['Emerald','Neon','Midnight','Sunset','Arctic']){await page.locator('#theme').selectOption(theme);assert.equal(await page.evaluate(()=>getComputedStyle(document.body).backgroundColor),'rgba(0, 0, 0, 0)');}}
 await page.locator('#theme').selectOption('Neon');await page.locator('[data-panel="0"]').click();fs.mkdirSync('test-results',{recursive:true});await page.screenshot({path:'test-results/dashboard-fixture.png'});
 await page.setViewportSize({width:960,height:720});assert(await page.locator('#close').isVisible());assert(await page.locator('#content').evaluate(el=>el.scrollWidth<=el.clientWidth+1));await page.screenshot({path:'test-results/compact-fixture.png'});
 await page.keyboard.press('Escape');await page.locator('#app').waitFor({state:'hidden'});for(let i=0;i<3;i++){await open();await page.locator('#app').waitFor({state:'visible'});await page.locator('#close').click();await page.locator('#app').waitFor({state:'hidden'});}
 assert.deepEqual(errors,[]);console.log('PASS browser: 22 panels, 46 editors, serial vector edits, undo/redo, XML, XSS, preset/backup CRUD and exports, live readouts, Lua empty arrays, stale run/AI replies, load/save race, snapshot recovery, five themes, TR/EN, responsive transparency and reopen');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(()=>server.close());

