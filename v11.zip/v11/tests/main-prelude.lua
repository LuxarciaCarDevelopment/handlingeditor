-- Client integration test doubles; no code from this file ships in the resource.
commands={}; callbacks={}; focus=false; messages={}; delayedAuth=false; deniedAuthorization=false; waitingReplies={}
local responseFlags={ai=false,smart=true,telemetry=true,tests=true,presets=true,interval=100,historyLimit=100,restore=true}
promise={new=function()return {resolve=function(self,value)self.value=value end}end}
Citizen={Await=function(p)if not p.value then coroutine.yield(p)end return p.value end}
function RegisterCommand(name,fn)commands[name]=fn end
function RegisterNUICallback(name,fn)callbacks[name]=fn end
function SetNuiFocus(hasFocus)focus=hasFocus end
function SendNUIMessage(message)lastMessage=message;messages[#messages+1]=message end
function TriggerEvent()end
function GetCurrentResourceName()return 'luxarcia_test' end
function TriggerServerEvent(name,id,action,payload)
 lastServerAction=action
 local result={ok=true}
 if action=='authorize'then
    result.ok=not deniedAuthorization
  result.flags=responseFlags
  if delayedAuth then waitingReplies[#waitingReplies+1]={id=id,result=result};return end
 elseif action=='validate'then
  local values,err=ValidateHandlingChanges(payload.values);result={ok=values~=nil,values=values,error=err}
 elseif action=='load'then result.data=nil end
 local old=source;source=65535;events['luxarcia:reply'](id,result);source=old
end
function TriggerLatentServerEvent(name,bps,id,action,payload)
 assert(bps==500000);lastLatentAction=action;TriggerServerEvent(name,id,action,payload)
end
function resumeLatest()
 local thread=threads[#threads];local ok,err=coroutine.resume(thread);assert(ok,err);return thread
end
function callback(name,data)
 local result
 assert(callbacks[name], 'missing NUI callback: '..name)
 callbacks[name](data or {},function(value)result=value end)
 return result
end
