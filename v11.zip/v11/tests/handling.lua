assert(#HandlingSchema==46)
nativeValues=baseValues();Handling.capture(1)
assert(Handling.apply({fMass=1500},'unchanged').ok and #Handling.history==1)
for _,spec in ipairs(HandlingSchema)do
 local original=deepcopy(Handling.values[spec.field]);local change
 if spec.type=='vector'then change={x=2,y=2,z=2}
 elseif spec.rule=='bias' or spec.rule=='driveBias'then change=.6
 elseif spec.field=='fSuspensionLowerLimit'then change=-.2
 else change=original+1 end
 local result=Handling.apply({[spec.field]=change},'test')
 assert(result.ok,spec.field..':'..tostring(result.error))
 assert(Handling.matches(Handling.values[spec.field],change),spec.field)
 assert(Handling.apply({[spec.field]=original},'restore').ok)
end
assert(not ValidateHandling({unknown=1},true))
assert(not ValidateHandling({fMass=0/0},true))
assert(not ValidateHandling({fBrakeBiasFront=1.1},true))
assert(not ValidateHandling({nInitialDriveGears=2.5},true))
assert(not ValidateHandlingChanges({nInitialDriveGears=8}))
assert(ValidateHandling({nInitialDriveGears=8},true))
assert(not ValidateHandling({fDriveBiasFront=.05},true))
assert(not ValidateHandling({fDriveBiasFront=.95},true))
assert(not ValidateHandling({fPercentSubmerged=0},true))
assert(not ValidateHandling({fSteeringLock=0},true))
assert(not ValidateHandling({vecCentreOfMassOffset={x=1,y=1,z=1,w=1}},true))
reject='fMass';local before=Handling.values.fMass
assert(not Handling.apply({fMass=before+100}).ok);assert(Handling.values.fMass==before);reject=nil
assert(Handling.apply({fMass=before+1},'control-test').ok)
assert(Handling.undo().ok)
local valuesBeforeControlLoss=deepcopy(Handling.values)
local nativeBeforeControlLoss=deepcopy(nativeValues)
local generationBeforeControlLoss=Handling.generation
local cursorBeforeControlLoss=Handling.cursor
local undoCountBeforeControlLoss=#Handling.undoHistory
local redoCountBeforeControlLoss=#Handling.redoHistory
local historyCountBeforeControlLoss=#Handling.history
owner=false
assert(Handling.apply({fMass=1600}).error=='noControl')
assert(Handling.undo().error=='noControl')
assert(Handling.redo().error=='noControl')
assert(Handling.resetField('fMass').error=='noControl')
assert(Handling.resetAll().error=='noControl')
assert(Handling.restore().error=='noControl')
for fieldName,value in pairs(valuesBeforeControlLoss)do assert(Handling.matches(Handling.values[fieldName],value),fieldName)end
for fieldName,value in pairs(nativeBeforeControlLoss)do assert(Handling.matches(nativeValues[fieldName],value),fieldName)end
assert(Handling.generation==generationBeforeControlLoss)
assert(Handling.cursor==cursorBeforeControlLoss and #Handling.history==historyCountBeforeControlLoss)
assert(#Handling.undoHistory==undoCountBeforeControlLoss and #Handling.redoHistory==redoCountBeforeControlLoss)
owner=true
vehicle=2;assert(not Handling.apply({fMass=1600}).ok);vehicle=1
assert(not Handling.apply({fSuspensionUpperLimit=-1}).ok)
Handling.limit=3;for i=1,8 do assert(Handling.apply({fMass=1500+i}).ok)end
assert(#Handling.history==3 and Handling.cursor==3)
Handling.restore();assert(nativeValues.fMass==1500)
-- Leaving an untouched 8-gear vehicle must never send its original through the native's 7-gear cap.
nativeValues=baseValues();nativeValues.nInitialDriveGears=8;Handling.capture(1)
local originalWrite=SetVehicleHandlingInt
SetVehicleHandlingInt=function(v,c,f,x)assert(f~='nInitialDriveGears','untouched gear write');originalWrite(v,c,f,x)end
assert(Handling.apply({fMass=1650}).ok);Handling.restore();assert(nativeValues.nInitialDriveGears==8)
assert(Handling.apply(Handling.original,'reset').ok)
assert(not Handling.apply({nInitialDriveGears=7}).ok)
reject='fMass';assert(not Handling.apply({fMass=1750}).ok);reject=nil
assert(nativeValues.nInitialDriveGears==8)
SetVehicleHandlingInt=originalWrite
print('PASS Lua: 46 native routes, validation, rollback, stale driver, control, history cap, reset')
