local P=Performance
function GetVehicleBodyHealth() return 900 end
nativeValues=baseValues();assert(Handling.capture(1));frame={speed=0,x=0,y=0,z=0};now=0
assert(not P.arm('invented').ok)
assert(P.arm('accel100').ok);P.sample()
for i=1,50 do now=i*100;frame.speed=i*2;frame.y=frame.y+frame.speed/3.6*.1;P.sample() end
assert(P.snapshot().test.status=='complete');assert(math.abs(P.results.accel100.seconds-5)<0.001)
assert(P.results.accel100.measured and P.results.accel100.values.fMass==1500)
assert(P.samples[#P.samples].longG>0 and P.samples[#P.samples].bodyHealth==900)
local run=P.run();run.samples[1].speed=500;assert(P.samples[1].speed==0)
P.reset();frame.speed=0;assert(P.arm('accel200').ok);P.sample()
frame.collision=true;now=now+100;P.sample();assert(P.snapshot().test.status=='invalid');frame.collision=false
P.reset();frame.speed=110;assert(P.arm('brake').ok);P.sample()
for i=1,110 do now=now+100;frame.speed=110-i;frame.y=frame.y+frame.speed/3.6*.1;P.sample() end
assert(P.results.brake and math.abs(P.results.brake.seconds-9.95)<.001)
P.reset();frame.speed=0;assert(P.arm('drag').ok);P.sample()
for i=1,250 do now=now+100;frame.speed=72;frame.y=frame.y+2;P.sample() end
assert(P.results.drag and math.abs(P.results.drag.metres-400)<.001)
P.reset();frame.speed=0;assert(P.arm('accel100').ok);P.sample();now=now+1000;P.sample();assert(P.snapshot().test.status=='invalid')
P.reset();assert(P.start().ok);P.sample();owner=false;P.sample();assert(not P.active);owner=true
P.reset();assert(P.start().ok);P.sample();frame.y=frame.y+1000;now=now+100;P.sample();assert(P.samples[#P.samples].invalid)
P.reset();assert(P.start().ok);frame.speed=0
for i=1,1202 do now=now+100;P.sample() end
assert(#P.samples==1200 and not P.active)
P.reset();frame={speed=0,x=0,y=0,z=0};assert(P.lapCommand('checkpoint').ok)
frame.y=100;assert(P.lapCommand('checkpoint').ok);assert(P.lapCommand('start').ok)
local function gate(t,y) P.lapSample({time=t,x=0,y=y,z=0,invalid=false},nil) end
-- Ordered gates: 1 starts, 2 follows, then 1 finishes.
gate(1000,0);gate(2000,100);gate(5000,0)
assert(#P.laps==1 and P.laps[1].seconds==4 and not P.laps[1].invalid)
P.lapCommand('invalidate');gate(6000,100);gate(9000,0);assert(P.laps[2].invalid)
assert(not P.lapCommand('unknown').ok)
print('PASS Lua: native acceleration/braking/drag calculations, invalid runs, G smoothing, bounded traces, ordered laps and invalid laps')
