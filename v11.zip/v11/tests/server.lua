Config.AllowedDiscordIDs={'123456789012345678'}
local latentReplies=0
function TriggerLatentClientEvent(name,src,bps,id,data)
 assert(name=='luxarcia:reply' and bps==500000)
 latentReplies=latentReplies+1;TriggerClientEvent(name,src,id,data)
end
local function req(src,action,payload)
 source=src;now=now+1001;events['luxarcia:request'](1,action,payload or {});return replies[#replies].data
end
assert(not req(2,'authorize').ok)
assert(req(1,'authorize').ok)
assert(not req(1,'validate',{values={nInitialDriveGears=8}}).ok)
assert(req(1,'authorize').flags.ai==false)
assert(not req(1,'validate',{values={evil=12}}).ok)
assert(req(1,'validate',{values={fMass=1500}}).ok)
local library={version=2,presets={{id='one',name='Test',values=baseValues()}},backups={},reports={},runs={},feedback={}}
assert(req(1,'save',{data=library}).ok)
assert(req(1,'load').data.presets[1].name=='Test')
assert(type(req(1,'load').data.history)=='table')
assert(latentReplies==2)
assert(not req(2,'load').ok)
local invalidLibraryCases=0
local function invalidLibrary(change)
 invalidLibraryCases=invalidLibraryCases+1
 local candidate=deepcopy(library);change(candidate)
 local result=req(1,'save',{data=candidate})
 assert(not result.ok,'invalid library case '..invalidLibraryCases..' accepted')
end
invalidLibrary(function(data)data.presets[1].values.fMass=-10 end)
invalidLibrary(function(data)data.presets[1].model={} end)
invalidLibrary(function(data)data.presets[3]=deepcopy(data.presets[1]) end)
invalidLibrary(function(data)data.backups={deepcopy(data.presets[1])} end)
invalidLibrary(function(data)data.history={{label='Bad archive',values={fMass=1500}}} end)
invalidLibrary(function(data)data.presets[1].cycle=data end)
local run={id='run-one',name='Recorded test',model='123',values=baseValues(),
 samples={{time=1000,speed=0,x=1,y=1,z=1,distance=0,acceleration=0,rpm=.5,invalid=false,entityInvalid=false},
 {time=1100,speed=10,x=1,y=2,z=1,distance=1,acceleration=2,rpm=.6,invalid=false,entityInvalid=false}},
 results={maxSpeed=100,peakAcceleration=2,peakBraking=3,
 accel100={kind='accel100',seconds=5,metres=100,maxSpeed=100,measured=true,values=baseValues()}},
 setupChanges={{time=1050,values=baseValues()}},laps={{seconds=60,invalid=false}},checkpoints={{x=1,y=2,z=3}}}
library.runs={run}
local report={id='report-one',name='Report',version=2,values=baseValues(),original=baseValues(),
 history={{label='original',time=0,model='123',values=baseValues()}},recordedResults=deepcopy(run.results),
 savedResults={{name=run.name,results=deepcopy(run.results)}},notes='Measured session',aiExplanation='',limitations='Estimates are labelled'}
library.reports={report}
library.feedback={{id='vote-one',name='Race',style='Race',model='123',vote=1,values=baseValues()}}
assert(req(1,'save',{data=library}).ok)
assert(req(1,'load').data.runs[1].results.accel100.seconds==5)
local archive={{label='Manual edit',time=100,model='123',values=baseValues()}}
assert(req(1,'saveHistory',{history=archive}).ok)
local archived=req(1,'load').data
assert(archived.history[1].label=='Manual edit' and archived.runs[1].results.accel100.seconds==5 and archived.presets[1].name=='Test')
assert(req(1,'recover').data.history[1]==nil,'History save should preserve previous full library snapshot')
assert(not req(1,'saveHistory',{history={{label='Bad archive',values={fMass=1500}}}}).ok)
assert(not req(1,'saveHistory',{history=string.rep('x',100)}).ok)
assert(not req(2,'saveHistory',{history=archive}).ok)
local historyLimit=Config.HistoryLimit
Config.HistoryLimit=1
assert(not req(1,'saveHistory',{history={archive[1],archive[1]}}).ok)
Config.HistoryLimit=historyLimit
local originalEncode=json.encode
json.encode=function()return false end
assert(not req(1,'save',{data=library}).ok)
json.encode=function()error('encoder failed')end
assert(not req(1,'save',{data=library}).ok)
json.encode=originalEncode
invalidLibrary(function(data)data.runs[1].results.maxSpeed={} end)
invalidLibrary(function(data)data.runs[1].results.accel100.seconds=-1 end)
invalidLibrary(function(data)data.runs[1].results.accel100.measured='yes' end)
invalidLibrary(function(data)data.runs[1].results.accel100.values=nil end)
invalidLibrary(function(data)data.runs[1].results.arbitrary=123 end)
invalidLibrary(function(data)data.runs[1].samples[2].time=1000 end)
invalidLibrary(function(data)data.runs[1].samples[1].invalid='false' end)
invalidLibrary(function(data)data.runs[1].samples[1].rpm=math.huge end)
invalidLibrary(function(data)data.runs[1].setupChanges[1].values={fMass=1500} end)
invalidLibrary(function(data)data.runs[1].laps[1].seconds=-1 end)
invalidLibrary(function(data)data.runs[1].checkpoints[1].z={} end)
invalidLibrary(function(data)data.reports[1].recordedResults.accel100='bad' end)
invalidLibrary(function(data)data.reports[1].savedResults[1].results='bad' end)
invalidLibrary(function(data)data.reports[1].values={} end)
invalidLibrary(function(data)data.feedback[1].vote=0 end)
local key='luxarcia:v2:discord:123456789012345678'
local goodBackup=kvp[key..':previous']
kvp[key]='corrupt JSON'
local corruptLoad=req(1,'load')
assert(corruptLoad.error=='invalidStorage','corrupt load returned '..tostring(corruptLoad.error)..' / '..tostring(corruptLoad.ok))
assert(req(1,'saveHistory',{history=archive}).error=='invalidStorage')
assert(kvp[key]=='corrupt JSON','History writes must not overwrite an invalid current library')
local recoveredLibrary=req(1,'recover')
assert(recoveredLibrary.ok,'recovery failed: '..tostring(recoveredLibrary.error))
assert(recoveredLibrary.data and recoveredLibrary.data.presets and recoveredLibrary.data.presets[1]
 and recoveredLibrary.data.presets[1].name=='Test','recovery preset missing: '..tostring(recoveredLibrary.data and recoveredLibrary.data.presets))
assert(req(1,'save',{data=library}).ok)
assert(kvp[key..':previous']==goodBackup,'A corrupt primary must not replace the known-good recovery snapshot')
kvp[key]=json.encode({version=2,presets='bad',backups={},reports={},runs={},feedback={}})
assert(req(1,'load').error=='invalidStorage')
kvp[key..':previous']='corrupt recovery JSON'
assert(req(1,'recover').error=='invalidStorage')
kvp[key..':previous']=nil
assert(req(1,'recover').error=='empty')
local storageLimit=Config.MaxStorageBytes
Config.MaxStorageBytes=20;kvp[key]=string.rep('x',21)
assert(req(1,'load').error=='invalidStorage')
Config.MaxStorageBytes=storageLimit
kvp[key]=nil
assert(req(1,'load').ok and req(1,'load').data==nil)
assert(req(1,'saveHistory',{history=archive}).ok)
assert(req(1,'load').data.history[1].label=='Manual edit')
Config.EnablePresets=false
local disabledRecover=req(1,'recover')
assert(disabledRecover.error=='disabled','recover feature gate returned '..tostring(disabledRecover.error))
assert(req(1,'save',{data=library}).error=='disabled')
assert(req(1,'saveHistory',{history=archive}).error=='disabled')
Config.EnablePresets=true
assert(not req(1,'ai',{values=baseValues(),prompt='test'}).ok)
Config.EnableAI=true
local originalConvar=GetConvar
GetConvar=function(name,default) if name=='luxarcia_ai_enabled' then return 'true' end return originalConvar(name,default) end
req(1,'ai',{values=baseValues(),prompt='test',language='en'})
assert(http and http.headers.Authorization=='Bearer SERVER_SECRET_TEST')
http.cb(200,json.encode({choices={{message={content=json.encode({explanation='Test',changes={unknown=4}})}}}}))
assert(replies[#replies].data.error=='aiInvalid')
-- Every untrusted level of the HTTP envelope must be type-checked before indexing.
for _,envelope in ipairs({{choices=true},{choices=1},{choices='wrong'},
 {choices={true}},{choices={3}},{choices={'wrong'}},{choices={{message=true}}},
 {choices={{message=3}}},{choices={{message={content={}}}}},
 {choices={{message={content=json.encode({explanation='Bad',changes='wrong'})}}}},
 {choices={{message={content=json.encode({explanation='Bad',changes={},extra='wrong'})}}}}}) do
 now=now+20000
 req(1,'ai',{values=baseValues(),prompt='test'})
 local count=#replies
 local ok,err=pcall(http.cb,200,json.encode(envelope))
 assert(ok,err)
 assert(#replies==count+1 and replies[#replies].data.error=='aiInvalid')
end
now=now+20000
req(1,'ai',{values=baseValues(),prompt='test'})
http.cb(200,json.encode({choices={{message={content=json.encode({explanation='Chat reply',changes={}})}}}}))
assert(replies[#replies].data.ok and next(replies[#replies].data.changes)==nil)
now=now+20000
req(1,'ai',{values=baseValues(),prompt='test'})
http.cb(200,json.encode({choices={{message={content=json.encode({explanation='Proposed change',changes={fMass=1800}})}}}}))
assert(replies[#replies].data.ok and replies[#replies].data.changes.fMass==1800)
-- Invalid HTTP responses free the busy slot, and callbacks reply only once.
now=now+20000
req(1,'ai',{values=baseValues(),prompt='test'})
local failureCallback=http.cb
failureCallback(503,'unavailable')
assert(replies[#replies].data.error=='aiUnavailable')
local failureCount=#replies
failureCallback(200,json.encode({choices={{message={content=json.encode({explanation='Duplicate',changes={}})}}}}))
assert(#replies==failureCount)
now=now+20000
local originalTimeout=SetTimeout
Config.AITimeout=60000
SetTimeout=function(ms,fn)assert(ms==20000);originalTimeout(ms,fn)end
req(1,'ai',{values=baseValues(),prompt='test'})
SetTimeout=originalTimeout;Config.AITimeout=20000
local callback=http.cb
timeouts[#timeouts]()
assert(replies[#replies].data.error=='aiTimeout')
local count=#replies
callback(200,json.encode({choices={{message={content=json.encode({explanation='Late',changes={fMass=1800}})}}}}))
assert(#replies==count)
-- A disconnected player's HTTP callback cannot be delivered to a reused source.
now=now+20000
req(1,'ai',{values=baseValues(),prompt='test'})
callback=http.cb;source=1;events.playerDropped();count=#replies
callback(200,json.encode({choices={{message={content=json.encode({explanation='Disconnected',changes={}})}}}}))
assert(#replies==count)
print('PASS Lua: authorization, storage schemas, corruption/recovery, malformed AI envelopes, one-shot replies and disconnect/timeout cleanup')
