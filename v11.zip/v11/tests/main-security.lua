nativeValues=baseValues()

local function callNui(name, payload)
 local result
 assert(callbacks[name], 'missing NUI callback: '..name)
 callbacks[name](payload or {},function(value)result=value end)
 return result
end

local function assertRejected(name, payload, expectedError)
 local result=callNui(name,payload)
 assert(type(result)=='table' and result.ok==false and result.error==expectedError,
  name..' returned '..tostring(result and result.error))
end

assertRejected('applyHandling',{values={fMass=1600}},'unauthorized')
commands.handling(0)
assert(focus and lastMessage.action=='openEditor' and Handling.vehicle==1)
assert(lastServerAction=='authorize')
assert(callNui('applyHandling',{generation=Handling.generation,values={fMass=1600}}).ok)
assert(callNui('undoHandling',{}).ok)

local valuesBefore=deepcopy(Handling.values)
local nativeBefore=deepcopy(nativeValues)
local generationBefore=Handling.generation
local historyBefore=#Handling.history
local cursorBefore=Handling.cursor
local undoBefore=#Handling.undoHistory
local redoBefore=#Handling.redoHistory
owner=false
assertRejected('applyHandling',{generation=Handling.generation,values={fMass=1700}},'noControl')
assertRejected('undoHandling',{},'noControl')
assertRejected('redoHandling',{},'noControl')
assertRejected('resetField',{fieldName='fMass'},'noControl')
assertRejected('resetAll',{},'noControl')
for fieldName,value in pairs(valuesBefore)do assert(Handling.matches(Handling.values[fieldName],value),fieldName)end
for fieldName,value in pairs(nativeBefore)do assert(Handling.matches(nativeValues[fieldName],value),fieldName)end
assert(Handling.generation==generationBefore)
assert(#Handling.history==historyBefore and Handling.cursor==cursorBefore)
assert(#Handling.undoHistory==undoBefore and #Handling.redoHistory==redoBefore)

owner=true
vehicle=2
assertRejected('resetField',{fieldName='fMass'},'staleVehicle')
vehicle=1
callNui('closeEditor',{})
assert(not focus)
assertRejected('applyHandling',{values={fMass=1800}},'unauthorized')

deniedAuthorization=true
commands.handling(0)
assert(not focus)
assertRejected('resetAll',{},'unauthorized')
deniedAuthorization=false

events.onResourceStop('luxarcia_test')
assert(nativeValues.fMass==1500)
print('PASS Lua: authorized NUI session, captured vehicle identity, no-control rejection for every callback, unchanged state/history, and authorized cleanup')