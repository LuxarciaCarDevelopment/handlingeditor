/* Shared deterministic logic. Browser and Node tests use the same implementation. */
(function(root){
'use strict';
const clone=x=>JSON.parse(JSON.stringify(x));
function validate(values,schema,full=false){
  if(!values||typeof values!=='object'||Array.isArray(values))throw Error('invalidValues');
  const keys=Object.keys(values), map=new Map(schema.map(s=>[s.field,s]));
  if(!keys.length||(full&&keys.length!==schema.length))throw Error('invalidCount');
  const finite=v=>typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<3.4028234e38;
  for(const field of keys){
    const s=map.get(field),v=values[field]; if(!s)throw Error('unknownField:'+field);
    if(s.type==='vector'){
      if(!v||Object.keys(v).sort().join(',')!=='x,y,z'||!['x','y','z'].every(a=>finite(v[a])&&(s.rule!=='positiveVector'||v[a]>0)))throw Error('invalidVector:'+field);
    }else{
      if(!finite(v))throw Error('invalidNumber:'+field);
      if(s.type==='int'&&(!Number.isInteger(v)||v<0||v>2147483647))throw Error('invalidInteger:'+field);
      if((s.rule==='positive'&&v<=0)||(s.rule==='nonnegative'&&v<0)||(s.rule==='bias'&&(v<0||v>1))||(s.rule==='percent'&&(v<=0||v>100))||(s.rule==='driveBias'&&!(v===0||v===1||(v>=.1&&v<=.9)))||(s.rule==='gears'&&(v<1||v>255)))throw Error('invalidRange:'+field);
    }
  }return clone(values);
}
const profiles={
  Race:{fInitialDriveForce:1.08,fDriveInertia:1.04,fClutchChangeRateScaleUpShift:1.05,fClutchChangeRateScaleDownShift:1.05,fBrakeForce:1.08,fTractionCurveMax:1.05,fTractionCurveMin:1.04,fTractionLossMult:.95,fSuspensionForce:1.04,fSuspensionCompDamp:1.03,fSuspensionReboundDamp:1.04,fAntiRollBarForce:1.08},
  Drift:{fInitialDriveForce:1.04,fDriveInertia:1.05,fTractionCurveMin:.90,fTractionCurveMax:.96,fLowSpeedTractionLossMult:1.12,fTractionLossMult:1.08,fSteeringLock:1.08},
  Sport:{fInitialDriveForce:1.05,fDriveInertia:1.03,fBrakeForce:1.05,fTractionCurveMax:1.035,fTractionCurveMin:1.03,fTractionLossMult:.97,fSuspensionForce:1.035,fAntiRollBarForce:1.04},
  Realistic:{fInitialDriveForce:.97,fBrakeForce:1.02,fSteeringLock:.98,fSuspensionForce:1.01,fSuspensionCompDamp:1.03,fSuspensionReboundDamp:1.03,fTractionCurveMax:1.01,fTractionCurveMin:1.01},
  Comfort:{fInitialDriveForce:.94,fDriveInertia:.94,fClutchChangeRateScaleUpShift:.96,fClutchChangeRateScaleDownShift:.96,fSuspensionForce:.94,fSuspensionCompDamp:.93,fSuspensionReboundDamp:.93,fAntiRollBarForce:.96,fSteeringLock:.96}
};
const quick={
  accelUp:{fInitialDriveForce:1.1,fDriveInertia:1.04,fTractionCurveMax:1.025},
  accelDown:{fInitialDriveForce:.9},
  speedUp:{fInitialDriveMaxFlatVel:1.05,fInitialDragCoeff:.97},
  brakeUp:{fBrakeForce:1.1},
  cornering:{fTractionCurveMax:1.05,fTractionCurveMin:1.04,fAntiRollBarForce:1.04},
  drift:profiles.Drift,
  rollover:{fAntiRollBarForce:1.08},
  softer:{fSuspensionForce:.9,fSuspensionCompDamp:.95,fSuspensionReboundDamp:.95},
  stiffer:{fSuspensionForce:1.1,fSuspensionCompDamp:1.05,fSuspensionReboundDamp:1.05},
  improveAcceleration:{fInitialDriveForce:1.08,fDriveInertia:1.04,fTractionCurveMax:1.025},
  increaseTopSpeed:{fInitialDriveMaxFlatVel:1.05,fInitialDragCoeff:.97},
  improveBraking:{fBrakeForce:1.1},
  improveCornering:{fTractionCurveMax:1.05,fTractionCurveMin:1.04,fAntiRollBarForce:1.04},
  reduceWheelspin:{fInitialDriveForce:.96,fLowSpeedTractionLossMult:.9,fTractionCurveMin:1.04},
  improveStability:{fTractionLossMult:.9,fAntiRollBarForce:1.08,fSteeringLock:.96},
  improveSteering:{fSteeringLock:1.04,fTractionCurveLateral:1.03},
  balanceSuspension:{fSuspensionCompDamp:1.04,fSuspensionReboundDamp:1.04,fAntiRollBarForce:1.04}
};
const targetProfiles={
  Drift:{fTractionBiasFront:.48},
  brakeUp:{fBrakeBiasFront:.6},
  improveBraking:{fBrakeBiasFront:.6},
  reduceWheelspin:{fLowSpeedTractionLossMult:.65},
  improveSteering:{fTractionBiasFront:.5}
};
const classFactors={heavy:.82,sport:.94,performance:1.08,motorcycle:.82,offroad:.9,standard:1};
function vehicleCategory(classId){
  const id=Number(classId);
  if([2,10,11,12,17,18,19,20].includes(id))return 'heavy';
  if(id===8)return 'motorcycle';
  if(id===9)return 'offroad';
  if([3,4,5].includes(id))return 'sport';
  if([6,7,22].includes(id))return 'performance';
  return 'standard';
}
function driveLayout(values){
  const bias=values.fDriveBiasFront;
  if(bias===0)return 'rear';
  if(bias===1)return 'front';
  if(Number.isFinite(bias))return 'all';
  return 'unknown';
}
function clampTuned(field,value,schema){
  const spec=schema.find(item=>item.field===field);
  if(!spec)return value;
  if(spec.rule==='positive')return Math.max(.001,value);
  if(spec.rule==='nonnegative')return Math.max(0,value);
  if(spec.rule==='bias')return Math.max(0,Math.min(1,value));
  if(spec.rule==='percent')return Math.max(.01,Math.min(100,value));
  if(spec.rule==='gears')return Math.max(1,Math.min(7,Math.round(value)));
  if(spec.type==='int')return Math.max(0,Math.round(value));
  return value;
}
function tune(values,name,intensity=1,classId, schema=[]){
  const recipe=profiles[name]||quick[name]; if(!recipe)throw Error('unknownAction');
  if(!Number.isFinite(intensity)||intensity<.1||intensity>1)throw Error('invalidRange');
  const category=vehicleCategory(classId);
  const classScale=classFactors[category]||1;
  const layout=driveLayout(values);
  const changes={}; for(const [k,m]of Object.entries(recipe))if(typeof values[k]==='number'){
    let fieldIntensity=intensity*classScale;
    if(name==='Drift'&&['fTractionCurveMin','fTractionCurveMax','fLowSpeedTractionLossMult','fTractionLossMult'].includes(k)){
      fieldIntensity*=layout==='rear'?1:layout==='all'?.68:layout==='front'?.45:1;
    }
    let next=Number((values[k]*(1+(m-1)*fieldIntensity)).toFixed(6));
    // Propose the actual representable drive layout; do not let the native silently snap it after approval.
    if(k==='fDriveBiasFront'){if(next>0&&next<.1)next=0;if(next>.9&&next<1)next=1;}
    changes[k]=clampTuned(k,next,schema);
  }
  const targets=targetProfiles[name]||{};
  for(const [field,target] of Object.entries(targets))if(typeof values[field]==='number'){
    let fieldIntensity=intensity*classScale;
    if(name==='Drift'&&field==='fTractionBiasFront')fieldIntensity*=layout==='rear'?1:layout==='all'?.68:layout==='front'?.45:1;
    changes[field]=clampTuned(field,Number((values[field]+(target-values[field])*fieldIntensity).toFixed(6)),schema);
  }
  if(name==='rollover'&&values.vecCentreOfMassOffset)changes.vecCentreOfMassOffset={...values.vecCentreOfMassOffset,z:Number((values.vecCentreOfMassOffset.z-.03*intensity).toFixed(6))};
  return changes;
}
function diagnose(v){
  const issues=[]; const add=(key,fields,penalty)=>issues.push({key,fields,penalty});
  if(v.fTractionCurveMin>v.fTractionCurveMax)add('tractionConflict',['fTractionCurveMin','fTractionCurveMax'],20);
  if(v.fSuspensionUpperLimit<=v.fSuspensionLowerLimit)add('suspensionConflict',['fSuspensionUpperLimit','fSuspensionLowerLimit'],25);
  if(v.fBrakeBiasFront<.35||v.fBrakeBiasFront>.8)add('brakeBalance',['fBrakeBiasFront'],10);
  if(v.fBrakeForce<.3)add('weakBrakes',['fBrakeForce'],10);
  if(v.fInitialDriveForce<.15)add('poorAcceleration',['fInitialDriveForce'],5);
  if(v.fTractionBiasFront<.45)add('understeerRisk',['fTractionBiasFront'],10);
  if(v.fTractionBiasFront>.55)add('oversteerRisk',['fTractionBiasFront'],10);
  if(v.vecCentreOfMassOffset?.z>.2)add('rolloverRisk',['vecCentreOfMassOffset'],15);
  if(v.fAntiRollBarForce<.2)add('bodyRoll',['fAntiRollBarForce'],5);
  if(v.fTractionCurveMin<1)add('poorTraction',['fTractionCurveMin'],10);
  if(v.fSuspensionCompDamp>v.fSuspensionForce*1.5)add('harshSuspension',['fSuspensionCompDamp'],5);
  if(v.fSteeringLock>45&&v.fInitialDriveMaxFlatVel>180)add('highSpeedRisk',['fSteeringLock','fInitialDriveMaxFlatVel'],10);
  return {issues,score:Math.max(0,100-issues.reduce((s,i)=>s+i.penalty,0))};
}
function optimize(v){
  const c={}; for(const i of diagnose(v).issues){
    const k=i.key;
    if(k==='tractionConflict')c.fTractionCurveMin=v.fTractionCurveMax*.9;
    if(k==='suspensionConflict')c.fSuspensionUpperLimit=v.fSuspensionLowerLimit+.1;
    if(k==='brakeBalance')c.fBrakeBiasFront=.6;
    if(k==='weakBrakes')c.fBrakeForce=.3;
    if(k==='poorAcceleration')c.fInitialDriveForce=.15;
    if(k==='understeerRisk'||k==='oversteerRisk')c.fTractionBiasFront=.5;
    if(k==='rolloverRisk')c.vecCentreOfMassOffset={...v.vecCentreOfMassOffset,z:.1};
    if(k==='bodyRoll')c.fAntiRollBarForce=.2;
    if(k==='poorTraction')c.fTractionCurveMin=Math.min(1,v.fTractionCurveMax);
    if(k==='harshSuspension')c.fSuspensionCompDamp=v.fSuspensionForce;
    if(k==='highSpeedRisk')c.fSteeringLock=40;
  }return c;
}
const scoreFormula='Start at 100; subtract fixed penalties for invalid suspension travel (25), invalid traction ordering (20), brake bias outside 0.35-0.80 (10), high steering lock above 45 with speed reference above 180 (10), anti-roll force below 0.2 (5), center-of-mass Z above 0.2 (15), traction-loss multiplier above 2 (5), and compression damping above 1.5x spring force (5); clamp to 0-100.';
function stabilityScore(v){
  let score=100;
  if(v.fSuspensionUpperLimit<=v.fSuspensionLowerLimit)score-=25;
  if(v.fTractionCurveMin>v.fTractionCurveMax)score-=20;
  if(v.fBrakeBiasFront<.35||v.fBrakeBiasFront>.8)score-=10;
  if(v.fSteeringLock>45&&v.fInitialDriveMaxFlatVel>180)score-=10;
  if(v.fAntiRollBarForce<.2)score-=5;
  if(v.vecCentreOfMassOffset?.z>.2)score-=15;
  if(v.fTractionLossMult>2)score-=5;
  if(v.fSuspensionCompDamp>v.fSuspensionForce*1.5)score-=5;
  return Math.max(0,Math.min(100,Math.round(score)));
}
function troubleshoot(v){
  const issues=[];
  const add=(code,severity,fields,rule,suggestion)=>issues.push({code,severity,fields,rule,suggestion});
  if(v.fInitialDriveForce>1.15&&v.fTractionCurveMin<1.2)add('excessiveWheelspin','medium',['fInitialDriveForce','fTractionCurveMin'],'High drive force combined with low sliding traction can make wheelspin more likely.','Reduce drive force or increase sliding traction.');
  if(v.fInitialDriveForce<.15)add('poorAcceleration','low',['fInitialDriveForce'],'Drive force is below the configured conservative threshold.','Increase drive force gradually and validate on the target vehicle.');
  if(v.fBrakeForce<.3)add('weakBraking','medium',['fBrakeForce'],'Service brake force is below the configured threshold.','Increase brake force in small steps; tyre grip still limits braking.');
  if(v.fTractionBiasFront<.42)add('oversteer','medium',['fTractionBiasFront'],'Low front traction share can contribute to oversteer tendency.','Move traction bias toward the center in small steps.');
  if(v.fTractionBiasFront>.58)add('understeer','medium',['fTractionBiasFront'],'High front traction share can contribute to understeer tendency.','Move traction bias toward the center in small steps.');
  if(v.fAntiRollBarForce<.2)add('bodyRoll','low',['fAntiRollBarForce'],'Anti-roll force is low relative to the editor heuristic.','Increase anti-roll force gradually.');
  if(v.fSteeringLock>45&&v.fInitialDriveMaxFlatVel>180)add('highSpeedInstability','high',['fSteeringLock','fInitialDriveMaxFlatVel'],'High steering lock and a high speed reference can make steering response sensitive.','Reduce steering lock or speed reference and test carefully.');
  if(v.fSteeringLock<15)add('poorSteeringResponse','low',['fSteeringLock'],'Steering lock is below the configured response threshold.','Increase steering lock gradually.');
  if(v.fTractionLossMult>2)add('excessiveTractionLoss','medium',['fTractionLossMult'],'Traction loss multiplier is high relative to the configured heuristic.','Reduce traction loss in small steps.');
  return {issues,scope:'Static handling-value heuristics only; this does not observe or diagnose actual driving behavior.'};
}
function healthCheck(values,baseline,schema){
  const issues=[];
  const known=new Set(schema.map(spec=>spec.field));
  for(const field of Object.keys(values||{}))if(!known.has(field))issues.push({code:'unsupportedField',severity:'high',fields:[field],suggestion:'Remove the unsupported field; runtime setters accept only the schema whitelist.'});
  try{validate(values,schema,true);}catch(error){
    const [code,field]=String(error.message).split(':');
    issues.push({code:'invalidValue',severity:'high',fields:field?[field]:[],detail:code,suggestion:'Restore the captured value or enter a finite value inside the documented range.'});
  }
  if(values&&values.fInitialDriveForce>1.5)issues.push({code:'excessDriveForce',severity:'high',fields:['fInitialDriveForce'],suggestion:'Reduce drive force toward the captured baseline.'});
  if(values&&values.fBrakeForce>2)issues.push({code:'excessBrakeForce',severity:'medium',fields:['fBrakeForce'],suggestion:'Reduce brake force and verify brake balance.'});
  if(values&&values.fTractionCurveMax>4.5)issues.push({code:'excessTraction',severity:'medium',fields:['fTractionCurveMax'],suggestion:'Reduce peak traction to a vehicle-appropriate value.'});
  if(values&&values.fBrakeBiasFront<.35||values&&values.fBrakeBiasFront>.8)issues.push({code:'extremeBrakeBias',severity:'high',fields:['fBrakeBiasFront'],suggestion:'Move front brake share into the validated middle range.'});
  if(values&&(values.fSuspensionForce>3||values.fSuspensionUpperLimit-values.fSuspensionLowerLimit>.8||values.fSuspensionUpperLimit<=values.fSuspensionLowerLimit))issues.push({code:'extremeSuspension',severity:'high',fields:['fSuspensionForce','fSuspensionUpperLimit','fSuspensionLowerLimit'],suggestion:'Restore suspension force and travel toward the captured baseline.'});
  if(values&&values.fTractionCurveMin>values.fTractionCurveMax)issues.push({code:'unstableTractionOrder',severity:'high',fields:['fTractionCurveMin','fTractionCurveMax'],suggestion:'Keep sliding traction at or below peak traction.'});
  if(baseline&&values){
    for(const change of changes(baseline,values)){
      if(typeof change.before==='number'&&change.before!==0&&typeof change.after==='number'&&Math.abs(change.after/change.before-1)>.5){
        issues.push({code:'unrealisticChange',severity:'medium',fields:[change.field],suggestion:'Review this change against the baseline; it exceeds a 50% relative shift.'});
      }
    }
  }
  return {valid:!issues.some(issue=>issue.severity==='high'),issues};
}
function detectConflicts(v,goals=[]){
  const issues=[];
  const add=(code,fields,explanation,suggestion)=>issues.push({code,fields,explanation,suggestion});
  if(v.fInitialDriveForce>1.1&&v.fTractionCurveMin<v.fInitialDriveForce*.9)add('driveTractionConflict',['fInitialDriveForce','fTractionCurveMin'],'Drive force is high relative to sliding traction.','Reduce drive force or increase sliding traction.');
  if(v.fSteeringLock>45&&v.fTractionLossMult>1.5)add('steeringTractionConflict',['fSteeringLock','fTractionLossMult'],'High steering lock and high traction loss can compound steering sensitivity.','Reduce one of these values toward baseline.');
  if(v.fBrakeForce>1.5&&(v.fBrakeBiasFront<.4||v.fBrakeBiasFront>.7))add('brakeBalanceConflict',['fBrakeForce','fBrakeBiasFront'],'High brake force is paired with an extreme front brake share.','Bring brake bias closer to center before increasing brake force.');
  if(v.fSuspensionForce>2&&v.fSuspensionCompDamp<v.fSuspensionForce*.35)add('suspensionDampingConflict',['fSuspensionForce','fSuspensionCompDamp'],'High spring force is paired with low compression damping.','Increase damping proportionally or reduce spring force.');
  if((goals.includes('Race')&&goals.includes('Comfort'))||(goals.includes('Drift')&&goals.includes('Realistic')))add('goalConflict',[],'Selected goals request opposing response characteristics.','Choose one primary goal or apply them as separate previews.');
  return issues;
}
function tuningPreview(baseline,name,intensity=1,classId,schema=[]){
  const proposal=tune(baseline,name,intensity,classId,schema);
  validate(proposal,schema);
  return {name,intensity,classId,category:vehicleCategory(classId),baseline:clone(baseline),proposal,changes:changes(baseline,{...baseline,...proposal})};
}
function changes(before,after){return Object.keys(after).filter(k=>JSON.stringify(before[k])!==JSON.stringify(after[k])).map(field=>({field,before:before[field],after:after[field]}));}
function xmlExport(values,schema){
  validate(values,schema,true);
  return '<!-- CHandlingData fields only. Merge into the correct existing Item; retain handlingName, flags and SubHandlingData. -->\n'+schema.map(s=>s.type==='vector'?`<${s.field} x="${values[s.field].x}" y="${values[s.field].y}" z="${values[s.field].z}" />`:`<${s.field} value="${values[s.field]}" />`).join('\n');
}
function xmlImport(raw,schema,Parser=globalThis.DOMParser){
  if(typeof raw!=='string'||raw.length>200000||/<!DOCTYPE|<!ENTITY/i.test(raw))throw Error('invalidXML');
  const clean=raw.replace(/<\?xml[^?]*\?>/gi,''); const doc=new Parser().parseFromString('<root>'+clean+'</root>','text/xml');
  if(doc.querySelector('parsererror'))throw Error('invalidXML');
  const values={};
  for(const spec of schema){const nodes=doc.getElementsByTagName(spec.field); if(nodes.length>1)throw Error('duplicateField:'+spec.field); if(!nodes.length)continue;
    const node=nodes[0],number=key=>{const raw=node.getAttribute(key);if(raw===null||raw.trim()===''||!/^[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?$/i.test(raw.trim()))throw Error('invalidNumber:'+spec.field);return Number(raw);};
    values[spec.field]=spec.type==='vector'?{x:number('x'),y:number('y'),z:number('z')}:number('value');
  }return validate(values,schema);
}
function dyno(samples,mass){if(!Number.isFinite(mass)||mass<=0)return [];return samples.filter(s=>!s.invalid&&Number.isFinite(s.acceleration)&&Number.isFinite(s.speed)&&s.acceleration>0&&s.speed>5).map(s=>({speed:s.speed,rpm:s.rpm,kw:mass*s.acceleration*(s.speed/3.6)/1000}));}
function ghost(current,recorded){
  if(!Array.isArray(current)||!Array.isArray(recorded)||!current.length||!recorded.length)return null;
  const valid=trace=>trace.every((s,i)=>s&&!s.invalid&&['time','x','y','z','speed','distance'].every(k=>Number.isFinite(s[k]))&&(!i||s.time>trace[i-1].time));
  if(!valid(current)||!valid(recorded))return {invalid:true};
  const currentOrigin=current[0],otherOrigin=recorded[0];
  if(Math.hypot(currentOrigin.x-otherOrigin.x,currentOrigin.y-otherOrigin.y,currentOrigin.z-otherOrigin.z)>15)return {mismatch:true};
  const now=current.at(-1),elapsed=now.time-currentOrigin.time;
  let i=recorded.findIndex(s=>s.time-otherOrigin.time>=elapsed); if(i<0)return {finished:true};
  const b=recorded[i],a=recorded[Math.max(0,i-1)],f=b.time===a.time?0:(elapsed-(a.time-otherOrigin.time))/(b.time-a.time);
  return {elapsed:elapsed/1000,speedDelta:now.speed-(a.speed+(b.speed-a.speed)*f),distanceDelta:(now.distance-currentOrigin.distance)-((a.distance+(b.distance-a.distance)*f)-otherOrigin.distance)};
}
const api={clone,validate,profiles,quick,tune,vehicleCategory,driveLayout,tuningPreview,diagnose,optimize,healthCheck,troubleshoot,detectConflicts,stabilityScore,scoreFormula,changes,xmlExport,xmlImport,dyno,ghost};
if(typeof module!=='undefined')module.exports=api;root.Core=api;
})(globalThis);
