'use strict';
const $=s=>document.querySelector(s), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function preference(key,fallback){try{return localStorage.getItem(key)||fallback;}catch{return fallback;}}
function savePreference(key,value){try{localStorage.setItem(key,value);}catch{/* Preferences are optional; the editor must still open. */}}
const S={schema:[],state:null,flags:{},session:0,panel:0,language:preference('lux-language','en'),theme:preference('lux-theme','Neon'),samples:[],telemetry:{},recording:false,profile:'Race',intensity:70,search:'',group:'all',channel:'speed',compare:'original',ghost:'',notes:'',aiText:'',aiPrompt:'',aiContext:false,library:{version:2,presets:[],backups:[],reports:[],runs:[],feedback:[],history:[]}};
if(!Locales[S.language])S.language='en';
if(!['Emerald','Neon','Midnight','Sunset','Arctic'].includes(S.theme))S.theme='Neon';
const t=k=>Locales[S.language][k]??k, fmt=(v,d=2)=>typeof v==='number'&&Number.isFinite(v)?v.toFixed(d):'—';
const value=v=>typeof v==='object'?JSON.stringify(v):fmt(v,5);
const btn=(key,action=key,extra='',disabled=false)=>`<button data-action="${action}" ${extra} ${disabled?'disabled':''}>${esc(t(key))}</button>`;
const note=key=>`<p class="note">${esc(t(key))}</p>`,empty=()=>`<div class="empty">${esc(t('empty'))}</div>`;
const card=(title,body,cls='')=>`<section class="card ${cls}"><h2>${esc(t(title))}</h2>${body}</section>`;
const metric=(key,v,unit='')=>`<div class="metric"><span>${esc(t(key))}</span><b>${esc(v)} <small>${esc(unit)}</small></b></div>`;
const select=(id,items,selected)=>`<select id="${id}">${items.map(([v,l])=>`<option value="${esc(v)}" ${String(v)===String(selected)?'selected':''}>${esc(l)}</option>`).join('')}</select>`;
let queue=Promise.resolve(), modal=null, historyTimer, libraryReady=Promise.resolve();
// FiveM's Lua JSON encoder may represent an empty table as {} rather than [].
const list=value=>Array.isArray(value)?value:value&&typeof value==='object'&&!Object.keys(value).length?[]:null;
function libraryData(data){
  if(data==null)return {version:2,presets:[],backups:[],reports:[],runs:[],feedback:[],history:[]};
  if(data.version!==2)throw Error('invalidStorage');const out=Core.clone(data);
  for(const key of ['presets','backups','reports','runs','feedback','history']){out[key]=list(out[key]??[]);if(!out[key])throw Error('invalidStorage');}
  for(const run of out.runs){run.samples=list(run.samples);if(!run.samples)throw Error('invalidStorage');}
  return out;
}
const context=()=>({session:S.session,generation:S.state?.generation});
function current(token){return token.session===S.session&&token.generation===S.state?.generation;}
function assertCurrent(token){if(!current(token))throw Error('staleVehicle');}
function status(message,error=false){$('#status').textContent=message;$('#status').className=error?'danger':'';}
function errorText(raw){const [key,...rest]=String(raw).split(':');return t(key)+(rest.length?': '+rest.join(':'):'');}
async function rawRequest(action,data={},token=context()){
  if(action!=='ready'&&action!=='close')assertCurrent(token);
  if(typeof GetParentResourceName!=='function')throw Error('offline');
  const payload=typeof data==='function'?data():data;
  const controller=typeof AbortController==='function'?new AbortController():null;
  const timeout=controller?setTimeout(()=>controller.abort(),30000):null;
  let response;
  try{response=await fetch(`https://${GetParentResourceName()}/action`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,generation:token.generation,...payload}),...(controller?{signal:controller.signal}:{})});}
  finally{if(timeout!==null)clearTimeout(timeout);}
  const result=await response.json();if(action!=='ready'&&action!=='close')assertCurrent(token);
  if(result.state){S.state=result.state;if(window.parent!==window)window.parent.postMessage({type:'toolMutation',payload:result.state},location.origin);}
  if(result.telemetry)telemetry(result.telemetry);
  if(!result.ok){if(result.state)render();throw Error(result.error+(result.fields?.length?':'+result.fields.join(', '):''));}return result;
}
function request(action,data={}){const token=context();if(action==='close'||action==='ready'||action==='opened')return rawRequest(action,data,token);const task=queue.then(()=>rawRequest(action,data,token));queue=task.catch(()=>{});return task;}
function hide(){S.session++;clearTimeout(historyTimer);$('#app').hidden=true;resolveModal(false);}
function setTheme(){document.body.className=window.parent!==window?'embedded':S.theme.toLowerCase();$('#theme').value=S.theme;$('#language').value=S.language;document.documentElement.lang=S.language;}
function render(){
  if(!S.state)return;setTheme();
  $('#nav').innerHTML=t('panels').map((name,i)=>`<button data-panel="${i}" class="${S.panel===i?'active':''}"><span>${String(i+1).padStart(2,'0')}</span>${esc(name)}</button>`).join('');
  $('#eyebrow').textContent=t('suite');$('#title').textContent=t('panels')[S.panel];
  $('#vehiclebar').innerHTML=`<strong>${esc(S.state.name)}</strong><span>${esc(t('model'))}: ${esc(S.state.model)}</span><span>${esc(t('class'))}: ${esc(t('classes')[S.state.class]||S.state.class)}</span><span>${Object.keys(S.state.values).length} / 46 ${esc(t('fields'))}</span><span class="pill">PRO ${S.flags.ai?'+ AI':''}</span>`;
  $('#undo').disabled=S.state.cursor<=1;$('#redo').disabled=S.state.cursor>=S.state.history.length;$('#undo').title=t('undo');$('#redo').title=t('redo');
  $('#content').innerHTML=panel();drawCharts();
}
function fields(groups){
  const specs=S.schema.filter(s=>(!groups||groups.includes(s.group))&&(groups||S.group==='all'||s.group===S.group)&&(!S.search||`${s.field} ${s[S.language]}`.toLowerCase().includes(S.search.toLowerCase())));
  return specs.map(s=>{
    const v=S.state.values[s.field]; if(v===undefined)return `<div class="field danger">${esc(s.field)} — ${esc(t('unavailable'))}</div>`;
    const axes=s.type==='vector'?['x','y','z']:[''];
    return `<div class="field"><label>${esc(s.field)}</label><p class="description">${esc(s[S.language])}</p>${axes.map(axis=>{
      const n=axis?v[axis]:v;let min=s.rule==='bias'||s.rule==='driveBias'||s.rule==='percent'||s.rule==='nonnegative'||s.rule==='integer'?0:n-Math.max(1,Math.abs(n));let max=(s.rule==='bias'||s.rule==='driveBias')?1:s.rule==='percent'?100:n+Math.max(1,Math.abs(n));
      if(s.rule==='positive'||s.rule==='positiveVector')min=.00001;if(s.rule==='gears'){min=1;max=7;}
      const step=s.type==='int'?1:Math.max(.00001,(max-min)/1000);
      return `<div class="inputs">${axis?`<small>${axis.toUpperCase()}</small>`:''}<input aria-label="${esc(s.field+' '+axis)} slider" type="range" data-field="${s.field}" data-axis="${axis}" min="${Math.min(min,n)}" max="${Math.max(max,n)}" step="${step}" value="${n}"><input aria-label="${esc(s.field+' '+axis)}" type="number" data-field="${s.field}" data-axis="${axis}" step="${s.type==='int'?1:'any'}" value="${n}"></div>`;
    }).join('')}</div>`;
  }).join('')||empty();
}
function editor(groups,toolbar=true){return (toolbar?`<div class="toolbar"><input id="search" type="search" placeholder="${esc(t('search'))}" value="${esc(S.search)}">${select('group',Object.entries(Locales[S.language].groups),S.group)}</div>`:'')+`<div id="fields">${fields(groups)}</div>`;}
function diagnostics(){const d=Core.diagnose(S.state.values);return `<div class="split"><div><span class="pill">${esc(t('estimated'))}</span><div class="score">${d.score}<small> / 100</small></div></div>${btn('optimizer','optimize','',!S.flags.smart)}</div>${note('scoreNote')}<h3>${esc(t('conflicts'))}</h3>${d.issues.length?d.issues.map(i=>`<div class="list-item"><span class="danger">${esc(t(i.key))}</span><p class="muted">${esc(i.fields.join(' · '))}</p></div>`).join(''):`<p class="good">${esc(t('noIssues'))}</p>`}`;}
function profiles(){return `<div class="toolbar">${select('profile',Object.keys(Core.profiles).map(p=>[p,t(p)]),S.profile)}<label>${esc(t('intensity'))} <output id="intensity-output">${S.intensity}%</output></label><input id="intensity" type="range" min="10" max="100" value="${S.intensity}">${btn('preview','tune','',!S.flags.smart)}</div>`;}
function chart(id='telemetry'){return S.samples.length?`<div class="chart-labels"><span>${esc(t(S.channel))}</span><span>${esc(t('chartWindow'))}</span><span>${esc(t('measured'))}</span></div><canvas id="${id}" width="900" height="260"></canvas>`:empty();}
function recording(){return `<div class="actions">${btn(S.recording?'stop':'record','record','',!S.flags.telemetry)}${btn('drive','close')}${btn('resetStats')}${btn('saveRun','saveRun','',!S.samples.length||!S.flags.presets)}</div>`;}
function resultsTable(results){const rows=Object.entries(results||{});return rows.length?`<table><tbody>${rows.map(([k,v])=>`<tr><td>${esc(t(k))}</td><td>${typeof v==='object'?`${fmt(v.seconds,3)} s · ${fmt(v.metres)} m`:`${fmt(v)} ${k==='maxSpeed'?'km/h':'m/s²'}`}</td></tr>`).join('')}</tbody></table>`:empty();}
function runsSelect(id,selected){return select(id,[['',t('selectRun')],...S.library.runs.map(r=>[r.id,r.name])],selected);}
function savedRows(group){return S.library[group].length?`<table><tbody>${S.library[group].map(e=>`<tr><td>${esc(e.name)}<p class="muted">${esc(e.model||'')} · ${esc(e.style?t(e.style):'')}</p></td><td><div class="actions">${(group==='presets'||group==='backups')?btn('load','loadEntry',`data-id="${esc(e.id)}" data-group="${group}"`):btn('export','exportEntry',`data-id="${esc(e.id)}" data-group="${group}"`)}${(group==='presets'||group==='backups')?btn('export','exportEntry',`data-id="${esc(e.id)}" data-group="${group}"`):''}${btn('rename','renameEntry',`data-id="${esc(e.id)}" data-group="${group}"`)}${btn('duplicate','duplicateEntry',`data-id="${esc(e.id)}" data-group="${group}"`)}${btn('delete','deleteEntry',`data-id="${esc(e.id)}" data-group="${group}"`)}</div></td></tr>`).join('')}</tbody></table>`:empty();}
function diffTable(a,b){const diffs=Core.changes(a,b);return diffs.length?`<table><thead><tr><th>${esc(t('field'))}</th><th>${esc(t('before'))}</th><th>${esc(t('after'))}</th></tr></thead><tbody>${diffs.map(d=>`<tr><td>${esc(d.field)}</td><td>${esc(value(d.before))}</td><td class="good">${esc(value(d.after))}</td></tr>`).join('')}</tbody></table>`:`<p class="muted">${esc(t('noChanges'))}</p>`;}
function panel(){
  const v=S.state.values,tele=S.telemetry,s=tele.sample||{},r=tele.results||{};
  switch(S.panel){
  case 0:return `<div class="grid">${card('welcome',`<div class="code">LUXARCIA / ${esc(S.state.name)}</div><h2>${esc(S.state.name)}</h2><p class="muted">${esc(t('welcomeNote'))}</p><div class="actions">${btn('openManual','navigate','data-target="1"')}${btn('openTests','navigate','data-target="8"')}</div>`,'hero')}${card('diagnostics',diagnostics())}${card('measured',`<div id="dashboard-values" class="metrics">${dashboardValues()}</div>`)}${card('quick',profiles()+`<div class="actions">${Object.keys(Core.quick).map(k=>btn(k,'quick',`data-kind="${k}"`,!S.flags.smart)).join('')}</div>`)}</div>`;
  case 1:return card('runtimeNote',`<div class="toolbar">${btn('reset')}${btn('copyXML')}${btn('copyValues')}${btn('backup','backup','',!S.flags.presets)}</div>`)+card('fields',editor())+card('xml',`<textarea id="import-text" placeholder="${esc(t('paste'))}"></textarea><div class="actions spacer">${btn('import')}${btn('export')}${btn('copyXML')}</div>${note('exportNote')}`);
  case 2:return card('profile',profiles())+`<div class="grid">${card('quick',`<div class="actions">${Object.keys(Core.quick).map(k=>btn(k,'quick',`data-kind="${k}"`,!S.flags.smart)).join('')}</div>`)}${card('diagnostics',diagnostics())}</div>`;
  case 3:return card('fields',`<div class="toolbar">${select('group',Object.entries(Locales[S.language].groups),S.group)}</div>${note('runtimeNote')}<div id="fields">${fields()}</div>`)+card('weight',weight());
  case 4:return card('suspensionNote',`<div class="actions">${btn('softer','quick','data-kind="softer"',!S.flags.smart)}${btn('stiffer','quick','data-kind="stiffer"',!S.flags.smart)}</div>`)+card('fields',editor(['suspension'],false));
  case 5:return card('suspensionCompare',diffTable(Object.fromEntries(S.schema.filter(s=>s.group==='suspension').map(s=>[s.field,S.state.original[s.field]])),Object.fromEntries(S.schema.filter(s=>s.group==='suspension').map(s=>[s.field,v[s.field]]))))+card('estimated',`<div class="diagram"><div class="axle">${esc(t('front'))}<div class="spring">⌁</div>${fmt(v.fSuspensionBiasFront*100,1)}%</div><div><div class="spring">⇅</div>${fmt(v.fSuspensionUpperLimit-v.fSuspensionLowerLimit,3)} m</div><div class="axle">${esc(t('rear'))}<div class="spring">⌁</div>${fmt((1-v.fSuspensionBiasFront)*100,1)}%</div></div>${note('suspensionNote')}<div class="metrics">${metric('compression',fmt(v.fSuspensionCompDamp))}${metric('rebound',fmt(v.fSuspensionReboundDamp))}${metric('travel',fmt(v.fSuspensionUpperLimit-v.fSuspensionLowerLimit,3),'m')}</div>`)+card('fields',editor(['suspension'],false));
  case 6:return card('diagnostics',note('brakeWarning'))+card('front',`<div class="bar"><span style="width:${Math.max(0,Math.min(100,v.fBrakeBiasFront*100))}%"></span></div><div class="split"><span>${esc(t('front'))} ${fmt(v.fBrakeBiasFront*100,1)}%</span><span>${esc(t('rear'))} ${fmt((1-v.fBrakeBiasFront)*100,1)}%</span></div>`)+card('fields',editor(['brakes'],false));
  case 7:return card('estimated',note('gearNote')+`<div id="gear-values" class="metrics">${gearValues()}</div>`)+card('fields',editor(['transmission'],false));
  case 8:return card('status',note('testNote')+`<div class="actions">${['accel100','accel200','brake','drag'].map(k=>btn(k,'test',`data-kind="${k}"`,!S.flags.tests)).join('')}${btn('cancelTest')}</div><p class="pill" id="test-status">${esc(tele.test?t(tele.test.kind)+' · '+t(tele.test.status):'—')}</p>`)+`<div class="grid">${card('measured',`<div id="test-results">${resultsTable(r)}</div>`)}${card('session',recording()+`<div class="actions spacer"></div>`)}</div>`+card('savedTests',savedRows('runs'));
  case 9:return card('measured',`<div id="live-values" class="metrics">${liveValues()}</div>`)+card('chart',`<div class="toolbar">${select('channel',['speed','acceleration','longG','latG','roll','pitch','yaw'].map(k=>[k,t(k==='roll'||k==='pitch'||k==='yaw'?'rotation':k)+(k==='roll'||k==='pitch'||k==='yaw'?' '+k:'')]),S.channel)}</div><div id="chart-host">${chart()}</div>${recording()}`);
  case 10:return card('measured',note('gNote')+`<div id="g-values" class="metrics">${metric('longG',fmt(s.longG,3),'G')}${metric('latG',fmt(s.latG,3),'G')}</div><canvas id="gforce" width="800" height="300"></canvas>${recording()}`);
  case 11:return card('estimated',note('slipNote')+`<div id="slip-result">${slip()}</div>`)+card('diagnostics',diagnostics());
  case 12:return card('power',note('dynoNote')+runsSelect('ghost',S.ghost)+`<div id="dyno-host">${S.samples.length?'<canvas id="dyno" width="900" height="260"></canvas>':empty()}</div>${recording()}`);
  case 13:return card('lap',note('lapNote')+`<div class="actions">${['checkpoint','clear','startLap','stopLap','invalidate'].map(k=>btn(k,'lap',`data-kind="${k}"`,!S.flags.tests)).join('')}${btn('drive','close')}</div><div id="lap-results">${lapResults()}</div>`);
  case 14:return card('measured',note('ghostNote')+runsSelect('ghost',S.ghost)+`<div id="ghost-result">${ghostResult()}</div>${recording()}`);
  case 15:{const other=S.compare==='original'?S.state.original:S.library.presets.find(p=>p.id===S.compare)?.values||S.state.original;return card('compare',note('comparatorNote')+select('compare',[['original',t('original')],...S.library.presets.map(p=>[p.id,p.name+' / '+p.model])],S.compare)+diffTable(other,v))+card('benchmark',benchmark())+card('weight',weight());}
  case 16:return card('newPreset',`<div class="actions">${btn('newPreset','newPreset','',!S.flags.presets)}${btn('backup','backup','',!S.flags.presets)}${btn('recover','recover','',!S.flags.presets)}</div>`)+card('profile',savedRows('presets'))+card('backups',savedRows('backups'))+card('xml',`<textarea id="import-text" placeholder="${esc(t('paste'))}"></textarea><div class="actions spacer">${btn('import')}${btn('export')}</div>${note('exportNote')}`);
  case 17:return card('history',note('historyNote')+`<div class="actions">${btn('undo','undo','',S.state.cursor<=1)}${btn('redo','redo','',S.state.cursor>=S.state.history.length)}</div><table>${S.state.history.map((h,i)=>`<tr><td>${i+1} ${i+1===S.state.cursor?'●':''}</td><td>${esc(t(h.label))}</td><td>${btn('restore','historyPreview',`data-index="${i}"`)}</td></tr>`).join('')}</table>`)+card('archive',S.library.history.length?`<table>${S.library.history.map((h,i)=>`<tr><td>${esc(h.label)}</td><td>${btn('restore','archivePreview',`data-index="${i}"`)}</td></tr>`).join('')}</table>`:empty());
  case 18:return card('ai',!S.flags.ai?note('aiDisabled'):note('aiNote')+`<textarea id="ai-prompt" placeholder="${esc(t('prompt'))}">${esc(S.aiPrompt)}</textarea><div class="checks"><label><input id="ai-context" type="checkbox" ${S.aiContext?'checked':''}> ${esc(t('includeContext'))}</label></div><div class="actions">${['ask','aiTune','hybrid','aiExplain','aiOptimize','aiProblems','aiLearn'].map(k=>btn(k,'ai',`data-kind="${k}"`)).join('')}</div><pre>${esc(S.aiText)}</pre>`);
  case 19:return card('reports',note('reportNote')+`<textarea id="notes" placeholder="${esc(t('notes'))}">${esc(S.notes)}</textarea><div class="actions spacer">${btn('createReport','createReport','',!S.flags.presets)}${btn('downloadReport')}</div>`)+card('feedback',note('learningNote')+profiles()+`<div class="actions">${btn('goodSetup','feedback','data-vote="1"',!S.flags.presets)}${btn('badSetup','feedback','data-vote="-1"',!S.flags.presets)}</div><p>${esc(t('recommended'))}: ${esc(recommendation())} · ${S.library.feedback.length} ${esc(t('votes'))}</p>`)+card('archive',savedRows('reports'));
  case 20:{const list=S.library.presets.filter(p=>(!S.search||`${p.name} ${p.model}`.toLowerCase().includes(S.search.toLowerCase()))&&(S.group==='all'||p.style===S.group));return card('profile',`<div class="toolbar"><input id="library-search" type="search" placeholder="${esc(t('search'))}" value="${esc(S.search)}">${select('library-style',[['all',t('all')],...Object.keys(Core.profiles).map(k=>[k,t(k)])],S.group)}</div><div id="library-list">${libraryList(list)}</div>`);}
  case 21:return card('academyNote',`<div class="toolbar"><input id="search" type="search" placeholder="${esc(t('search'))}" value="${esc(S.search)}">${select('group',Object.entries(Locales[S.language].groups),S.group)}</div><div id="academy-list">${academy()}</div>`);
  default:return empty();
  }
}
function academy(){return S.schema.filter(s=>(S.group==='all'||s.group===S.group)&&`${s.field} ${s[S.language]}`.toLowerCase().includes(S.search.toLowerCase())).map(s=>`<div class="list-item"><h3>${esc(s.field)} <span class="pill">${esc(s.type)}</span></h3><p>${esc(s[S.language])}</p><p class="muted">${esc(Locales[S.language].groups[s.group])} · ${esc(t('value'))}: ${esc(value(S.state.values[s.field]))}</p></div>`).join('');}
function libraryList(list){return list.length?list.map(p=>`<div class="list-item split"><div><h2>${esc(p.name)}</h2><span class="muted">${esc(p.model)} · ${esc(t(p.style))}</span></div>${btn('load','loadEntry',`data-group="presets" data-id="${esc(p.id)}"`)}</div>`).join(''):empty();}
function dashboardValues(){const r=S.telemetry.results||{};return metric('maxSpeed',fmt(r.maxSpeed),'km/h')+metric('peakAcceleration',fmt(r.peakAcceleration),'m/s²')+metric('peakBraking',fmt(r.peakBraking),'m/s²');}
function gearValues(){const s=S.telemetry.sample||{};return metric('currentGear',s.gear??'—')+metric('normalizedRPM',fmt(s.rpm,3))+metric('gearingReference',fmt(S.state.values.fInitialDriveMaxFlatVel));}
function weight(){const v=S.state.values;return note('weightNote')+`<div class="metrics">${metric('fMass',fmt(v.fMass),'kg')}${metric('fSuspensionBiasFront',fmt(v.fSuspensionBiasFront*100),'%')}${metric('vecCentreOfMassOffset',value(v.vecCentreOfMassOffset),'m')}</div>`;}
function slip(){const s=S.telemetry.sample;if(s?.invalid)return note('invalid');if(!s||s.speed<15)return note('lowSpeed');const heading=s.yaw*Math.PI/180,forward={x:-Math.sin(heading),y:Math.cos(heading)},long=s.vx*forward.x+s.vy*forward.y,lat=s.vx*forward.y-s.vy*forward.x,angle=Math.atan2(lat,Math.abs(long))*180/Math.PI;const label=Math.abs(angle)>12?'slide':Math.abs(s.steering)>10&&Math.abs(s.latG)<.1?'under':'steady';return `<div class="metrics">${metric('slip',fmt(angle),'°')}${metric('latG',fmt(s.latG,3),'G')}</div><p>${esc(t(label))}</p>`;}
function lapResults(){const tele=S.telemetry,laps=list(tele.laps)||[],valid=laps.filter(l=>!l.invalid);return `<p>${esc(t('checkpoints'))}: ${(list(tele.checkpoints)||[]).length}</p><div class="metrics">${metric('currentLap',fmt(tele.lap?.current,3),'s')}${metric('previousLap',fmt(laps.at(-1)?.seconds,3),'s')}${metric('bestLap',valid.length?fmt(Math.min(...valid.map(l=>l.seconds)),3):'—','s')}</div>${laps.length?`<table>${laps.map((l,i)=>`<tr><td>${i+1}</td><td>${fmt(l.seconds,3)} s</td><td>${esc(t(l.invalid?'invalid':'complete'))}</td></tr>`).join('')}</table>`:empty()}`;}
function ghostResult(){const run=S.library.runs.find(r=>r.id===S.ghost),g=run&&Core.ghost(S.samples,run.samples);return !g?empty():g.invalid?note('invalid'):g.mismatch?note('mismatch'):g.finished?note('finished'):g.invalid?note('invalid'):`<div class="metrics">${metric('speedDelta',fmt(g.speedDelta),'km/h')}${metric('distanceDelta',fmt(g.distanceDelta),'m')}${metric('time',fmt(g.elapsed),'s')}</div>`;}
function benchmark(){return S.library.runs.length?`<table><thead><tr><th>${esc(t('name'))}</th><th>${esc(t('model'))}</th><th>0–100 s</th><th>400 m s</th><th>${esc(t('maxSpeed'))}</th></tr></thead><tbody>${S.library.runs.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.model)}</td><td>${fmt(r.results.accel100?.seconds,3)}</td><td>${fmt(r.results.drag?.seconds,3)}</td><td>${fmt(r.results.maxSpeed)} km/h</td></tr>`).join('')}</tbody></table>`:empty();}
function recommendation(){const scores={};for(const f of S.library.feedback)if(f.model===S.state.model)scores[f.style]=(scores[f.style]||0)+f.vote;const keys=Object.keys(scores).sort((a,b)=>scores[b]-scores[a]);return keys.length?t(keys[0]):'—';}
function graph(canvas,series,labels){if(!canvas)return;const c=canvas.getContext('2d'),w=canvas.width,h=canvas.height;c.clearRect(0,0,w,h);c.font='12px Segoe UI';c.fillStyle=getComputedStyle(document.body).getPropertyValue('--muted');const nums=series.flat().filter(Number.isFinite);if(!nums.length){c.fillText(t('empty'),30,40);return;}let low=Math.min(0,...nums),high=Math.max(...nums);if(high===low)high=low+1;const colors=['#00d9ff','#a88bff','#45e4ac'];c.strokeStyle='#50627855';for(let i=0;i<=4;i++){const y=20+(h-55)*i/4;c.beginPath();c.moveTo(55,y);c.lineTo(w-20,y);c.stroke();c.fillText(fmt(high-(high-low)*i/4,1),4,y+4);}series.forEach((values,i)=>{c.strokeStyle=colors[i%3];c.lineWidth=2;c.beginPath();values.forEach((v,j)=>{const x=55+j/Math.max(1,values.length-1)*(w-75),y=20+(high-v)/(high-low)*(h-55);j?c.lineTo(x,y):c.moveTo(x,y);});c.stroke();});c.fillText(labels||t('time')+' →',55,h-10);}
function drawCharts(){
  graph($('#telemetry'),[S.samples.slice(-120).map(s=>s[S.channel])]);
  const dyno=Core.dyno(S.samples,S.state?.values.fMass||0);graph($('#dyno'),[dyno.map(p=>p.kw),Core.dyno(S.library.runs.find(r=>r.id===S.ghost)?.samples||[],S.library.runs.find(r=>r.id===S.ghost)?.values.fMass||0).map(p=>p.kw)],t('power')+' / '+t('time')+' →');
  const canvas=$('#gforce');if(canvas){const c=canvas.getContext('2d');c.clearRect(0,0,800,300);c.strokeStyle='#50627888';for(let r=35;r<=120;r+=35){c.beginPath();c.arc(400,150,r,0,Math.PI*2);c.stroke();}c.beginPath();c.moveTo(260,150);c.lineTo(540,150);c.moveTo(400,10);c.lineTo(400,290);c.stroke();c.fillStyle='#00d9ff';const s=S.telemetry.sample;if(s){c.beginPath();c.arc(400+Math.max(-2,Math.min(2,s.latG))*60,150-Math.max(-2,Math.min(2,s.longG))*60,6,0,Math.PI*2);c.fill();}c.fillText(t('latG')+' →   ±2G',560,155);c.fillText(t('longG'),410,20);}
}
function liveValues(){const s=S.telemetry.sample||{};return metric('speed',fmt(s.speed),'km/h')+metric('normalizedRPM',fmt(s.rpm,3))+metric('currentGear',s.gear??'—')+metric('engineHealth',fmt(s.engineHealth))+metric('bodyHealth',fmt(s.bodyHealth))+metric('acceleration',s.invalid?'—':fmt(s.acceleration),'m/s²')+metric('brakingEstimate',s.invalid?'—':fmt(Math.max(0,-s.acceleration)),'m/s²');}
function live(){
  if($('#app').hidden)return;
  const s=S.telemetry.sample||{};
  document.querySelectorAll('[data-action="saveRun"]').forEach(b=>{b.disabled=!S.samples.length||!S.flags.presets;});
  document.querySelectorAll('[data-action="record"]').forEach(b=>{b.textContent=t(S.recording?'stop':'record');});
  if(S.panel===0)$('#dashboard-values').innerHTML=dashboardValues();
  if(S.panel===7)$('#gear-values').innerHTML=gearValues();
  if(S.panel===9){$('#live-values').innerHTML=liveValues();const host=$('#chart-host');if(host&&!$('#telemetry')&&S.samples.length)host.innerHTML=chart();drawCharts();}
  if(S.panel===10){$('#g-values').innerHTML=metric('longG',fmt(s.longG,3),'G')+metric('latG',fmt(s.latG,3),'G');drawCharts();}
  if(S.panel===11)$('#slip-result').innerHTML=slip();
  if(S.panel===12){if(!$('#dyno')&&S.samples.length)$('#dyno-host').innerHTML='<canvas id="dyno" width="900" height="260"></canvas>';drawCharts();}
  if(S.panel===13)$('#lap-results').innerHTML=lapResults();
  if(S.panel===14)$('#ghost-result').innerHTML=ghostResult();
  if(S.panel===8){$('#test-status').textContent=S.telemetry.test?t(S.telemetry.test.kind)+' · '+t(S.telemetry.test.status):'—';$('#test-results').innerHTML=resultsTable(S.telemetry.results);}
}
function telemetry(data,append=true,refresh=true){
  if(!S.state||data?.generation!==S.state.generation)return;
  S.telemetry={...data,laps:list(data.laps)||[],checkpoints:list(data.checkpoints)||[]};
  if(typeof data.active==='boolean')S.recording=data.active;
  if(data.samples)S.samples=(list(data.samples)||[]).slice(-1200);
  if(append&&data.sample&&(!S.samples.length||data.sample.time>S.samples.at(-1).time)){S.samples.push(data.sample);if(S.samples.length>1200)S.samples.shift();}
  if(refresh)live();
}
function openModal(title,body,noteText='',input=false){
  if(modal)modal.resolve(null);
  $('#proposal-title').textContent=title;$('#proposal-note').textContent=noteText;$('#proposal-content').innerHTML=body;$('#reject').textContent=t('cancel');$('#approve').textContent=input?t('save'):t('apply');
  if(!$('#proposal').open)$('#proposal').showModal();return new Promise(resolve=>{modal={resolve,input};});
}
function resolveModal(approved){if(!modal)return;const m=modal;modal=null;const result=approved?(m.input?$('#modal-name').value.trim().slice(0,120):true):null;$('#proposal').close();m.resolve(result);}
async function preview(values,label){Core.validate(values,S.schema);const diffs=Core.changes(S.state.values,values);if(!diffs.length){status(t('noChanges'));return;}const generation=S.state.generation;if(await openModal(t('preview'),diffTable(S.state.values,values),t('previewNote'))){if(generation!==S.state.generation)throw Error('staleVehicle');await apply(values,label);}}
async function apply(values,label){if(typeof values!=='function')Core.validate(values,S.schema);await request('apply',()=>{const next=typeof values==='function'?values():values;Core.validate(next,S.schema);return {values:next,label};});archiveHistory();render();status(t('applied'));}
function archiveHistory(){if(!S.flags.presets)return;clearTimeout(historyTimer);const token=context(),loaded=libraryReady,history=Core.clone(S.state.history.map(h=>({...h,model:S.state.model})));historyTimer=setTimeout(()=>{const job=storageQueue.then(async()=>{await loaded;assertCurrent(token);await request('saveHistory',{history});assertCurrent(token);S.library.history=history;});storageQueue=job.catch(e=>{if(current(token))status(errorText(e.message),true);});},1000);}
async function nameDialog(defaultName){return openModal(t('presetName'),`<input id="modal-name" maxlength="120" value="${esc(defaultName)}" aria-label="${esc(t('name'))}">`,'',true);}
let storageQueue=Promise.resolve();
function mutate(fn){const token=context(),loaded=libraryReady;const job=storageQueue.then(async()=>{await loaded;assertCurrent(token);const next=Core.clone(S.library);fn(next);if(['presets','backups','reports','runs','feedback'].reduce((n,k)=>n+next[k].length,0)>(S.flags.maxSavedEntries||100))throw Error('limit');await request('save',{data:next});assertCurrent(token);S.library=next;});storageQueue=job.catch(()=>{});return job;}
function id(){return globalThis.crypto.randomUUID();}
async function saveSetup(group){const name=await nameDialog(`${S.state.name} · ${t(S.profile)}`);if(!name)return;Core.validate(S.state.values,S.schema,true);const entry={id:id(),name,model:S.state.model,vehicleName:S.state.name,style:S.profile,values:Core.clone(S.state.values),created:new Date().toISOString()};await mutate(lib=>lib[group].push(entry));render();status(t('saved'));}
function report(){return {version:2,id:id(),name:S.state.name+' '+new Date().toISOString(),model:S.state.model,vehicleName:S.state.name,original:S.state.original,values:S.state.values,profile:S.profile,diagnostics:Core.diagnose(S.state.values),history:S.state.history,recordedResults:S.telemetry.results||{},savedResults:S.library.runs.filter(r=>r.model===S.state.model).map(r=>({name:r.name,results:r.results})),changes:Core.changes(S.state.original,S.state.values).map(c=>({...c,explanation:S.schema.find(s=>s.field===c.field)?.[S.language]})),notes:S.notes,aiExplanation:S.aiText,limitations:t('scoreNote'),created:new Date().toISOString()};}
function download(data,name){const text=typeof data==='string'?data:JSON.stringify(data,null,2),blob=new Blob([text],{type:'text/plain;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);return openModal(name,`<textarea readonly id="export-text">${esc(text)}</textarea><div class="actions spacer">${btn('copyValues','copyExport')}</div>`,t('exportFallback'));}
async function copy(text){try{await navigator.clipboard.writeText(text);status(t('copied'));}catch{await openModal(t('copyFailed'),`<textarea readonly>${esc(text)}</textarea>`);}}
async function action(button){
  const a=button.dataset.action;
  if(a==='navigate'){S.panel=Number(button.dataset.target);S.group='all';S.search='';render();return;}
  if(a==='close'){const closing=request('close');hide();await closing;return;}
  if(a==='undo'||a==='redo'){await request('history',{index:S.state.cursor+(a==='undo'?-1:1)});archiveHistory();render();return;}
  if(a==='tune')return preview(Core.tune(S.state.values,S.profile,S.intensity/100),S.profile);
  if(a==='quick')return preview(Core.tune(S.state.original,button.dataset.kind,S.intensity/100,S.state.class,S.schema),button.dataset.kind);
  if(a==='optimize')return preview(Core.optimize(S.state.values),'optimizer');
  if(a==='reset')return preview(S.state.original,'reset');
  if(a==='copyXML')return copy(Core.xmlExport(S.state.values,S.schema));
  if(a==='copyValues')return copy(JSON.stringify(S.state.values,null,2));
  if(a==='copyExport'){const text=$('#export-text');text.focus();text.select();try{await navigator.clipboard.writeText(text.value);status(t('copied'));}catch{const copied=document.execCommand('copy');status(t(copied?'copied':'copyFailed'),!copied);}return;}
  if(a==='export')return download({version:2,model:S.state.model,values:S.state.values},'luxarcia-setup.json');
  if(a==='import'){const raw=$('#import-text').value.trim();let values;if(raw.startsWith('<'))values=Core.xmlImport(raw,S.schema);else{if(raw.length>200000)throw Error('invalidValues');const data=JSON.parse(raw);values=data.values||data;Core.validate(values,S.schema);}return preview(values,'import');}
  if(a==='newPreset'||a==='backup')return saveSetup(a==='backup'?'backups':'presets');
  if(a.endsWith('Entry')){const group=button.dataset.group,entry=S.library[group].find(e=>e.id===button.dataset.id);if(!entry)return;
    if(a==='loadEntry')return preview(entry.values,entry.name);
    if(a==='exportEntry')return download(entry,`luxarcia-${group}.json`);
    if(a==='deleteEntry'){if(await openModal(t('confirmDelete'),`<p>${esc(entry.name)}</p>`))await mutate(lib=>{lib[group]=lib[group].filter(e=>e.id!==entry.id);});}
    if(a==='renameEntry'){const name=await nameDialog(entry.name);if(name)await mutate(lib=>{lib[group].find(e=>e.id===entry.id).name=name;});}
    if(a==='duplicateEntry'){const name=await nameDialog(entry.name+' (2)');if(name)await mutate(lib=>lib[group].push({...Core.clone(entry),id:id(),name}));}
    render();return;
  }
  if(a==='recover'){const result=await request('recover'),data=libraryData(result.data);if(result.data&&await openModal(t('recover'),`<p>${esc(t('previewNote'))}</p>`)){await mutate(lib=>{Object.assign(lib,data);});render();}return;}
  if(a==='historyPreview')return preview(S.state.history[Number(button.dataset.index)].values,'history');
  if(a==='archivePreview')return preview(S.library.history[Number(button.dataset.index)].values,'archive');
  if(a==='record'){const r=await request('telemetry',{enabled:!S.recording});S.recording=r.active;render();return;}
  if(a==='resetStats'){const result=await request('resetStats');S.samples=[];if(!result.telemetry)S.telemetry={checkpoints:S.telemetry.checkpoints||[]};render();return;}
  if(a==='test'){const result=await request('test',{kind:button.dataset.kind});S.recording=true;if(!result.telemetry)S.telemetry.test={kind:button.dataset.kind,status:'armed'};render();status(t('armed'));return;}
  if(a==='cancelTest'){await request(a);S.telemetry.test=null;live();return;}
  if(a==='startPosition'){await request(a);status(t('saved'));return;}
  if(a==='reposition'){if(await openModal(t('reposition'),note('repositionNote'))){await request(a,{confirm:true});S.samples=[];S.telemetry={checkpoints:S.telemetry.checkpoints||[]};render();}return;}
  if(a==='lap'){const command={startLap:'start',stopLap:'stop',checkpoint:'checkpoint',clear:'clear',invalidate:'invalidate'}[button.dataset.kind];const result=await request('lap',{command});S.telemetry.checkpoints=list(result.checkpoints)||[];S.telemetry.laps=list(result.laps)||[];if(!result.telemetry)S.recording=true;render();return;}
  if(a==='saveRun'){const data=await request('run'),samples=list(data.samples);if(!samples?.length)throw Error('empty');const name=await nameDialog(S.state.name+' / '+t('session'));if(!name)return;const entry={...data,samples,id:id(),name,model:S.state.model,values:data.values||Core.clone(S.state.values),style:S.profile,created:new Date().toISOString()};delete entry.ok;delete entry.telemetry;await mutate(lib=>lib.runs.push(entry));render();return;}
  if(a==='downloadReport')return download(report(),'luxarcia-report.json');
  if(a==='createReport'){const r=report();await mutate(lib=>lib.reports.push(r));render();status(t('saved'));return;}
  if(a==='feedback'){await mutate(lib=>lib.feedback.push({id:id(),name:S.profile,model:S.state.model,style:S.profile,vote:Number(button.dataset.vote),values:Core.clone(S.state.values)}));render();status(t('feedbackSaved'));return;}
  if(a==='ai'){
    const generation=S.state.generation,kind=button.dataset.kind,prompt=S.aiPrompt||t(kind);
    const base=kind==='hybrid'?Core.tune(S.state.values,S.profile,S.intensity/100):{};
    status(t('busy'));
    const r=await request('ai',{prompt:t(kind)+': '+prompt,language:S.language,values:{...S.state.values,...base},context:$('#ai-context').checked?JSON.stringify({history:S.state.history.slice(-5),tests:S.telemetry.results,feedback:S.library.feedback.filter(f=>f.model===S.state.model).slice(-5)}):''});
    if(generation!==S.state.generation)throw Error('staleVehicle');S.aiText=r.explanation;render();const proposed={...base,...r.changes};if(Object.keys(proposed).length)await preview(proposed,kind);return;
  }
}
document.addEventListener('click',async e=>{
  const nav=e.target.closest('[data-panel]');if(nav){S.panel=Number(nav.dataset.panel);S.search='';S.group='all';render();return;}
  const button=e.target.closest('[data-action]');if(!button||button.disabled)return;
  button.disabled=true;try{await action(button);}catch(error){status(errorText(error.message),true);}finally{if(button.isConnected)button.disabled=false;}
});
document.addEventListener('input',e=>{
  const el=e.target;
  if(el.dataset.field){const pair=el.closest('.inputs');pair.querySelectorAll('input').forEach(input=>{if(input!==el)input.value=el.value;});}
  if(el.id==='intensity'){S.intensity=Number(el.value);$('#intensity-output').textContent=el.value+'%';}
  if(el.id==='search'){S.search=el.value;if(S.panel===21)$('#academy-list').innerHTML=academy();else $('#fields').innerHTML=fields();}
  if(el.id==='library-search'){S.search=el.value;$('#library-list').innerHTML=libraryList(S.library.presets.filter(p=>`${p.name} ${p.model}`.toLowerCase().includes(S.search.toLowerCase())&&(S.group==='all'||p.style===S.group)));}
  if(el.id==='notes')S.notes=el.value;if(el.id==='ai-prompt')S.aiPrompt=el.value;
});
document.addEventListener('change',async e=>{
  const el=e.target;
  try{
    if(el.dataset.field){if(el.value.trim()==='')throw Error('invalidNumber');const field=el.dataset.field,axis=el.dataset.axis,n=Number(el.value);if(S.panel>=4&&S.panel<=7){await preview({[field]:axis?{...S.state.values[field],[axis]:n}:n},'manual');return;}await apply(()=>({[field]:axis?{...S.state.values[field],[axis]:n}:n}),'manual');return;}
    if(el.id==='ai-context')S.aiContext=el.checked;
    const map={language:'language',theme:'theme',profile:'profile',group:'group',channel:'channel',compare:'compare',ghost:'ghost','library-style':'group'};
    if(map[el.id]){S[map[el.id]]=el.value;if(el.id==='language'||el.id==='theme')savePreference('lux-'+el.id,el.value);render();}
  }catch(error){render();status(errorText(error.message),true);}
});
$('#approve').addEventListener('click',()=>resolveModal(true));$('#reject').addEventListener('click',()=>resolveModal(false));$('#proposal').addEventListener('cancel',e=>{e.preventDefault();resolveModal(false);});
$('#close').addEventListener('click',()=>action({dataset:{action:'close'}}).catch(e=>status(errorText(e.message),true)));
$('#undo').addEventListener('click',()=>action({dataset:{action:'undo'}}).catch(e=>status(errorText(e.message),true)));$('#redo').addEventListener('click',()=>action({dataset:{action:'redo'}}).catch(e=>status(errorText(e.message),true)));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#proposal').open){e.preventDefault();$('#close').click();}});
function bootFailure(error){hide();if(window.LuxarciaBridge)window.LuxarciaBridge.fail(error);else console.error('[LUXARCIA NUI]',error);}
const ready=(async()=>{
  let failure;
  for(let attempt=0;attempt<3;attempt++){
    try{
      const response=await fetch('schema.json');if(!response.ok)throw Error('schema.json HTTP '+response.status);
      const schema=await response.json();
      if(!Array.isArray(schema)||schema.length!==46||!schema.every(s=>s&&typeof s.field==='string'))throw Error('schema.json is invalid');
      S.schema=schema;return;
    }catch(error){failure=error;if(attempt<2)await new Promise(resolve=>setTimeout(resolve,150*(attempt+1)));}
  }
  throw failure;
})();
window.addEventListener('message',async event=>{
  const msg=event.data;if(!msg||typeof msg!=='object')return;
  if(msg.type==='close'){hide();return;}
  if(msg.type==='open'){
    const opening=++S.session;resolveModal(false);clearTimeout(historyTimer);queue=Promise.resolve();storageQueue=Promise.resolve();
    try{
      await ready;if(opening!==S.session)return;
      const changed=S.state?.generation!==msg.state.generation;S.state=msg.state;S.flags=msg.flags||{};
      if(changed){S.samples=[];S.telemetry={};S.recording=false;S.compare='original';S.ghost='';S.notes='';S.aiText='';S.aiPrompt='';S.aiContext=false;}
      S.library=libraryData(null);status('');$('#app').hidden=false;if(msg.telemetry)telemetry(msg.telemetry,true,false);render();
      if(msg.openId!==undefined){await request('opened',{openId:msg.openId});if(opening!==S.session)return;}
      const token=context();libraryReady=request('load').then(result=>{assertCurrent(token);S.library=libraryData(result.data);render();});await libraryReady;
    }catch(error){if(opening===S.session){status(errorText(error.message),true);bootFailure(error);}}return;
  }
  if(msg.type==='telemetry')telemetry(msg.data);
});
ready.then(()=>{window.LuxarciaAppReady=true;if(typeof GetParentResourceName==='function')return request('ready');}).catch(bootFailure);
