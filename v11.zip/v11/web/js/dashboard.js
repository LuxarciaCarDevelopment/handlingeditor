document.addEventListener('DOMContentLoaded', () => {
    const vehicleInfo = document.getElementById('vehicle-info');
    const handlingSummary = document.getElementById('handling-summary');
    const quickActions = document.getElementById('quick-actions');

    // Update vehicle info
    fetch('/luxarcia:vehicle:info')
        .then(response => response.json())
        .then(data => {
            vehicleInfo.innerHTML = `
                <p>Model: ${data.model}</p>
                <p>Class: ${data.class}</p>
                <p>Handling: ${data.handling}</p>
            `;
        });

    // Update handling summary
    fetch('/luxarcia:handling:summary')
        .then(response => response.json())
        .then(data => {
            handlingSummary.innerHTML = `
                <p>Speed: ${data.speed} km/h</p>
                <p>RPM: ${data.rpm}</p>
                <p>Gear: ${data.gear}</p>
                <p>Engine Health: ${data.engineHealth}</p>
                <p>Current Tuning Profile: ${data.currentProfile}</p>
            `;
        });

    // Add quick actions
    quickActions.innerHTML = `
        <button id="race-button">Race</button>
        <button id="drift-button">Drift</button>
        <button id="realistic-button">Realistic</button>
        <button id="sport-button">Sport</button>
        <button id="comfort-button">Comfort</button>
    `;

    quickActions.querySelector('#race-button').addEventListener('click', () => {
        // Implement race tuning
    });

    quickActions.querySelector('#drift-button').addEventListener('click', () => {
        // Implement drift tuning
    });

    quickActions.querySelector('#realistic-button').addEventListener('click', () => {
        // Implement realistic tuning
    });

    quickActions.querySelector('#sport-button').addEventListener('click', () => {
        // Implement sport tuning
    });

    quickActions.querySelector('#comfort-button').addEventListener('click', () => {
        // Implement comfort tuning
    });
});