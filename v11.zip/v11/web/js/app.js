document.addEventListener('DOMContentLoaded', function() {
    const app = document.getElementById('luxarcia-app');
    if (!app) return;

    const themeSelector = document.getElementById('theme-selector');
    const languageSelector = document.getElementById('language-selector');
    const navigation = document.getElementById('module-navigation');
    const dashboardPanel = document.getElementById('dashboard-panel');
    const editorPanel = document.getElementById('editor-panel');
    const smartPanel = document.getElementById('smart-panel');
    const wizardPanel = document.getElementById('wizard-panel');
    const themes = ['luxarcia-dark', 'midnight-black', 'neon-blue', 'racing-red', 'premium-purple'];
    const state = { language: 'en', theme: themes[0], panel: 0, vehicle: null, telemetry: null, values: {}, original: {}, schema: [] };

    function t(key, values) {
        return window.LuxarciaUI ? window.LuxarciaUI.translate(key, values) : key;
    }

    function preference(key, fallback) {
        try { return localStorage.getItem(key) || fallback; } catch (_) { return fallback; }
    }

    function savePreference(key, value) {
        try { localStorage.setItem(key, value); } catch (_) { return; }
    }

    function numeric(value) {
        if (value == null || value === '') return null;
        const result = Number(value);
        return Number.isFinite(result) ? result : null;
    }

    function setPanel(index) {
        state.panel = index;
        window.dispatchEvent(new CustomEvent('luxarcia:panel', { detail: index }));
        dashboardPanel.hidden = index !== 0;
        editorPanel.hidden = index !== 1;
        smartPanel.hidden = index !== 2;
        wizardPanel.hidden = index !== 3;
        navigation.querySelectorAll('[data-panel]').forEach((button) => {
            const active = Number(button.dataset.panel) === index;
            button.classList.toggle('active', active);
            button.setAttribute('aria-current', active ? 'page' : 'false');
        });
    }

    function renderNavigation() {
        const locale = window.Locales && window.Locales[state.language];
        const modules = locale && Array.isArray(locale.panels) ? locale.panels : [];
        navigation.innerHTML = modules.map((name, index) => {
            const enabled = true;
            const active = state.panel === index;
            const soon = enabled ? '' : `<small class="nav-state">${t('moduleComingSoon')}</small>`;
            const title = enabled ? '' : `title="${t('moduleComingSoon')}"`;
            return `<button class="nav-item${active ? ' active' : ''}" type="button" data-panel="${index}" ${enabled ? '' : 'disabled'} aria-current="${active ? 'page' : 'false'}" ${title}><span class="nav-index">${String(index + 1).padStart(2, '0')}</span><span class="nav-label">${name}</span>${soon}</button>`;
        }).join('');
    }

    function sameValue(current, original) {
        if (current && original && typeof current === 'object' && typeof original === 'object') {
            return ['x', 'y', 'z'].every((axis) => {
                const left = numeric(current[axis]);
                const right = numeric(original[axis]);
                return left !== null && right !== null && Math.abs(left - right) <= 0.000001;
            });
        }
        const left = numeric(current);
        const right = numeric(original);
        return left !== null && right !== null ? Math.abs(left - right) <= 0.000001 : current === original;
    }

    function modifiedCount() {
        return state.schema.reduce((count, field) => {
            const name = field.field;
            return count + (Object.prototype.hasOwnProperty.call(state.values, name) && !sameValue(state.values[name], state.original[name]) ? 1 : 0);
        }, 0);
    }

    function renderDashboard() {
        const vehicle = state.vehicle || {};
        const telemetry = state.telemetry || {};
        const locale = window.Locales && window.Locales[state.language];
        const classes = locale && Array.isArray(locale.classes) ? locale.classes : [];
        const modelName = vehicle.modelName || vehicle.name || '';
        const classId = numeric(vehicle.class);
        const speed = numeric(telemetry.speed);
        const rpm = numeric(telemetry.normalizedRpm ?? telemetry.rpm);
        const gear = numeric(telemetry.gear);
        const health = numeric(telemetry.engineHealth);

        document.getElementById('vehicle-name').textContent = modelName || t('noVehicle');
        document.getElementById('dashboard-model').textContent = modelName || '—';
        document.getElementById('vehicle-hash').textContent = vehicle.modelHash == null ? '—' : `${t('vehicleHash')}: ${vehicle.modelHash}`;
        document.getElementById('vehicle-class').textContent = classId === null ? '—' : (classes[classId] || `${state.language === 'tr' ? 'Sınıf' : 'Class'} ${classId}`);
        document.getElementById('vehicle-speed').textContent = speed === null ? '—' : speed.toFixed(1);
        document.getElementById('vehicle-rpm').textContent = rpm === null ? '—' : String(Math.round(rpm * 100));
        document.getElementById('vehicle-gear').textContent = gear === null ? '—' : String(gear);
        document.getElementById('vehicle-health').textContent = health === null ? '—' : health.toFixed(0);
        document.getElementById('tuning-profile').textContent = String(vehicle.tuningProfile || vehicle.profile || t('notSet'));
        document.getElementById('modified-count').textContent = `${modifiedCount()} / ${state.schema.length || 46}`;

        const hasVehicle = Boolean(modelName || vehicle.modelHash != null);
        const status = document.getElementById('vehicle-status');
        status.textContent = hasVehicle ? t('vehicleReady') : t('vehicleUnavailable');
        status.classList.toggle('status-error', !hasVehicle);
    }

    function updateLanguage(language, persist) {
        state.language = language === 'tr' ? 'tr' : 'en';
        document.documentElement.lang = state.language;
        document.title = t('documentTitle');
        languageSelector.value = state.language;
        document.querySelectorAll('[data-i18n]').forEach((element) => {
            element.textContent = t(element.dataset.i18n);
        });
        const search = document.getElementById('parameter-search');
        const category = document.getElementById('category-filter');
        if (search) {
            search.placeholder = t('search');
            search.setAttribute('aria-label', t('searchLabel'));
        }
        if (category) category.setAttribute('aria-label', t('categoryLabel'));
        themeSelector.setAttribute('aria-label', t('theme'));
        languageSelector.setAttribute('aria-label', t('language'));
        navigation.setAttribute('aria-label', t('modules'));
        renderNavigation();
        renderDashboard();
        if (persist) savePreference('luxarcia-language', state.language);
        window.dispatchEvent(new CustomEvent('luxarcia:language', { detail: { language: state.language } }));
    }

    function updateTheme(theme, persist) {
        state.theme = themes.includes(theme) ? theme : themes[0];
        document.documentElement.dataset.theme = state.theme;
        themeSelector.value = state.theme;
        if (persist) savePreference('luxarcia-theme', state.theme);
    }

    function updateVehicle(payload) {
        const input = payload || {};
        state.vehicle = input.vehicle || input;
        state.telemetry = input.telemetry || null;
        state.values = input.values || {};
        state.original = input.original || {};
        state.schema = Array.isArray(input.schema) ? input.schema : [];
        renderDashboard();
    }

    function updateTelemetry(payload) {
        if (!payload || typeof payload !== 'object') return;
        state.telemetry = payload;
        if (payload.modelName || payload.modelHash != null || payload.class != null) {
            state.vehicle = { ...(state.vehicle || {}), ...payload };
        }
        renderDashboard();
    }

    function updateHandling(detail) {
        if (!detail) return;
        state.values = detail.values || state.values;
        state.original = detail.original || state.original;
        state.schema = detail.schema || state.schema;
        renderDashboard();
    }

    navigation.addEventListener('click', (event) => {
        const button = event.target.closest('[data-panel]');
        if (button && !button.disabled) setPanel(Number(button.dataset.panel));
    });
    document.getElementById('open-editor-button').addEventListener('click', () => setPanel(1));
    themeSelector.addEventListener('change', () => updateTheme(themeSelector.value, true));
    languageSelector.addEventListener('change', () => updateLanguage(languageSelector.value, true));

    window.luxarciaApp = {
        updateVehicle,
        updateTelemetry,
        updateHandling,
        hide() { app.classList.add('hidden'); },
        show() { app.classList.remove('hidden'); }
    };

    window.addEventListener('luxarcia:state', (event) => updateHandling(event.detail));
    window.addEventListener('luxarcia:tuning-profile', (event) => {
        const profile = event.detail && event.detail.profile;
        const locale = window.LuxarciaUI && window.LuxarciaUI.strings[state.language];
        const quickLabels = {
            improveAcceleration: 'quickAcceleration', increaseTopSpeed: 'quickTopSpeed', improveBraking: 'quickBraking',
            improveCornering: 'quickCornering', reduceWheelspin: 'quickWheelspin', improveStability: 'quickStability',
            improveSteering: 'quickSteering', balanceSuspension: 'quickSuspension'
        };
        const profileKey = `profile${profile}`;
        document.getElementById('tuning-profile').textContent = profile ? (locale && locale[profileKey] ? t(profileKey) : t(quickLabels[profile] || profile)) : t('notSet');
    });
    window.addEventListener('message', (event) => {
        const message = event.data || {};
        if (message.action === 'openEditor') {
            updateVehicle(message.payload || {});
            if (message.telemetry) updateTelemetry(message.telemetry);
            setPanel(0);
            window.luxarciaApp.show();
        } else if (message.action === 'closeEditor') {
            window.luxarciaApp.hide();
        } else if (message.type === 'telemetry') {
            updateTelemetry(message.data);
        }
    });

    updateTheme(preference('luxarcia-theme', themes[0]), false);
    updateLanguage(preference('luxarcia-language', 'en'), false);
    renderNavigation();
    setPanel(0);
});
