document.addEventListener('DOMContentLoaded', function() {
    const panel = document.getElementById('smart-panel');
    if (!panel || !window.Core) return;

    const dialog = document.getElementById('tuning-preview-dialog');
    const controls = {
        profile: document.getElementById('tuning-profile-select'),
        intensity: document.getElementById('tuning-intensity'),
        intensityOutput: document.getElementById('tuning-intensity-output'),
        previewProfile: document.getElementById('preview-profile-button'),
        score: document.getElementById('stability-score'),
        analysis: document.getElementById('analysis-results'),
        previewTitle: document.getElementById('preview-title'),
        previewSummary: document.getElementById('preview-summary'),
        previewFields: document.getElementById('preview-fields'),
        approve: document.getElementById('approve-tuning'),
        cancel: document.getElementById('cancel-tuning-preview'),
        wizardGoal: document.getElementById('wizard-goal'),
        wizardProgress: document.getElementById('wizard-progress'),
        wizardAnalysis: document.getElementById('wizard-analysis'),
        wizardResult: document.getElementById('wizard-result'),
        wizardResultSummary: document.getElementById('wizard-result-summary'),
        wizardAnalyze: document.getElementById('wizard-analyze'),
        wizardRecommend: document.getElementById('wizard-recommend'),
        wizardPreview: document.getElementById('wizard-preview'),
        wizardUndo: document.getElementById('wizard-undo')
    };
    const state = {
        values: null,
        baseline: null,
        schema: [],
        vehicle: null,
        intensity: 0.7,
        analysisMode: 'troubleshoot',
        pending: null,
        wizard: { step: 1, goal: 'Race', recommendation: null }
    };

    function t(key, values) {
        return window.LuxarciaUI ? window.LuxarciaUI.translate(key, values) : key;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
    }

    function formatValue(value) {
        if (value && typeof value === 'object') return `x ${Number(value.x).toFixed(3)} · y ${Number(value.y).toFixed(3)} · z ${Number(value.z).toFixed(3)}`;
        return typeof value === 'number' ? value.toFixed(4).replace(/0+$/, '').replace(/\.$/, '') : String(value ?? '—');
    }

    function vehicleClassLabel() {
        const classId = state.vehicle && Number(state.vehicle.class);
        const language = document.documentElement.lang === 'tr' ? 'tr' : 'en';
        const classes = window.Locales && window.Locales[language] && window.Locales[language].classes;
        return classes && Number.isInteger(classId) ? classes[classId] || String(classId) : '—';
    }

    function tuningName(name) {
        const profileKey = `profile${name}`;
        const language = document.documentElement.lang === 'tr' ? 'tr' : 'en';
        const catalog = window.LuxarciaUI && window.LuxarciaUI.strings[language];
        if (catalog && catalog[profileKey]) return t(profileKey);
        const quickLabels = {
            improveAcceleration: 'quickAcceleration', increaseTopSpeed: 'quickTopSpeed', improveBraking: 'quickBraking',
            improveCornering: 'quickCornering', reduceWheelspin: 'quickWheelspin', improveStability: 'quickStability',
            improveSteering: 'quickSteering', balanceSuspension: 'quickSuspension'
        };
        return quickLabels[name] ? t(quickLabels[name]) : name;
    }

    function fieldNameList(fields) {
        return (fields || []).map(field => `<code>${escapeHtml(field)}</code>`).join(', ');
    }

    function analysisRows(issues) {
        if (!issues.length) return `<p class="analysis-empty">${t('noConfiguredWarnings')}</p>`;
        return issues.map(issue => {
            const description = document.documentElement.lang === 'tr' ? '' : issue.explanation || issue.rule || issue.detail || '';
            return `<article class="analysis-item severity-${escapeHtml(issue.severity || 'low')}">
                <div class="analysis-item-heading"><strong>${t(`issue_${issue.code}`)}</strong><span>${t(`severity_${issue.severity || 'low'}`)}</span></div>
                ${description ? `<p>${escapeHtml(description)}</p>` : ''}
                ${issue.fields && issue.fields.length ? `<small>${t('label_fields')}: ${fieldNameList(issue.fields)}</small>` : ''}
                ${issue.suggestion && document.documentElement.lang !== 'tr' ? `<small>${t('label_suggestion')}: ${escapeHtml(issue.suggestion)}</small>` : ''}
            </article>`;
        }).join('');
    }

    function runAnalysis(mode) {
        state.analysisMode = mode || state.analysisMode;
        const goalControls = document.getElementById('analysis-goal-conflicts');
        goalControls.hidden = false;
        if (!state.values || !state.schema.length) {
            controls.analysis.innerHTML = `<p class="analysis-empty">${t('noBaseline')}</p>`;
            return;
        }
        const report = state.analysisMode === 'health'
            ? window.Core.healthCheck(state.values, state.baseline, state.schema)
            : state.analysisMode === 'conflicts'
            ? { issues: window.Core.detectConflicts(state.values, Array.from(document.querySelectorAll('[data-analysis-goal]:checked'), input => input.value)) }
                : window.Core.troubleshoot(state.values);
        controls.analysis.innerHTML = analysisRows(report.issues || []);
        controls.score.textContent = String(window.Core.stabilityScore(state.values));
    }

    function updateWizardProgress() {
        const keys = ['wizardGoal', 'wizardStep2', 'wizardStep3', 'wizardStep4', 'wizardStep5', 'wizardStep6'];
        controls.wizardProgress.innerHTML = keys.map((key, index) => `<span class="wizard-step${index + 1 === state.wizard.step ? ' active' : ''}${index + 1 < state.wizard.step ? ' complete' : ''}">${escapeHtml(t(key))}</span>`).join('');
        controls.wizardRecommend.disabled = state.wizard.step < 2;
        controls.wizardPreview.disabled = state.wizard.step < 3 || !state.wizard.recommendation;
        controls.wizardResult.hidden = state.wizard.step !== 6;
    }

    function render() {
        controls.intensity.value = String(Math.round(state.intensity * 100));
        controls.intensityOutput.value = `${Math.round(state.intensity * 100)}%`;
        if (state.values && state.schema.length) {
            controls.score.textContent = String(window.Core.stabilityScore(state.values));
            runAnalysis(state.analysisMode);
        }
        updateWizardProgress();
    }

    function receiveState(detail) {
        if (!detail || !detail.values || !detail.original || !Array.isArray(detail.schema)) return;
        state.values = window.Core.clone(detail.values);
        state.baseline = window.Core.clone(detail.original);
        state.schema = detail.schema;
        state.vehicle = detail.vehicle || null;
        render();
    }

    function getProposal(name) {
        if (!state.baseline || !state.schema.length) throw Error('noBaseline');
        const classId = state.vehicle && state.vehicle.class;
        const result = window.Core.tuningPreview(state.baseline, name, state.intensity, classId, state.schema);
        const target = { ...state.values, ...result.proposal };
        const differences = window.Core.changes(state.values, target);
        return { result, target, differences, name };
    }

    function showPreview(name, effectKey, wizardMode) {
        let preview;
        try {
            preview = getProposal(name);
        } catch (error) {
            if (window.luxarciaEditor) window.luxarciaEditor.notify(t(error.message === 'noBaseline' ? 'noBaseline' : 'error_default'), true);
            return;
        }
        if (!preview.differences.length) {
            if (window.luxarciaEditor) window.luxarciaEditor.notify(t('noTuningChanges'), true);
            return;
        }

        state.pending = { ...preview, effectKey, wizardMode: Boolean(wizardMode) };
        controls.previewTitle.textContent = `${t('tuningPreview')} · ${tuningName(name)}`;
        controls.previewSummary.textContent = `${t('label_class')}: ${vehicleClassLabel()} · ${t('label_drivetrain')}: ${t(`drive_${window.Core.driveLayout(state.baseline)}`)} · ${t('tuningIntensity')}: ${Math.round(state.intensity * 100)}% · ${effectKey ? t(`effect_${effectKey}`) : t('profileExpectedEffect')}`;
        controls.previewFields.innerHTML = `<table class="preview-table"><thead><tr><th>${t('parameter')}</th><th>${t('current')}</th><th>${t('proposed')}</th><th>${t('label_effect')}</th></tr></thead><tbody>${preview.differences.map(change => `<tr><td><code>${escapeHtml(change.field)}</code></td><td>${escapeHtml(formatValue(change.before))}</td><td>${escapeHtml(formatValue(change.after))}</td><td>${escapeHtml(t(`fieldEffect_${change.field}`))}</td></tr>`).join('')}</tbody></table>`;
        if (wizardMode) state.wizard.step = 4;
        updateWizardProgress();
        if (typeof dialog.showModal === 'function') dialog.showModal();
        else dialog.setAttribute('open', '');
    }

    function closePreview() {
        state.pending = null;
        if (dialog.open) dialog.close();
        else dialog.removeAttribute('open');
    }

    async function approvePreview() {
        const pending = state.pending;
        if (!pending) return;
        closePreview();
        if (pending.wizardMode) {
            state.wizard.step = 5;
            updateWizardProgress();
        }
        const response = await window.luxarciaEditor.applyChanges(pending.result.proposal, `tuning:${pending.name}`);
        if (!response) return;
        state.values = response.changed || state.values;
        window.dispatchEvent(new CustomEvent('luxarcia:tuning-profile', { detail: { profile: pending.name } }));
        if (window.luxarciaEditor.notify) window.luxarciaEditor.notify(t('tuningApplied', { profile: tuningName(pending.name), count: Object.keys(pending.result.proposal).length }));
        if (pending.wizardMode) {
            state.wizard.step = 6;
            controls.wizardResultSummary.textContent = t('tuningApplied', { profile: tuningName(pending.name), count: Object.keys(pending.result.proposal).length });
            updateWizardProgress();
        }
        render();
    }

    document.getElementById('tuning-intensity').addEventListener('input', event => {
        state.intensity = Number(event.target.value) / 100;
        controls.intensityOutput.value = `${event.target.value}%`;
    });
    controls.previewProfile.addEventListener('click', () => showPreview(controls.profile.value, null, false));
    document.getElementById('quick-tune-actions').addEventListener('click', event => {
        const button = event.target.closest('[data-quick]');
        if (button) showPreview(button.dataset.quick, button.dataset.quick, false);
    });
    document.querySelectorAll('[data-analysis]').forEach(button => button.addEventListener('click', () => {
        document.querySelectorAll('[data-analysis]').forEach(tab => tab.classList.toggle('active', tab === button));
        runAnalysis(button.dataset.analysis);
    }));
    document.querySelectorAll('[data-analysis-goal]').forEach(input => input.addEventListener('change', () => {
        document.querySelectorAll('[data-analysis]').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.analysis === 'conflicts');
        });
        runAnalysis('conflicts');
    }));
    controls.cancel.addEventListener('click', closePreview);
    dialog.addEventListener('cancel', event => { event.preventDefault(); closePreview(); });
    controls.approve.addEventListener('click', approvePreview);

    controls.wizardAnalyze.addEventListener('click', () => {
        if (!state.values || !state.baseline) {
            controls.wizardAnalysis.textContent = t('noBaseline');
            return;
        }
        state.wizard.goal = controls.wizardGoal.value;
        state.wizard.step = 2;
        const report = window.Core.troubleshoot(state.values);
        const health = window.Core.healthCheck(state.values, state.baseline, state.schema);
        const conflicts = window.Core.detectConflicts(state.values, [state.wizard.goal]);
        controls.wizardAnalysis.innerHTML = `<p>${escapeHtml(t('label_class'))}: ${escapeHtml(vehicleClassLabel())} · ${escapeHtml(t('label_drivetrain'))}: ${escapeHtml(t(`drive_${window.Core.driveLayout(state.baseline)}`))}</p><p>${escapeHtml(t('troubleshooter'))}: ${report.issues.length} · ${escapeHtml(t('healthCheck'))}: ${health.issues.length} · ${escapeHtml(t('conflictDetector'))}: ${conflicts.length}</p>${analysisRows([...report.issues, ...health.issues, ...conflicts])}`;
        updateWizardProgress();
    });
    controls.wizardRecommend.addEventListener('click', () => {
        if (state.wizard.step < 2) return;
        state.wizard.goal = controls.wizardGoal.value;
        try {
            state.wizard.recommendation = getProposal(state.wizard.goal);
            state.wizard.step = 3;
            controls.wizardAnalysis.insertAdjacentHTML('beforeend', `<p class="wizard-recommendation">${escapeHtml(t('wizardRecommendedProfile', { profile: t(`profile${state.wizard.goal}`), category: vehicleClassLabel() }))}</p>`);
        } catch (_) {
            controls.wizardAnalysis.textContent = t('noBaseline');
        }
        updateWizardProgress();
    });
    controls.wizardPreview.addEventListener('click', () => {
        if (state.wizard.step >= 3) showPreview(state.wizard.goal, null, true);
    });
    controls.wizardUndo.addEventListener('click', async () => {
        const result = await window.luxarciaEditor.undo();
        if (result) {
            state.wizard.step = 2;
            state.wizard.recommendation = null;
            controls.wizardAnalysis.textContent = t('tuningUndone');
            updateWizardProgress();
        }
    });
    controls.wizardGoal.addEventListener('change', () => {
        state.wizard.goal = controls.wizardGoal.value;
        state.wizard.recommendation = null;
        state.wizard.step = 1;
        controls.wizardAnalysis.textContent = '';
        updateWizardProgress();
    });

    window.addEventListener('luxarcia:state', event => receiveState(event.detail));
    window.addEventListener('luxarcia:language', render);
    window.addEventListener('luxarcia:vehicle', event => receiveState(event.detail));
    render();
});
