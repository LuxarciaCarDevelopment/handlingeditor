const resourceName = window.GetParentResourceName ? window.GetParentResourceName() : 'luxarcia_handling_v2';

function closeEditor() {
    const app = document.getElementById('luxarcia-app');
    if (app) {
        app.classList.add('hidden');
    }

    fetch(`https://${resourceName}/closeEditor`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

window.addEventListener('message', function(event) {
    const data = event.data || {};

    if (data.action === 'openEditor') {
        const payload = data.payload || {};

        if (window.luxarciaApp && typeof window.luxarciaApp.show === 'function') {
            window.luxarciaApp.show();
        }

        if (window.luxarciaApp && typeof window.luxarciaApp.updateVehicle === 'function') {
            window.luxarciaApp.updateVehicle(payload);
        }
    }

    if (data.action === 'closeEditor') {
        if (window.luxarciaApp && typeof window.luxarciaApp.hide === 'function') {
            window.luxarciaApp.hide();
        }
    }
});

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeEditor();
    }
});

document.getElementById('close-button').addEventListener('click', closeEditor);