document.addEventListener('DOMContentLoaded', () => {
    const app = document.getElementById('luxarcia-app');
    if (!app) {
        return;
    }

    const resourceName = window.GetParentResourceName ? window.GetParentResourceName() : 'luxarcia_handling_v2';
    const controls = {
        search: document.getElementById('parameter-search'),
        category: document.getElementById('category-filter'),
        modifiedOnly: document.getElementById('modified-only'),
        count: document.getElementById('parameter-count'),
        undo: document.getElementById('undo-button'),
        redo: document.getElementById('redo-button'),
        resetAll: document.getElementById('reset-all-button'),
        toast: document.getElementById('editor-toast'),
        list: document.getElementById('parameter-list')
    };

    const editorState = {
        schema: [],
        values: {},
        original: {},
        vehicle: null,
        generation: 0,
        history: [], cursor: 1,
        filter: '',
        category: 'All',
        modifiedOnly: false,
    };

    function t(key, values) {
        return window.LuxarciaUI ? window.LuxarciaUI.translate(key, values) : key;
    }

    function publishState() {
        window.dispatchEvent(new CustomEvent('luxarcia:state', {
            detail: {
                values: editorState.values,
                original: editorState.original,
                schema: editorState.schema,
                generation: editorState.generation,
                history: editorState.history, cursor: editorState.cursor,
                vehicle: editorState.vehicle
            }
        }));
    }

    function showToast(message, errorMode) {
        if (!controls.toast) {
            return;
        }

        controls.toast.textContent = message || t('error_default');
        controls.toast.classList.toggle('error', Boolean(errorMode));
        controls.toast.classList.add('visible');

        window.clearTimeout(showToast.timeoutId);
        showToast.timeoutId = window.setTimeout(() => {
            controls.toast.classList.remove('visible');
        }, 2500);
    }

    function valueToText(value) {
        if (value == null) {
            return '0';
        }

        if (typeof value === 'object' && value !== null && ('x' in value || 'y' in value || 'z' in value)) {
            return `${Number(value.x ?? 0).toFixed(3)}, ${Number(value.y ?? 0).toFixed(3)}, ${Number(value.z ?? 0).toFixed(3)}`;
        }

        return String(value);
    }

    function isModified(fieldName) {
        const current = editorState.values[fieldName];
        const original = editorState.original[fieldName];

        if (typeof current === 'object' && current && typeof original === 'object' && original) {
            return current.x !== original.x || current.y !== original.y || current.z !== original.z;
        }

        return current !== original;
    }

    function parseFieldValue(field, rawValue) {
        if (!field) {
            return null;
        }

        const value = rawValue == null ? '' : String(rawValue).trim();

        if (field.type === 'vector') {
            const chunks = value.split(',').map((part) => Number(part.trim()));
            if (chunks.length !== 3 || chunks.some((part) => !Number.isFinite(part))) {
                return null;
            }

            return { x: chunks[0], y: chunks[1], z: chunks[2] };
        }

        if (field.type === 'int') {
            const parsed = Number(value);
            if (!Number.isInteger(parsed)) {
                return null;
            }
            return parsed;
        }

        const parsed = Number(value);
        if (!Number.isFinite(parsed)) {
            return null;
        }

        return parsed;
    }

    function buildCategoryOptions() {
        if (!controls.category) {
            return;
        }

        const categories = Array.from(new Set((editorState.schema || []).map((field) => field.category || 'General'))).sort();
        const currentValue = editorState.category;
        controls.category.innerHTML = ['All', ...categories].map((category) => {
            const selected = category === currentValue ? 'selected' : '';
            const label = category === 'All' ? t('allCategories') : category === 'General' ? t('general') : category;
            return `<option value="${category}" ${selected}>${label}</option>`;
        }).join('');
    }

    function getVisibleFields() {
        const searchTerm = (editorState.filter || '').trim().toLowerCase();
        return (editorState.schema || []).filter((field) => {
            const label = `${field.field || ''} ${field.type || ''} ${field.category || 'General'} ${(field.description || '')}`.toLowerCase();
            const matchesSearch = !searchTerm || label.includes(searchTerm);
            const matchesCategory = editorState.category === 'All' || (field.category || 'General') === editorState.category;
            const matchesModified = !editorState.modifiedOnly || isModified(field.field);
            return matchesSearch && matchesCategory && matchesModified;
        });
    }

    function requestAction(endpoint, payload) {
        return fetch(`https://${resourceName}/${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload || {})
        }).then((response) => response.json().catch(() => ({}))).then((data) => {
            if (!data || !data.ok) {
                const errorMessage = data && data.error ? data.error : 'Request failed';
                showToast(window.LuxarciaUI ? window.LuxarciaUI.error(errorMessage) : errorMessage, true);
                return null;
            }

            if(data.history) {editorState.history=data.history;editorState.cursor=data.cursor;}
            return data;
        }).catch((error) => {
            showToast(window.LuxarciaUI ? window.LuxarciaUI.error(error && error.message) : 'Action failed', true);
            return null;
        });
    }

    function renderParameterList() {
        if (!controls.list) {
            return;
        }

        const visibleFields = getVisibleFields();
        if (controls.count) {
            controls.count.textContent = `${visibleFields.length} ${t(visibleFields.length === 1 ? 'matchOne' : 'matchMany')}`;
        }

        controls.list.innerHTML = visibleFields.map((field) => {
            const value = editorState.values[field.field];
            const originalValue = editorState.original[field.field];
            const modified = isModified(field.field);
            const inputType = field.type === 'vector' ? 'text' : field.type === 'int' ? 'number' : 'number';
            const step = field.type === 'int' ? '1' : '0.001';
            const rawValue = valueToText(value);
            const originalText = valueToText(originalValue);

            return `
                <div class="parameter-row ${modified ? 'modified' : ''}">
                    <div class="parameter-meta">
                        <strong>${field.field}</strong>
                        <span>${field.type || 'float'} · ${field.category || t('general')}</span>
                    </div>
                    <div class="parameter-controls">
                        <label>${t('current')}</label>
                        <input type="${inputType}" step="${step}" value="${rawValue}" title="${t('current')}: ${field.field}" aria-label="${t('current')}: ${field.field}" data-field="${field.field}" data-type="${field.type || 'float'}">
                    </div>
                    <div class="parameter-inline">
                        <small>${t('original')}</small>
                        <span>${originalText}</span>
                        <button class="reset-field-btn" title="${t('reset')} ${field.field}" aria-label="${t('reset')} ${field.field}" type="button" data-field="${field.field}">${t('reset')}</button>
                    </div>
                </div>
            `;
        }).join('');

        controls.list.querySelectorAll('input[data-field]').forEach((input) => {
            const fieldName = input.dataset.field;
            input.addEventListener('change', () => {
                const fieldEntry = (editorState.schema || []).find((field) => field.field === fieldName);
                if (!fieldEntry) {
                    return;
                }

                const parsed = parseFieldValue(fieldEntry, input.value);
                if (parsed === null) {
                    showToast(t('invalidValue', { field: fieldName }), true);
                    input.value = valueToText(editorState.values[fieldName]);
                    return;
                }

                window.luxarciaEditor.applyField(fieldName, parsed);
            });
        });

        controls.list.querySelectorAll('.reset-field-btn').forEach((button) => {
            button.addEventListener('click', () => {
                const fieldName = button.dataset.field;
                window.luxarciaEditor.resetField(fieldName);
            });
        });
    }

    window.luxarciaEditor = {
        notify(message, errorMode) {
            showToast(message, errorMode);
        },
        setState(nextState) {
            Object.assign(editorState, nextState);
            renderParameterList();
        },
        loadFromPayload(payload) {
            const schema = Array.isArray(payload && payload.schema) ? payload.schema : [];
            const values = payload && payload.values ? payload.values : {};
            const original = payload && payload.original ? payload.original : {};

            editorState.schema = schema;
            editorState.values = values;
            editorState.original = original;
            editorState.vehicle = payload && payload.vehicle ? payload.vehicle : null;
            editorState.generation = payload && payload.generation ? payload.generation : 0;
            editorState.history=payload.history || [{label:'original',time:0,values:original}];
            editorState.cursor=payload.cursor || 1;
            buildCategoryOptions();
            renderParameterList();
            publishState();
        },
        applyField(fieldName, value) {
            if (!fieldName || !editorState.values) {
                return Promise.resolve(null);
            }

            const payload = { generation: editorState.generation, label: 'manual', values: { [fieldName]: value } };
            const previousValue = editorState.values[fieldName];

            editorState.values[fieldName] = value;
            renderParameterList();

            return requestAction('applyHandling', payload).then((data) => {
                if (!data) {
                    editorState.values[fieldName] = previousValue;
                    renderParameterList();
                    return null;
                }

                if (data.generation) {
                    editorState.generation = data.generation;
                }
                if (data.changed) editorState.values = data.changed;
                publishState();
                renderParameterList();
                showToast(t('applySuccess', { field: fieldName }), false);
                return data;
            });
        },
        applyChanges(changes, label) {
            if (!changes || typeof changes !== 'object' || !Object.keys(changes).length) {
                showToast(t('noTuningChanges'), true);
                return Promise.resolve(null);
            }

            try {
                if (window.Core) window.Core.validate(changes, editorState.schema);
            } catch (error) {
                showToast(window.LuxarciaUI ? window.LuxarciaUI.error(error.message) : error.message, true);
                return Promise.resolve(null);
            }

            return requestAction('applyHandling', {
                generation: editorState.generation,
                label: label || 'tuning',
                values: changes
            }).then((data) => {
                if (!data) return null;
                if (data.generation) editorState.generation = data.generation;
                if (data.changed) editorState.values = data.changed;
                publishState();
                renderParameterList();
                return data;
            });
        },
        undo() {
            return requestAction('undoHandling', {}).then((data) => {
                if (!data) {
                    return null;
                }

                if (data.values) {
                    editorState.values = data.values;
                }
                if (data.generation) editorState.generation = data.generation;
                publishState();
                showToast(t('undoSuccess'), false);
                renderParameterList();
                return data;
            });
        },
        redo() {
            return requestAction('redoHandling', {}).then((data) => {
                if (!data) {
                    return null;
                }

                if (data.values) {
                    editorState.values = data.values;
                }
                if (data.generation) editorState.generation = data.generation;
                publishState();
                showToast(t('redoSuccess'), false);
                renderParameterList();
                return data;
            });
        },
        resetField(fieldName) {
            if (!fieldName) {
                return Promise.resolve(null);
            }

            const confirmed = window.confirm(t('confirmFieldReset', { field: fieldName }));
            if (!confirmed) {
                return Promise.resolve(null);
            }

            return requestAction('resetField', { fieldName }).then((data) => {
                if (!data || !data.ok) {
                    return null;
                }

                if (data.values) {
                    editorState.values = data.values;
                }
                if (data.generation) editorState.generation = data.generation;
                publishState();
                renderParameterList();
                showToast(t('fieldReset', { field: fieldName }), false);
                return data;
            });
        },
        resetAll() {
            const confirmed = window.confirm(t('confirmAllReset'));
            if (!confirmed) {
                return Promise.resolve(null);
            }

            return requestAction('resetAll', {}).then((data) => {
                if (!data || !data.ok) {
                    return null;
                }

                if (data.values) {
                    editorState.values = data.values;
                }
                if (data.generation) editorState.generation = data.generation;
                publishState();
                renderParameterList();
                showToast(t('allReset'), false);
                return data;
            });
        }
    };

    if (controls.search) {
        controls.search.addEventListener('input', (event) => {
            editorState.filter = event.target.value;
            renderParameterList();
        });
    }

    if (controls.category) {
        controls.category.addEventListener('change', (event) => {
            editorState.category = event.target.value || 'All';
            renderParameterList();
        });
    }

    if (controls.modifiedOnly) {
        controls.modifiedOnly.addEventListener('change', (event) => {
            editorState.modifiedOnly = !!event.target.checked;
            renderParameterList();
        });
    }

    if (controls.undo) {
        controls.undo.addEventListener('click', () => window.luxarciaEditor.undo());
    }

    if (controls.redo) {
        controls.redo.addEventListener('click', () => window.luxarciaEditor.redo());
    }

    if (controls.resetAll) {
        controls.resetAll.addEventListener('click', () => window.luxarciaEditor.resetAll());
    }

    window.addEventListener('luxarcia:language', () => {
        buildCategoryOptions();
        renderParameterList();
    });

    window.addEventListener('message', function(event) {
        const data = event.data || {};
        if (data.action === 'openEditor' && data.payload) {
            window.luxarciaEditor.loadFromPayload(data.payload);
        }

        if (data.action === 'closeEditor') {
            if (window.luxarciaApp && window.luxarciaApp.hide) {
                window.luxarciaApp.hide();
            }
        }
    });
});
