(function() {
    'use strict';

    const strings = {
        en: {
            brandSubtitle: 'VEHICLE DYNAMICS', modules: 'MODULES', theme: 'Theme', language: 'Language', documentTitle: 'Luxarcia Handling Editor',
            currentVehicle: 'CURRENT VEHICLE', close: 'Close', vehicleReady: 'Vehicle ready',
            overviewLabel: 'LIVE VEHICLE DATA', dashboard: 'Dashboard', live: 'Live', model: 'Model',
            vehicleClass: 'Vehicle class', speed: 'Speed', rpm: 'RPM · normalized', gear: 'Gear',
            engineHealth: 'Engine health', setupStatus: 'SETUP STATUS', handlingSummary: 'Handling summary',
            modifiedHandling: 'Modified handling fields', tuningProfile: 'Tuning profile', sessionStatus: 'Session',
            captured: 'Captured', notSet: 'Not set', activeTool: 'ACTIVE TOOL',
            manualEditor: 'Manual handling editor', editorDescription: 'Inspect and adjust supported handling values for this vehicle.',
            openEditor: 'Open handling editor', liveHandling: 'LIVE HANDLING SESSION', search: 'Search parameters...',
            searchLabel: 'Search handling parameters', allCategories: 'All categories', categoryLabel: 'Filter by category',
            modifiedOnly: 'Modified only', matchOne: 'match', matchMany: 'matches', undo: 'Undo', redo: 'Redo',
            resetAll: 'Reset all', current: 'Current', original: 'Original', reset: 'Reset',
            invalidValue: 'Enter a valid value for {field}.', updateFailed: 'Could not apply the value.',
            applySuccess: '{field} updated.', undoSuccess: 'Undo applied.', redoSuccess: 'Redo applied.',
            fieldReset: '{field} reset.', allReset: 'All handling values reset.',
            confirmFieldReset: 'Reset {field} to its captured original value?',
            confirmAllReset: 'Reset all handling values to their captured original values?', general: 'General', vehicleHash: 'Model hash',
            noVehicle: 'No vehicle detected', vehicleUnavailable: 'Vehicle telemetry unavailable',
            moduleComingSoon: 'Coming Soon', unavailable: 'Unavailable',
            error_invalidValues: 'Invalid handling values.', error_invalidVector: 'Invalid vector value.',
            error_invalidNumber: 'Invalid number.', error_invalidInteger: 'Invalid integer.',
            error_invalidRange: 'Value is outside the allowed range.', error_unknownField: 'Unknown handling field.',
            error_staleGeneration: 'Vehicle state changed. Reopen the editor.',
            error_staleVehicle: 'The active vehicle changed. Reopen the editor.',
            error_noControl: 'Network control of this vehicle is unavailable.',
            error_unauthorized: 'Open the editor through the authorized /handling command.',
            error_InvalidVehicle: 'The current vehicle is unavailable.',
            error_NoUndo: 'There is no earlier change to undo.', error_NoRedo: 'There is no later change to redo.',
            error_default: 'The action could not be completed.', tuningSuite: 'DETERMINISTIC PRO TUNING', smartTuning: 'Smart Tuning', staticEstimate: 'STATIC HANDLING ANALYSIS',
            profile: 'Profile', tuneFromBaseline: 'Tune from captured baseline', drivingProfile: 'Driving profile', profileRace: 'Race', profileDrift: 'Drift', profileSport: 'Sport', profileRealistic: 'Realistic', profileComfort: 'Comfort',
            tuningIntensity: 'Tuning intensity', baselineNote: 'Every preview is calculated from this session\'s captured original handling values.', previewProfile: 'Preview profile', quickTune: 'QUICK TUNE', singleGoalActions: 'Single-goal adjustments', quickAcceleration: 'Improve acceleration', quickTopSpeed: 'Increase top speed', quickBraking: 'Improve braking', quickCornering: 'Improve cornering', quickWheelspin: 'Reduce wheelspin', quickStability: 'Improve stability', quickSteering: 'Improve steering response', quickSuspension: 'Balance suspension',
            analysisTools: 'ANALYSIS TOOLS', handlingAnalysis: 'Handling analysis', estimatedScore: 'ESTIMATED SCORE', troubleshooter: 'Troubleshooter', healthCheck: 'Health check', conflictDetector: 'Conflict detector', goalsBeingCombined: 'Tuning goals being combined', staticDiagnosisNote: 'Static-value heuristics only. These tools do not observe driving behavior or certify safety.',
            guidedWorkflow: 'GUIDED WORKFLOW', tuningWizard: 'Advanced Tuning Wizard', approvalRequired: 'APPROVAL REQUIRED', wizardGoal: 'Step 1 · Select tuning goal', goalRace: 'Race pace', goalDrift: 'Controlled drift', goalSport: 'Balanced sport', goalRealistic: 'Realistic road setup', goalComfort: 'Comfort', wizardAnalyze: 'Analyze vehicle', wizardRecommend: 'Generate recommendations', wizardPreview: 'Preview changes', wizardComplete: 'Tuning applied', undoTuning: 'Undo tuning', tuningPreview: 'Tuning preview', cancel: 'Cancel', approveApply: 'Approve and apply',
            analysisPlaceholder: 'Run an analysis to review the configured handling values.', noConfiguredWarnings: 'No configured heuristic warnings.', wizardStep2: 'Step 2 · Analyze current handling', wizardStep3: 'Step 3 · Deterministic recommendations generated', wizardStep4: 'Step 4 · Review the complete parameter preview', wizardStep5: 'Step 5 · Apply only after approval', wizardStep6: 'Step 6 · Review results or undo',
            effect_improveAcceleration: 'Raises drive force and inertia modestly, with a small peak-traction adjustment.', effect_increaseTopSpeed: 'Raises the gearing speed reference and slightly reduces drag; it is not a guaranteed road speed.', effect_improveBraking: 'Raises service brake force; tyre grip and brake balance still govern the result.', effect_improveCornering: 'Raises peak/sliding traction and anti-roll support.', effect_reduceWheelspin: 'Reduces drive force and low-speed traction loss, then raises sliding traction.', effect_improveStability: 'Reduces traction loss and steering sensitivity while raising anti-roll support.', effect_improveSteering: 'Raises steering lock and lateral traction response.', effect_balanceSuspension: 'Raises compression/rebound damping and anti-roll support in small increments.',
            severity_high: 'High', severity_medium: 'Medium', severity_low: 'Low',
            issue_excessiveWheelspin: 'Wheelspin potential', issue_poorAcceleration: 'Low acceleration response', issue_weakBraking: 'Weak braking potential', issue_oversteer: 'Oversteer tendency', issue_understeer: 'Understeer tendency', issue_bodyRoll: 'Body-roll potential', issue_highSpeedInstability: 'High-speed steering sensitivity', issue_poorSteeringResponse: 'Low steering response', issue_excessiveTractionLoss: 'High traction loss',
            issue_unsupportedField: 'Unsupported handling field', issue_invalidValue: 'Invalid numeric or range value', issue_excessDriveForce: 'Excessive drive force', issue_excessBrakeForce: 'Excessive brake force', issue_excessTraction: 'Excessive peak traction', issue_extremeBrakeBias: 'Extreme brake bias', issue_extremeSuspension: 'Extreme suspension settings', issue_unstableTractionOrder: 'Inconsistent traction ordering', issue_unrealisticChange: 'Large baseline-relative change',
            issue_driveTractionConflict: 'Drive force / traction conflict', issue_steeringTractionConflict: 'Steering / traction-loss conflict', issue_brakeBalanceConflict: 'Brake force / balance conflict', issue_suspensionDampingConflict: 'Spring / damping conflict', issue_goalConflict: 'Opposing tuning goals',
            tuningApplied: '{profile} applied to {count} fields.', tuningUndone: 'Tuning change undone.', noTuningChanges: 'This preview contains no changes.', noBaseline: 'Open an authorized vehicle session before tuning.',
            label_rule: 'Rule', label_suggestion: 'Suggested fix', label_fields: 'Fields', label_effect: 'Expected effect', label_class: 'Vehicle class', label_drivetrain: 'Drivetrain', label_baseline: 'Captured baseline', label_scoreFormula: 'Score formula', scoreFormulaText: 'Start at 100. Subtract: 25 for invalid suspension travel; 20 for sliding traction above peak; 10 for brake bias outside 0.35–0.80; 10 for steering lock over 45 with speed reference over 180; 5 for anti-roll force under 0.2; 15 for center-of-mass Z over 0.2; 5 for traction loss over 2; and 5 for compression damping over 1.5× spring force. Clamp to 0–100. This is an estimate, not a native metric.', parameter: 'Parameter', proposed: 'Proposed', profileExpectedEffect: 'Deterministic changes to the configured fields shown below.', wizardRecommendedProfile: 'Vehicle category {category}: deterministic {profile} recommendations generated from the captured baseline.',
            drive_rear: 'Rear-wheel drive', drive_front: 'Front-wheel drive', drive_all: 'All-wheel drive', drive_unknown: 'Unspecified drivetrain',
            fieldEffect_fInitialDriveForce: 'Changes engine drive-force response.', fieldEffect_fDriveInertia: 'Changes rotational response.', fieldEffect_fClutchChangeRateScaleUpShift: 'Changes upshift clutch response.', fieldEffect_fClutchChangeRateScaleDownShift: 'Changes downshift clutch response.', fieldEffect_fBrakeForce: 'Changes service brake force.', fieldEffect_fBrakeBiasFront: 'Changes front brake share.', fieldEffect_fTractionCurveMax: 'Changes peak traction.', fieldEffect_fTractionCurveMin: 'Changes sliding traction.', fieldEffect_fTractionLossMult: 'Changes surface traction loss.', fieldEffect_fLowSpeedTractionLossMult: 'Changes low-speed traction loss.', fieldEffect_fSteeringLock: 'Changes maximum steering lock.', fieldEffect_fTractionCurveLateral: 'Changes lateral traction response.', fieldEffect_fSuspensionForce: 'Changes spring force.', fieldEffect_fSuspensionCompDamp: 'Changes compression damping.', fieldEffect_fSuspensionReboundDamp: 'Changes rebound damping.', fieldEffect_fAntiRollBarForce: 'Changes anti-roll support.', fieldEffect_fInitialDriveMaxFlatVel: 'Changes gearing speed reference, not guaranteed top speed.', fieldEffect_fInitialDragCoeff: 'Changes aerodynamic drag reference.', fieldEffect_fTractionBiasFront: 'Changes front traction share.'
        },
        tr: {
            brandSubtitle: 'ARAÇ DİNAMİKLERİ', modules: 'MODÜLLER', theme: 'Tema', language: 'Dil', documentTitle: 'Luxarcia Handling Editörü',
            currentVehicle: 'MEVCUT ARAÇ', close: 'Kapat', vehicleReady: 'Araç hazır',
            overviewLabel: 'CANLI ARAÇ VERİLERİ', dashboard: 'Ana Panel', live: 'Canlı', model: 'Model',
            vehicleClass: 'Araç sınıfı', speed: 'Hız', rpm: 'RPM · normalize', gear: 'Vites',
            engineHealth: 'Motor sağlığı', setupStatus: 'AYAR DURUMU', handlingSummary: 'Handling özeti',
            modifiedHandling: 'Değiştirilmiş handling alanları', tuningProfile: 'Tuning profili', sessionStatus: 'Oturum',
            captured: 'Kaydedildi', notSet: 'Ayarlanmadı', activeTool: 'ETKİN ARAÇ',
            manualEditor: 'Manuel handling editörü', editorDescription: 'Bu araç için desteklenen handling değerlerini inceleyin ve düzenleyin.',
            openEditor: 'Handling editörünü aç', liveHandling: 'CANLI HANDLING OTURUMU', search: 'Parametreleri ara...',
            searchLabel: 'Handling parametrelerini ara', allCategories: 'Tüm kategoriler', categoryLabel: 'Kategoriye göre filtrele',
            modifiedOnly: 'Yalnızca değişenler', matchOne: 'sonuç', matchMany: 'sonuç', undo: 'Geri al', redo: 'Yinele',
            resetAll: 'Tümünü sıfırla', current: 'Mevcut', original: 'Orijinal', reset: 'Sıfırla',
            invalidValue: '{field} için geçerli bir değer girin.', updateFailed: 'Değer uygulanamadı.',
            applySuccess: '{field} güncellendi.', undoSuccess: 'Değişiklik geri alındı.', redoSuccess: 'Değişiklik yinelendi.',
            fieldReset: '{field} sıfırlandı.', allReset: 'Tüm handling değerleri sıfırlandı.',
            confirmFieldReset: '{field} yakalanan orijinal değerine sıfırlansın mı?',
            confirmAllReset: 'Tüm handling değerleri yakalanan orijinal değerlerine sıfırlansın mı?', general: 'Genel', vehicleHash: 'Model hash',
            noVehicle: 'Araç algılanmadı', vehicleUnavailable: 'Araç telemetrisi kullanılamıyor',
            moduleComingSoon: 'Yakında', unavailable: 'Kullanılamıyor',
            error_invalidValues: 'Handling değerleri geçersiz.', error_invalidVector: 'Vektör değeri geçersiz.',
            error_invalidNumber: 'Sayı geçersiz.', error_invalidInteger: 'Tam sayı geçersiz.',
            error_invalidRange: 'Değer izin verilen aralığın dışında.', error_unknownField: 'Handling alanı bilinmiyor.',
            error_staleGeneration: 'Araç durumu değişti. Editörü yeniden açın.',
            error_staleVehicle: 'Etkin araç değişti. Editörü yeniden açın.',
            error_noControl: 'Bu araç için ağ kontrolü alınamıyor.',
            error_unauthorized: 'Editörü yetkili /handling komutuyla açın.',
            error_InvalidVehicle: 'Mevcut araç kullanılamıyor.',
            error_NoUndo: 'Geri alınacak önceki değişiklik yok.', error_NoRedo: 'Yinelenecek sonraki değişiklik yok.',
            error_default: 'İşlem tamamlanamadı.', tuningSuite: 'BELİRLİ PRO TUNING', smartTuning: 'Akıllı Tuning', staticEstimate: 'STATİK HANDLING ANALİZİ',
            profile: 'Profil', tuneFromBaseline: 'Kaydedilen başlangıç değerlerinden ayarla', drivingProfile: 'Sürüş profili', profileRace: 'Yarış', profileDrift: 'Drift', profileSport: 'Spor', profileRealistic: 'Gerçekçi', profileComfort: 'Konfor',
            tuningIntensity: 'Tuning yoğunluğu', baselineNote: 'Her önizleme bu oturumda yakalanan orijinal handling değerlerinden hesaplanır.', previewProfile: 'Profili önizle', quickTune: 'HIZLI TUNING', singleGoalActions: 'Tek hedefli ayarlar', quickAcceleration: 'Hızlanmayı iyileştir', quickTopSpeed: 'Azami hızı artır', quickBraking: 'Frenlemeyi iyileştir', quickCornering: 'Virajı iyileştir', quickWheelspin: 'Teker patinajını azalt', quickStability: 'Stabiliteyi artır', quickSteering: 'Direksiyon tepkisini iyileştir', quickSuspension: 'Süspansiyonu dengele',
            analysisTools: 'ANALİZ ARAÇLARI', handlingAnalysis: 'Handling analizi', estimatedScore: 'TAHMİNİ PUAN', troubleshooter: 'Sorun giderici', healthCheck: 'Sağlık kontrolü', conflictDetector: 'Çakışma dedektörü', goalsBeingCombined: 'Birlikte seçilen tuning hedefleri', staticDiagnosisNote: 'Yalnızca statik değer sezgiselleri. Sürüş davranışını izlemez ve güvenliği belgelemez.',
            guidedWorkflow: 'YÖNLENDİRİLMİŞ AKIŞ', tuningWizard: 'Gelişmiş Tuning Sihirbazı', approvalRequired: 'ONAY GEREKLİ', wizardGoal: 'Adım 1 · Tuning hedefini seç', goalRace: 'Yarış temposu', goalDrift: 'Kontrollü drift', goalSport: 'Dengeli spor', goalRealistic: 'Gerçekçi yol ayarı', goalComfort: 'Konfor', wizardAnalyze: 'Aracı analiz et', wizardRecommend: 'Önerileri oluştur', wizardPreview: 'Değişiklikleri önizle', wizardComplete: 'Tuning uygulandı', undoTuning: 'Tuning işlemini geri al', tuningPreview: 'Tuning önizlemesi', cancel: 'İptal', approveApply: 'Onayla ve uygula',
            analysisPlaceholder: 'Yapılandırılmış handling değerlerini incelemek için analiz başlatın.', noConfiguredWarnings: 'Sezgisel uyarı bulunamadı.', wizardStep2: 'Adım 2 · Mevcut handling değerlerini analiz et', wizardStep3: 'Adım 3 · Belirli öneriler oluşturuldu', wizardStep4: 'Adım 4 · Tüm parametre önizlemesini incele', wizardStep5: 'Adım 5 · Yalnızca onaydan sonra uygula', wizardStep6: 'Adım 6 · Sonucu incele veya geri al',
            effect_improveAcceleration: 'Tahrik kuvvetini ve ataleti ölçülü artırır, tepe tutuşuna küçük ayar yapar.', effect_increaseTopSpeed: 'Aktarma hız referansını artırır, hava direncini hafif azaltır; yol hızı garantisi değildir.', effect_improveBraking: 'Servis fren kuvvetini artırır; lastik tutuşu ve fren dengesi belirleyicidir.', effect_improveCornering: 'Tepe/kayma tutuşunu ve viraj denge desteğini artırır.', effect_reduceWheelspin: 'Tahrik kuvveti ve düşük hız tutuş kaybını azaltır, kayma tutuşunu artırır.', effect_improveStability: 'Tutuş kaybı ve direksiyon hassasiyetini azaltır, viraj denge desteğini artırır.', effect_improveSteering: 'Direksiyon kilidi ve yanal tutuş tepkisini artırır.', effect_balanceSuspension: 'Sıkışma/geri açılma sönümlemesini ve viraj denge desteğini ölçülü artırır.',
            severity_high: 'Yüksek', severity_medium: 'Orta', severity_low: 'Düşük',
            issue_excessiveWheelspin: 'Patinaj olasılığı', issue_poorAcceleration: 'Düşük hızlanma tepkisi', issue_weakBraking: 'Zayıf frenleme olasılığı', issue_oversteer: 'Arkadan kayma eğilimi', issue_understeer: 'Önden kayma eğilimi', issue_bodyRoll: 'Gövde yatma olasılığı', issue_highSpeedInstability: 'Yüksek hızda direksiyon hassasiyeti', issue_poorSteeringResponse: 'Düşük direksiyon tepkisi', issue_excessiveTractionLoss: 'Yüksek tutuş kaybı',
            issue_unsupportedField: 'Desteklenmeyen handling alanı', issue_invalidValue: 'Geçersiz sayı veya aralık', issue_excessDriveForce: 'Aşırı tahrik kuvveti', issue_excessBrakeForce: 'Aşırı fren kuvveti', issue_excessTraction: 'Aşırı tepe tutuşu', issue_extremeBrakeBias: 'Aşırı fren dengesi', issue_extremeSuspension: 'Aşırı süspansiyon ayarı', issue_unstableTractionOrder: 'Tutarsız tutuş sıralaması', issue_unrealisticChange: 'Başlangıca göre büyük değişiklik',
            issue_driveTractionConflict: 'Tahrik kuvveti / tutuş çakışması', issue_steeringTractionConflict: 'Direksiyon / tutuş kaybı çakışması', issue_brakeBalanceConflict: 'Fren kuvveti / denge çakışması', issue_suspensionDampingConflict: 'Yay / sönümleme çakışması', issue_goalConflict: 'Birbirine zıt tuning hedefleri',
            tuningApplied: '{profile}, {count} alana uygulandı.', tuningUndone: 'Tuning değişikliği geri alındı.', noTuningChanges: 'Bu önizlemede değişiklik yok.', noBaseline: 'Tuning için yetkili bir araç oturumu açın.',
            label_rule: 'Kural', label_suggestion: 'Önerilen düzeltme', label_fields: 'Alanlar', label_effect: 'Beklenen etki', label_class: 'Araç sınıfı', label_drivetrain: 'Aktarma', label_baseline: 'Kaydedilen başlangıç', label_scoreFormula: 'Puan formülü', scoreFormulaText: '100 puanla başla. Şunları çıkar: geçersiz süspansiyon hareketi için 25; kayma tutuşu tepeyi aşarsa 20; fren dengesi 0,35–0,80 dışındaysa 10; hız referansı 180 üzerindeyken direksiyon kilidi 45 üzerindeyse 10; viraj denge kuvveti 0,2 altındaysa 5; ağırlık merkezi Z değeri 0,2 üzerindeyse 15; tutuş kaybı 2 üzerindeyse 5; sıkışma sönümlemesi yay kuvvetinin 1,5 katını aşarsa 5. Sonucu 0–100 aralığında tut. Bu tahmindir, yerel bir metrik değildir.', parameter: 'Parametre', proposed: 'Önerilen', profileExpectedEffect: 'Aşağıdaki alanlarda belirli tuning değişiklikleri önerilir.', wizardRecommendedProfile: '{category} araç kategorisi için kaydedilen başlangıçtan belirli {profile} önerileri oluşturuldu.',
            drive_rear: 'Arkadan itiş', drive_front: 'Önden çekiş', drive_all: 'Dört tekerlekten çekiş', drive_unknown: 'Belirtilmemiş aktarma',
            fieldEffect_fInitialDriveForce: 'Motor tahrik kuvveti tepkisini değiştirir.', fieldEffect_fDriveInertia: 'Dönüş tepkisini değiştirir.', fieldEffect_fClutchChangeRateScaleUpShift: 'Vites yükseltme debriyaj tepkisini değiştirir.', fieldEffect_fClutchChangeRateScaleDownShift: 'Vites düşürme debriyaj tepkisini değiştirir.', fieldEffect_fBrakeForce: 'Servis fren kuvvetini değiştirir.', fieldEffect_fBrakeBiasFront: 'Ön fren payını değiştirir.', fieldEffect_fTractionCurveMax: 'Tepe tutuşunu değiştirir.', fieldEffect_fTractionCurveMin: 'Kayma tutuşunu değiştirir.', fieldEffect_fTractionLossMult: 'Zemin tutuş kaybını değiştirir.', fieldEffect_fLowSpeedTractionLossMult: 'Düşük hız tutuş kaybını değiştirir.', fieldEffect_fSteeringLock: 'Azami direksiyon kilidini değiştirir.', fieldEffect_fTractionCurveLateral: 'Yanal tutuş tepkisini değiştirir.', fieldEffect_fSuspensionForce: 'Yay kuvvetini değiştirir.', fieldEffect_fSuspensionCompDamp: 'Sıkışma sönümlemesini değiştirir.', fieldEffect_fSuspensionReboundDamp: 'Geri açılma sönümlemesini değiştirir.', fieldEffect_fAntiRollBarForce: 'Viraj denge desteğini değiştirir.', fieldEffect_fInitialDriveMaxFlatVel: 'Aktarma hız referansını değiştirir; gerçek azami hızı garanti etmez.', fieldEffect_fInitialDragCoeff: 'Aerodinamik direnç referansını değiştirir.', fieldEffect_fTractionBiasFront: 'Ön aks tutuş payını değiştirir.'
        }
    };

    function language() {
        return document.documentElement.lang === 'tr' ? 'tr' : 'en';
    }

    function translate(key, values) {
        const current = strings[language()];
        let result = current[key] || strings.en[key] || key;
        Object.keys(values || {}).forEach((name) => {
            result = result.replace(`{${name}}`, String(values[name]));
        });
        return result;
    }

    function error(raw) {
        const key = String(raw || '').split(':')[0];
        const mapped = {
            invalidValues: 'error_invalidValues', invalidVector: 'error_invalidVector',
            invalidNumber: 'error_invalidNumber', invalidInteger: 'error_invalidInteger',
            invalidRange: 'error_invalidRange', unknownField: 'error_unknownField',
            staleGeneration: 'error_staleGeneration', staleVehicle: 'error_staleVehicle',
            noControl: 'error_noControl', unauthorized: 'error_unauthorized', 'Invalid vehicle': 'error_InvalidVehicle',
            'Invalid Vehicle': 'error_InvalidVehicle'
        };
        if (key === 'No undo history available') return translate('error_NoUndo');
        if (key === 'No redo history available') return translate('error_NoRedo');
        return translate(mapped[key] || 'error_default');
    }

    window.LuxarciaUI = { strings, translate, error };
})();