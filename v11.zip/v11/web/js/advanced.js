document.addEventListener('DOMContentLoaded', () => {
  const frame = document.createElement('iframe');
  frame.id = 'advanced-tools'; frame.src = 'tools.html'; frame.title = 'LUXARCIA PRO'; frame.hidden = true;
  frame.style.cssText = 'width:100%;height:72vh;border:0;border-radius:12px';
  document.getElementById('wizard-panel').after(frame);
  let ready = false, payload, panel = 0;
  const send = message => { if (ready) frame.contentWindow.postMessage(message, location.origin); };
  const state = p => ({generation:p.generation,model:String(p.vehicle.modelHash),name:p.vehicle.modelName,class:p.vehicle.class,
    values:p.values,original:p.original,history:p.history || [{label:'original',values:p.original}],cursor:p.cursor || 1});
  function select(index) {
    panel = index; frame.hidden = index < 4;
    send({type:'toolPanel',panel:index,language:document.documentElement.lang,theme:document.documentElement.dataset.theme});
  }
  function open() { if(payload) { send({type:'open',state:state(payload),flags:payload.flags || {smart:true,telemetry:true,tests:true,presets:true,ai:false}}); setTimeout(()=>select(panel),0); } }
  window.addEventListener('message', e => {
    if(e.data?.type === 'toolsReady' && e.source === frame.contentWindow) { ready=true; open(); }
    if(e.data?.action === 'openEditor') { payload=e.data.payload; panel=0;open(); }
    if(e.data?.action === 'closeEditor') send({type:'close'});
    if(e.data?.type === 'performance') send({type:'telemetry',data:e.data.data});
    if(e.data?.type === 'toolMutation' && e.source === frame.contentWindow) {
      payload={...payload,...e.data.payload};send({type:'toolState',state:state(payload)});
      window.luxarciaEditor.loadFromPayload(payload);
    }
  });
  window.addEventListener('luxarcia:panel', e=>select(e.detail));
  window.addEventListener('luxarcia:language', ()=>select(panel));
  new MutationObserver(()=>select(panel)).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
  window.addEventListener('luxarcia:state',e=>{ if(payload) {payload={...payload,...e.detail};send({type:'toolState',state:state(payload)});} });
});
