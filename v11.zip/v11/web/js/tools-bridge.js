'use strict';
// Reuse the existing advanced screens inside the current themed editor.
if (window.parent !== window) {
  window.GetParentResourceName = () => window.parent.GetParentResourceName();
  window.addEventListener('message', event => {
    if (event.source !== window.parent) return;
    const m = event.data;
    if (m.type === 'toolPanel') {
      S.panel = m.panel; S.language = m.language; S.group = 'all'; S.search = '';
      document.body.dataset.theme = m.theme;
      render();
    }
    if (m.type === 'toolState' && S.state) { S.state = m.state; render(); }
  });
  window.addEventListener('load', () => window.parent.postMessage({type:'toolsReady'}, location.origin));
}
