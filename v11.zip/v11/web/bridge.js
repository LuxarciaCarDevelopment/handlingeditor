/* Minimal fail-closed NUI bridge. Loaded before the editor so boot errors release focus. */
(function(){
  'use strict';
  function hide(){
    var app=document.getElementById('app');if(app)app.hidden=true;
    var dialog=document.getElementById('proposal');if(dialog&&dialog.open)dialog.close();
  }
  function post(action,data){
    if(typeof GetParentResourceName!=='function')return;
    try{
      fetch('https://'+GetParentResourceName()+'/action',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify(Object.assign({action:action},data||{}))
      }).catch(function(){});
    }catch(error){console.error('[LUXARCIA NUI] Native bridge unavailable',error);}
  }
  function fail(error){
    window.LuxarciaAppReady=false;hide();
    var details=String(error&&error.message||error||'Browser initialization failed').slice(0,500);
    console.error('[LUXARCIA NUI] '+details);post('uiError',{details:details});
  }
  window.LuxarciaBridge={fail:fail,hide:hide};
  window.addEventListener('error',function(event){fail(event.error||event.message);});
  window.addEventListener('unhandledrejection',function(event){fail(event.reason);});
  window.addEventListener('message',function(event){if(event.data&&event.data.type==='close')hide();});
  document.addEventListener('keydown',function(event){
    if(event.key==='Escape'&&!window.LuxarciaAppReady){hide();post('close');}
  });
  document.addEventListener('click',function(event){
    if(!window.LuxarciaAppReady&&event.target.closest&&event.target.closest('#close')){hide();post('close');}
  });
  hide();
})();
