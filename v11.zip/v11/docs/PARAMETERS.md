# 46-field catalog and native verification matrix

Generated from the shared catalog. Every row has passed mocked typed read/write/restore checks. Actual native readback and physical behavior remain pending real-server verification for every row.

The two vector fields expose x/y/z; 46 counts native fields, not scalar inputs. Native identifiers and their bilingual explanations are in web/schema.json.

Validation: finite = finite float32-representable; positive >0; nonnegative ≥0; bias 0–1; driveBias exactly 0, 0.1–0.9, or 1; percent >0–100; integer nonnegative signed-32-bit range; vector exactly finite x/y/z; positiveVector additionally requires positive components. Gear snapshots accept uint8 counts 1–255 to preserve native reads, but runtime changes are limited to 1–7 by the official setter. Captured stock counts above 7 remain readable/exportable and cannot be edited through this setter.

For each field record: original → change → readback → physical observation → undo → redo → reset → XML → reimport. Metadata such as monetary value is not a physics control. A successful readback is not evidence of a changed physical effect.

| # | Field | Native type | Validation | Explanation | In-game verified |
|---:|---|---|---|---|---|
| 1 | `fMass` | float | positive | Vehicle mass in kilograms; affects momentum and estimated power. | [ ] |
| 2 | `fInitialDragCoeff` | float | nonnegative | Aerodynamic drag coefficient; increasing it resists high speed. | [ ] |
| 3 | `fPercentSubmerged` | float | percent | Submersion percentage used by buoyancy behavior. | [ ] |
| 4 | `vecCentreOfMassOffset` | vector | vector | Local center of mass offset in metres; x right, y forward, z up. | [ ] |
| 5 | `vecInertiaMultiplier` | vector | positiveVector | Rotational inertia multipliers for the three local axes. | [ ] |
| 6 | `fDriveBiasFront` | float | driveBias | Front drive share: 0 rear drive, 1 front drive; intermediate native values must be 0.1–0.9. | [ ] |
| 7 | `nInitialDriveGears` | int | gears | Forward gear count; the FiveM handling setter caps it at 7; road verification is required. | [ ] |
| 8 | `fInitialDriveForce` | float | nonnegative | Drive force multiplier; influences acceleration, not measured horsepower. | [ ] |
| 9 | `fDriveInertia` | float | positive | Engine rotational response; higher values change rev response. | [ ] |
| 10 | `fClutchChangeRateScaleUpShift` | float | positive | Upshift clutch change rate multiplier. | [ ] |
| 11 | `fClutchChangeRateScaleDownShift` | float | positive | Downshift clutch change rate multiplier. | [ ] |
| 12 | `fInitialDriveMaxFlatVel` | float | positive | Engine gearing speed reference; not a guaranteed road top speed. | [ ] |
| 13 | `fBrakeForce` | float | nonnegative | Service brake force multiplier; tyre grip still limits braking. | [ ] |
| 14 | `fBrakeBiasFront` | float | bias | Front brake share between zero and one. | [ ] |
| 15 | `fHandBrakeForce` | float | nonnegative | Handbrake force multiplier. | [ ] |
| 16 | `fSteeringLock` | float | positive | Maximum steering lock in degrees; does not represent current wheel angle. | [ ] |
| 17 | `fTractionCurveMax` | float | positive | Peak traction curve coefficient. | [ ] |
| 18 | `fTractionCurveMin` | float | positive | Sliding traction curve coefficient. | [ ] |
| 19 | `fTractionCurveLateral` | float | positive | Lateral traction curve angle in degrees. | [ ] |
| 20 | `fTractionSpringDeltaMax` | float | positive | Suspension travel contribution to traction response. | [ ] |
| 21 | `fLowSpeedTractionLossMult` | float | nonnegative | Low speed traction loss multiplier. | [ ] |
| 22 | `fCamberStiffnesss` | float | finite | Camber stiffness coefficient; native field intentionally has three s letters. | [ ] |
| 23 | `fTractionBiasFront` | float | bias | Front traction distribution fraction. | [ ] |
| 24 | `fTractionLossMult` | float | nonnegative | Traction loss multiplier across surfaces. | [ ] |
| 25 | `fSuspensionForce` | float | positive | Spring force multiplier. | [ ] |
| 26 | `fSuspensionCompDamp` | float | nonnegative | Compression damping coefficient. | [ ] |
| 27 | `fSuspensionReboundDamp` | float | nonnegative | Rebound damping coefficient. | [ ] |
| 28 | `fSuspensionUpperLimit` | float | finite | Upper suspension travel limit in metres. | [ ] |
| 29 | `fSuspensionLowerLimit` | float | finite | Lower suspension travel limit in metres. | [ ] |
| 30 | `fSuspensionRaise` | float | finite | Suspension ride height offset in metres. | [ ] |
| 31 | `fSuspensionBiasFront` | float | bias | Front spring distribution fraction. | [ ] |
| 32 | `fAntiRollBarForce` | float | nonnegative | Anti-roll force multiplier; higher is not always better. | [ ] |
| 33 | `fAntiRollBarBiasFront` | float | bias | Front anti-roll distribution fraction. | [ ] |
| 34 | `fRollCentreHeightFront` | float | finite | Front roll center height in metres; not static axle weight. | [ ] |
| 35 | `fRollCentreHeightRear` | float | finite | Rear roll center height in metres. | [ ] |
| 36 | `fCollisionDamageMult` | float | nonnegative | Collision damage multiplier. | [ ] |
| 37 | `fWeaponDamageMult` | float | nonnegative | Weapon damage multiplier. | [ ] |
| 38 | `fDeformationDamageMult` | float | nonnegative | Body deformation multiplier. | [ ] |
| 39 | `fEngineDamageMult` | float | nonnegative | Engine damage multiplier. | [ ] |
| 40 | `fPetrolTankVolume` | float | nonnegative | Fuel tank capacity metadata; fuel resources may override behavior. | [ ] |
| 41 | `fOilVolume` | float | nonnegative | Oil volume metadata; physical effect needs in-game verification. | [ ] |
| 42 | `fSeatOffsetDistX` | float | finite | Seat position offset on the local x axis. | [ ] |
| 43 | `fSeatOffsetDistY` | float | finite | Seat position offset on the local y axis. | [ ] |
| 44 | `fSeatOffsetDistZ` | float | finite | Seat position offset on the local z axis. | [ ] |
| 45 | `fDownforceModifier` | float | nonnegative | Downforce modifier; effects depend on the vehicle and game build. | [ ] |
| 46 | `nMonetaryValue` | int | integer | Vehicle monetary value metadata; does not change driving physics. | [ ] |
