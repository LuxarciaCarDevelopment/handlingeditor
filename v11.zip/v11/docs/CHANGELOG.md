# Development report — 2.0.0

This is a **new resource**, not a V1 upgrade. No original V1 files or production bugs were available or audited. The earlier V1 migration requirement was superseded by the user's from-scratch instruction.

## Implemented phases

1. Shared 46-field catalog, typed native handling access, server-only configuration and Discord authorization.
2. Runtime validation/readback/rollback, original snapshots, bounded undo/redo and vehicle generation checks.
3. Offline tuning profiles, quick actions, diagnostics, explanatory analysis and paired manual controls.
4. Real native telemetry sampling, acceleration/braking/drag tests, checkpoint laps and recorded comparisons.
5. Presets, backups, vehicle profiles, history archives, safe imports/exports, reports and account persistence.
6. Optional Groq server integration, timeout/rate limits, strict proposals and approval-only application.
7. All 22 NUI panels, five themes, bilingual text, charts, empty states and transparent outer page.
8. Mocked Lua execution tests, browser integration tests, documentation and distribution build.

## Issues found and corrected during implementation

- Replaced an unverified candidate field with the known `nMonetaryValue` metadata field before finalizing the 46-field catalog.
- Corrected traction-distribution diagnostic wording/direction; all such diagnoses remain heuristics.
- Initialized first-sample path distance so ghost comparisons do not produce NaN.
- Scoped test maximum speed to the active test instead of the entire session.
- Added NUI-ready synchronization to avoid a command opening before the UI listener is ready.
- Captured vehicle generations when queueing requests and rejected stale response state.
- Allowed close/ready callbacks to bypass a pending AI request, avoiding blocked focus release.
- Added always-visible text exports for embedded-browser download restrictions.
- Added persistence entry-ID/array/run/history validation, configurable entry cap handling and previous-library recovery.
- Added minimum checkpoint spacing to avoid overlapping gates, and setup-change metadata/invalidation for measurement integrity.
- Kept fullscreen HTML/body backgrounds explicitly transparent under every theme and repeated reopen.
- Restored vehicle overrides when leaving after closing an idle editor; cancelled pending opens when the user closes or toggles the command.
- Added generation/active state to telemetry packets and sent existing recordings on NUI reopen, preventing stale state across vehicle changes or reloads.
- Validated stored data on load/recovery and hardened every nested level of Groq JSON parsing.
- Added latent library transfer and scoped history persistence to reduce large repeat uploads.

These are development fixes covered where possible by local tests, not claims about repaired historical production behavior.

## Migration / future upgrades

There is no automatic V1 migration because no V1 data format was provided. Existing vehicle handling XML can be imported through preview. For a future version, preserve the resource folder name, back up server KVP and export important records before replacing files. Keep the customer's server-only config. The persisted library format has `version: 2`; incompatible versions must be explicitly migrated instead of silently interpreted. The field catalog remains the source of truth for regenerated schema assets.

Final source-level native review verified the official gear setter cap, drive-bias snapping and unit conversions. Changes now write/roll back/restore only touched fields, preserving untouched stock transmissions above the setter cap. Native-cap regression tests cover read-only stock gear counts, export snapshots and failed-edit rollback.
