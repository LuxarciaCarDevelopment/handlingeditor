# Verification and release acceptance

Local automated verification performed on 2026-10-16 and extended on 2026-10-17. **No FiveM server, GTA session, Groq key, official escrow upload or Tebex publication was used.**

## Local checks passed

| Check | Scope |
|---|---|
| Lua parsing | Manifest, config and every shared/client/server Lua file |
| Lua execution with test doubles | All 46 typed native routes, value validation, rollback on rejected readback, stale driver, missing control, history bounds, restoration |
| Client callback/lifecycle execution | Focus release, queued-open cancellation, idle vehicle exit restoration, stale generation rejection, telemetry startup snapshot, resource cleanup and latent history upload |
| Telemetry execution with controlled samples | Threshold interpolation, braking distance, 400 m completion, airtime/gap invalidation, checkpoints, sample bounds |
| Server execution with test doubles | Unauthorized denial, authorized flags, validated storage/read/recovery, scoped history merge, corrupt KVP handling, latent download, malformed AI envelopes, AI-disabled behavior, invalid AI fields, timeout and discarded late result |
| Pure JavaScript checks | Schema count/uniqueness, profile recipes/intensity, invalid input rejection, dyno formula, ghost interpolation, translation parity |
| Headless browser | All 22 panels, 46 editors, manual NUI request, undo/redo, approval-only tuning, safe preset names, XML import/DTD rejection, AI preview, save run, 5 themes × 2 languages, 960px layout, transparent page, ESC/reopen |
| Visual inspection | Dashboard browser screenshot inspected; fixture vehicle/data are test-only |

Tests live in `tests/`; mocked data is excluded from the release ZIP. Static/simulation tests check our logic, not GTA's native implementation.

## Required real-server acceptance — all pending

- [ ] Start resource on the intended FiveM GTA V Legacy artifact/build with no script/NUI errors.
- [ ] Empty whitelist, missing Discord identifier, unauthorized player and forged permission payloads are denied.
- [ ] Two distinct authorized Discord accounts cannot read/write each other's libraries.
- [ ] Revoking access and restarting removes access; no config/secrets appear in client downloads, devtools or logs.
- [ ] `/handling`, ESC and close work repeatedly, while AI is pending, after respawn, after vehicle change and on resource restart.
- [ ] Verify all 46 parameters using the per-field checklist in PARAMETERS.md, including effects after exit/reentry or respawn where relevant.
- [ ] Confirm failures leave actual handling restored; repeat while network control is lost or the vehicle is deleted.
- [ ] Test undo/redo and original reset after multiple edits, presets and AI-approved changes.
- [ ] Compare exported XML fields with actual readings; merge into a disposable test vehicle resource and reload it.
- [ ] Verify clipboard and text export fallback in actual NUI. Confirm JSON import/export, preset rename/duplicate/delete and original-vs-current comparison.
- [ ] Validate English/Turkish text, every panel's controls, all five themes, transparency and readable charts at target resolutions.
- [ ] Run repeated 0–100, 0–200, 100–0 and drag tests on a flat course; compare independent timing/distance references with the documented sample tolerance.
- [ ] Test armed/cancelled/invalid tests, collision/airtime/gaps, altered handling mid-test, slopes, reverse driving and recording stop/resume.
- [ ] Test checkpoint order, current/previous/best lap, invalid laps, duplicate/nearby checkpoints and clearing a course.
- [ ] Save real runs, compare the same route, reject different origins, and confirm no fake data appears when no recording exists.
- [ ] Test persistence after reconnect/server restart; test size caps, KVP recovery, backup restore and malformed library rejection.
- [ ] Test AI disabled, missing key, correct key, bad model, HTTP/JSON failure, quota exhaustion, timeout, disconnect and late responses. Confirm no change without approval.
- [ ] Measure idle/open/recording resmon/profiler CPU and memory on target hardware. Verify bounded histories and samples during long sessions.
- [ ] Test other handling/fuel resources and ownership migration; document any conflicts for customers.
- [ ] Process official Asset Escrow, verify editable config and NUI visibility, test entitlements, then validate the actual Tebex download.

Only check these boxes after observing the behavior on a real server. This package is ready to begin integration and that testing, not evidence of commercial release acceptance.
