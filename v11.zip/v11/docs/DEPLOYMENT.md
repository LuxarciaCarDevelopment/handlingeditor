# Configuration and deployment

## Server-only configuration

`fxmanifest.lua` loads `config.lua` before `server/main.lua`, never as a shared/client script or NUI asset. `AllowedDiscordIDs` accepts multiple string IDs. Configuration changes require a resource restart; reopening `/handling` never does.

| Setting | Default | Meaning |
|---|---:|---|
| EnableAI | false | Optional Groq requests |
| EnableSmartTuning | true | Offline tuning controls |
| EnableTelemetry | true | Recording and live telemetry |
| EnablePerformanceTests | true | Acceleration, braking, drag and laps |
| EnablePresets | true | All library writes, including saved runs/reports |
| TelemetrySampleInterval | 100 | Milliseconds, clamped to 50–1000 |
| HistoryLimit | 100 | Vehicle history length, client clamped to 1–500; configure within that range |
| MaxSavedEntries | 100 | Total entries across presets/backups/reports/runs/feedback |
| MaxStorageBytes | 4000000 | Maximum JSON library bytes per account |
| AIModel | llama-3.3-70b-versatile | Customer-selected Groq model; verify availability on your account |
| AITimeout | 20000 | Application timeout in milliseconds, clamped to 1000–20000 |
| AICooldown | 15000 | Minimum interval between AI requests per connected player |
| RestoreOnStop | true | Best-effort restore on resource shutdown |

Presets disabled means library writes are disabled; existing data can still be read. Smart tuning is a UI convenience restriction, not a separate permission to edit: authorized users can always manually apply valid values. Sampling is opt-in, never started simply by opening the editor.

## Optional Groq AI

1. Create your own Groq API key.
2. Set `EnableAI = true` and choose an available JSON-mode-compatible model.
3. In `server.cfg`, use a **non-replicated** convar:

```text
set luxarcia_groq_api_key "YOUR_API_KEY"
```

Do not use `setr`, embed keys in NUI/client files, or share real keys with customers. Restart the resource after changing config. The server alone calls `https://api.groq.com/openai/v1/chat/completions`. JSON responses must contain exactly `explanation` and `changes`. Each changed field is checked against the same handling schema. AI text is escaped when rendered. No generated code is evaluated.

Chat, tuning, explanation, optimization, problem detection and learning assistance use different request intents. Hybrid mode generates a deterministic proposal first and asks for refinement. The complete merged proposal is shown before applying. Optional history context contains recent approved setups and test summaries, not model training. Prompts/current values are sent to Groq when users request AI; the context checkbox adds history and feedback. Review your customer privacy notice accordingly.

HTTP failures, quota errors, malformed JSON and timeouts yield localized errors. Late HTTP responses are discarded, though the underlying HTTP request cannot be cancelled by this application timer. AI availability does not affect PRO mode. ESC remains available during an AI request.

## Official Asset Escrow / Tebex

The manifest excludes only `config.lua` with `escrow_ignore`. Upload the generated resource through the official Cfx.re asset workflow, obtain the official escrow output, and distribute that output through your Tebex package. Test an entitled and an unentitled server. This repository does not create or alter `.fxap` files and does not implement entitlement bypasses.

**NUI assets are not supported by Asset Escrow protection**, according to the official documentation consulted on 2026-10-16. HTML, CSS, JavaScript and schema metadata should be treated as visible customer/client assets. Lua protection and entitlement enforcement are supplied by the official upload/distribution process, not by this source ZIP. Do not advertise the NUI as encrypted or this unprocessed ZIP as already escrowed.

Technical listing information: standalone GTA V Legacy resource; Lua client/server; plain NUI; Discord identifier required; no framework/database; optional external Groq service with customer key; configurable sampling; 22 panels; road-vehicle testing required. Add your own support contact, terms, licensing, price and marketing screenshots after in-game acceptance. No fabricated FPS/resmon or performance claims are supplied.

## Persistence and backups

Server resource KVP storage is keyed by the authorized Discord ID. Before replacing a library, the previous serialized library is stored in a separate recovery key. This supports one previous-library recovery; it is not a transactional database or off-server backup. Export important presets/reports/runs and include the server's KVP data in operational backups. Resource name changes or KVP deletion may make prior records unavailable. Keep the same resource folder name between upgrades.

Stored content is validated again when loaded or recovered. A corrupt primary is reported as invalid storage; recovery remains available, and a valid recovery copy is not overwritten by the corrupt primary. History uses a scoped server merge so editing a field does not upload every saved run. Larger library transfers use latent events at 500,000 bytes/second, following the [FiveM event transfer guidance](https://docs.fivem.net/docs/scripting-manual/working-with-events/triggering-events/).

## XML integration

Export produces the 46 field elements as a fragment. Find the correct existing `Item type="CHandlingData"` in the vehicle's `handling.meta`; replace matching fields while retaining `handlingName`, flags and `SubHandlingData`. Imported whole XML files must contain one unambiguous set of fields: duplicate known fields are rejected. DTD/entity declarations are rejected. Unknown XML fields are ignored, never executed or exported as supported fields. JSON unknown fields are rejected. Always keep a vehicle-resource backup and verify the changed vehicle after restarting that resource.

References: [Asset Escrow](https://docs.fivem.net/docs/server-manual/asset-escrow/), [Groq API](https://console.groq.com/docs/api-reference), [Groq structured output](https://console.groq.com/docs/structured-outputs).
