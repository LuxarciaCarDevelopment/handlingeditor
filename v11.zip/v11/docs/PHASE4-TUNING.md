# Phase 4 Tuning Engine

## Determinism and Baseline

All profile and Quick Tune proposals are deterministic. The UI always passes the captured session baseline to `Core.tune`; the slider intensity is a normalized value from `0.10` through `1.00`. Multiplicative recipe values are interpolated from baseline as:

`baseline × (1 + (recipeFactor − 1) × intensity × classFactor)`

Target-based fields use linear interpolation from baseline to the recipe target. The vehicle class factor is `0.82` for heavy classes, `0.82` for motorcycles, `0.90` for off-road, `0.94` for coupes/muscle/classic sport, `1.08` for sport/super/open-wheel, and `1.00` otherwise. Drift traction changes are additionally scaled by captured drivetrain layout: full for rear-wheel drive, `0.68` for all-wheel drive, and `0.45` for front-wheel drive. No profile changes `fDriveBiasFront`, so the engine does not convert the vehicle's drivetrain.

## Stability Score

The 0–100 stability score is a static heuristic, not a GTA V native metric or a safety certification. Start at 100, subtract these fixed penalties, then clamp to `[0, 100]`:

- 25: suspension upper travel is not above lower travel.
- 20: sliding traction exceeds peak traction.
- 10: front brake bias is outside `0.35–0.80`.
- 10: steering lock exceeds 45 while the speed reference exceeds 180.
- 5: anti-roll force is below 0.2.
- 15: center-of-mass Z offset exceeds 0.2.
- 5: traction-loss multiplier exceeds 2.
- 5: compression damping exceeds 1.5 times spring force.

Troubleshooter, Health Check, and Conflict Detector inspect configured values only. They do not infer actual driver behavior, tyre state, road surface, or in-game stability.

## Mutation Safety

Every approved tuning preview is submitted as a batch through the existing `applyHandling` NUI callback. The server-authorized session, captured vehicle identity, network-control check, handling whitelist, numeric/range validation, native readback, rollback, and history behavior remain owned by the existing handling engine.