# Security, performance and limitations

## Implemented boundaries

- Every privileged server request resolves the actual server-side player identifiers. Client booleans and NUI state never authorize access. Missing or non-whitelisted Discord IDs are denied.
- The configuration and Groq convar are server-only. Replies expose feature flags, not IDs or secrets. No request bodies, authorization headers or API credentials are logged by this resource.
- Requests are rate-limited to 20 per player per second. AI additionally uses a per-player cooldown and one outstanding request. Disconnect clears transient state; late AI callbacks check a unique request token and the authorized identity.
- Field names are allowlisted, floats must be finite float32-representable numbers, integer fields must be integers, ordinary biases are 0–1, drive bias is 0/0.1–0.9/1, submersion percentage is positive and at most 100, and vectors must contain exactly x/y/z. Positive/nonnegative field policies are listed in PARAMETERS.md. These are editor policies, not a claim that GTA documents universal safe ranges.
- Lua requires local driver ownership and network control to edit. Vehicle generations prevent an asynchronous request for one vehicle from applying to a later one. Client Lua/server traffic serializes normal operations; close bypasses pending AI traffic to release focus promptly.
- AI is untrusted advisory output. JSON structure and every changed field are checked server-side, then the user approves the diff. AI cannot execute code or apply settings directly.
- XML rejects DTD/entity declarations, malformed documents, ambiguous duplicate known fields and nonnumeric values. No external entity or script execution is used. UI text is escaped, including names, prompts, AI prose and imported values. JSON never merges unknown field names into native calls.
- Server libraries have entry and byte caps, array-shape validation, unique safe IDs, validated handling snapshots and finite ordered run samples. Accounts have distinct KVP keys. A previous-library copy is retained. Server-side persistence is not proof that client telemetry is authentic.

## Threat-model boundary

FiveM clients can be modified. This resource cannot prevent a cheating client from invoking GTA natives through other code or fabricating its own telemetry. Authorization protects this resource's server functions and normal UI workflow; it is not an anti-cheat. Tuning overrides are local to the editing client's vehicle and are not an authoritative synchronization solution for every remote viewer or future owner. Test network ownership migration and your vehicle framework. Competing handling/fuel resources may overwrite values.

KVP backup/write is not a multi-key transaction. A server crash can interrupt a save; exported off-server copies remain necessary. Browser settings (theme/language) use localStorage, while vehicle data uses server KVP. Disconnect or abrupt client crash may bypass best-effort native cleanup. Telemetry has a bounded in-memory buffer; only explicitly saved records survive restarts. Current unsaved edits do not auto-apply after restart.

## Performance design

- Two sleeping client loops; no zero-wait polling. Idle intervals are 500 ms. Recording interval is configurable and bounded to 50–1000 ms.
- One shared native sampler, maximum 1200 points. Browser charts use only the latest 120 points for live channels. Recorded dyno data is bounded by the same buffer.
- Hidden UI keeps bounded data without drawing charts. Live visible telemetry updates only the current panel. No image/video backgrounds, external fonts, CDN requests or animation loops.
- History defaults to 100 snapshots; lap results to 100; library defaults to 100 entries/4 MB. The client and server reject over-cap saves, preserving the prior library.
- Graph rendering uses canvas, and event delegation avoids duplicate per-row listeners on rerender. Zero production dependencies are downloaded at startup.
- Full library uploads/downloads use FiveM latent events at 500,000 bytes/second. History updates send only the archive, avoiding retransmission of saved traces after every edit. Validate transfer times under real network conditions before raising the default 4 MB cap.

**No in-game CPU time, FPS, network throughput or memory benchmark has been measured.** Use FiveM profiler/resmon on your target server at idle, open editor, recording and AI load; establish commercial performance claims from those measurements. A full 1200-sample run can consume a substantial part of the library cap. Increase storage only after measuring your expected number of users and library sizes.

## Known limitations requiring deployment decisions

1. Road vehicles are the intended tuning target. Boats, aircraft, bicycles, trains and special vehicles need separate suitability testing; class detection does not imply all recipes fit every class.
2. Some natives accept/read values without changing immediate physical behavior. Gear writes are capped at 7 by the native; captured higher stock counts are preserved as read-only data. Drive distribution, downforce and metadata need vehicle/build-specific testing; metadata such as monetary value is not a driving-physics control.
3. This resource supports the common `CHandlingData` layer only, not flying/boat subhandling classes or runtime flags requiring global changes.
4. Preset load never writes vehicle resource files. XML exports are fragments, not complete replacement handling files.
5. File downloads may be blocked by embedded Chromium; copyable text is always shown as a fallback. Test the actual NUI clipboard behavior before release.
6. Application AI timeout does not cancel the upstream HTTP request; late results are ignored. Groq availability, model support and quotas depend on the customer account.
7. No measured torque/horsepower, per-gear ratio tuning, real-time wheel suspension compression or static axle-weight instrumentation is claimed.
8. The UI concept's photographic vehicles and promotional banners are not used as current-vehicle images. The real native model/class panel is displayed instead.
9. This source package is not yet officially escrowed or certified by Tebex/Cfx.re. NUI source remains visible under current escrow support.

## Development dependency audit

On 2026-10-17, `npm audit --omit=dev` reported zero production vulnerabilities. The development-only Fengari test runner depends on `sprintf-js`, for which npm reports a moderate denial-of-service advisory ([GHSA-hp3w-g68c-fv3c](https://github.com/advisories/GHSA-hp3w-g68c-fv3c)) and no available fix. The Lua harness executes trusted project fixtures only; do not use it to run untrusted Lua or attacker-supplied format strings. Neither dependency nor any test fixture is included in the resource ZIP or used by FiveM.
