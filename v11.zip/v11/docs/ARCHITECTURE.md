# Architecture and formulas

## Modules

| Module | Responsibility |
|---|---|
| tools/generate_schema.py | Single field catalog with type, validation rule, group and bilingual explanation |
| shared/schema.lua | Generated allowlist and Lua numeric/vector validation |
| config.lua | Server-only customer settings |
| server/main.lua | Discord authorization, rate limits, library KVP, Groq requests and response validation |
| client/handling.lua | Vehicle capture, typed native reads/writes, post-write verification, rollback and history |
| client/telemetry.lua | Shared sampler, timed tests, checkpoints and bounded records |
| client/main.lua | `/handling`, NUI callbacks, server request/reply, focus and lifecycle |
| web/core.js | Pure validation, tuning recipes, diagnostics, import/export, dyno and ghost calculations |
| web/app.js | Shared UI state, all panels, charts, dialogs and serialized actions |
| web/locales.js | English/Turkish UI text and vehicle class labels |
| web/style.css | Transparent outer page, responsive layout, five theme palettes |

## Handling flow

Command → server authorization → driver/vehicle validation → capture original native state → send NUI state. Manual edits commit through NUI → authorization → server field validation → driver/generation/ownership check → typed native write → all-field readback → transaction comparison → history/state response.

Application rollback is attempted when any requested value fails readback or a native throws. It is best effort: entity deletion/ownership loss or another resource can prevent restoration. Only touched values are written on success; unrelated native values are re-read. Original values are separately retained even after history trimming. Writes and restoration touch only changed fields, preserving unrelated stock values. The handling setter caps gear changes at 7: captured larger stock transmissions remain exportable/readable, but their gear count cannot be changed because this setter cannot restore the original. Undo/redo restores snapshots and truncates the redo branch on a new edit.

Values use `CHandlingData` with `Get/SetVehicleHandlingFloat`, `Get/SetVehicleHandlingInt` or `Get/SetVehicleHandlingVector`. The `fCamberStiffnesss` spelling is intentional. Sliders supply a view window based on the current value; numeric inputs accept any value passing the semantic/type validation policy, rather than silently clamping to slider ends. Readback tolerance is max(0.0001, abs(requested) × 0.00001).

## Telemetry and tests

Sampling uses real entity speed, position, velocity and rotation, native steering, current gear and normalized RPM. `speed = GetEntitySpeed × 3.6`; acceleration is the finite speed derivative in m/s². Longitudinal G is the velocity-vector derivative projected onto vehicle-forward divided by 9.80665. Lateral G uses the horizontal right vector. Gravity is not removed: these are kinematic estimates from sampled native observations, not an accelerometer model. Pitch/roll/yaw are native Euler angles in degrees.

Acceleration/drag timing starts at the interpolated departure from the ≤0.5 km/h stationary band. A native arm-time speed/position baseline prevents missing an immediate launch. Finish time is interpolated between samples crossing 100/200 km/h. The 100–0 test starts at a downward crossing of 100 and finishes at 0.5 km/h, interpolating sampled path distance. Thus its label uses the conventional 100–0 name with an explicitly documented stop tolerance. The 400 m test measures travelled 3D path length, not certified straight-line track distance. Max speed and peak acceleration/deceleration are maxima of valid sampled values; peaks depend on sampling interval.

Collision, airtime, an excessive position jump or a sampling gap above one second invalidates an active test. Pausing recording or changing handling invalidates an armed/running test or active lap; run archives include setup changes. These checks cannot detect every cheat, slope, reset or off-course excursion. Test at a known flat course, with the same vehicle/upgrades/weather and repeat runs. This is a tuning tool, not an authoritative competitive timing system.

Lap timing requires at least two ordered checkpoints, separated by 15 m; entering a 7 m sphere counts. Segment/sphere entry is interpolated between observations, processing crossed checkpoints in order. If the command begins inside checkpoint 1, the native command-time baseline establishes the start. The course is snapshotted at lap start; editing it invalidates that session until restarting laps. Invalid laps stay in the record and are excluded from best lap. Off-route shortcuts between checkpoints cannot be detected. Checkpoints are session-local; saved runs preserve their course coordinates.

Records are capped at 1200 samples and 100 lap results. At 100 ms the live trace spans approximately two minutes. Longer sessions continue timing, but old trace samples fall out of the buffer. Export/save before losing a needed trace. Max values and completed tests remain until reset. Changing vehicles resets session measurements and course data.

## Estimates and heuristics

- Offline profiles multiply selected current fields; intensity linearly blends 10–100% of each recipe. For example Race uses +10% drive force, +12% brake force and +8% peak traction at full intensity. Every actual changed number appears in a diff. Repeated applications compound; restore or compare against original when needed. Recipes are tuning starting points, not universal optimal physics.
- Health/stability score starts at 100 and subtracts documented rule penalties in `Core.diagnose`. Checks include traction ordering (20), reversed suspension limits (25), brake balance outside .35–.8 (10), drive force below .15 (5), low brake force (10), high center of mass (15), traction bias outside .45–.55 (10), low anti-roll (5), low sliding grip (10), harsh damping (5), high steering/high gearing reference (10). Thresholds are policy heuristics, not native validation limits or empirical measurements.
- Optimizer proposes specific corrections for those rules. It cannot guarantee safe or faster handling. Notes and class detection are exposed so the user can judge applicability.
- Body slip angle uses `atan2(lateral velocity, abs(forward velocity))`. Above 15 km/h, >12° flags possible oversteer; steering >10° with <0.1 lateral G flags possible understeer. These are ambiguous indicators, not measured axle slip. Reverse driving and slopes are particularly unsuitable.
- Virtual dyno estimates **inertial power** `mass × acceleration × speed / 1000` kW for positive acceleration above 5 km/h. It excludes resistance, grade and drivetrain loss. The curve is indexed by sample time; native normalized RPM is not actual engine RPM, so no fabricated RPM or torque curve is shown.
- Ghost comparison aligns recorded traces by relative time and interpolates reference speed/distance. Starts over 15 m apart are rejected. Same origin does not guarantee the same course; users must choose comparable runs. No entity or simulated ghost car is spawned.
- Suspension visualization is a parameter schematic, not wheel-travel telemetry. Weight analysis exposes center-of-mass offset, total mass and suspension bias; it does not fabricate axle loads. Gear analysis exposes count, current gear, normalized RPM and speed reference; no per-gear native ratio support is claimed.
- Local learning sums positive/negative profile votes for the current model and lists the best-rated profile. It does not retrain an AI model or infer physical improvements from subjective votes.

## UI integration map

Panels 1–8 cover dashboard/manual editing/tuning and suspension/brake/gearing tools; 9–15 share the telemetry/test engine; 16 compares saved or original vehicles; 17 manages presets/backups; 18 handles live and archived history; 19 handles optional AI; 20 stores reports and feedback; 21 filters the vehicle/profile library; 22 explains every field. Header controls provide settings (theme/language), undo/redo and close. Manual/preset panels expose import/export. Diagnostics live on dashboard, Smart Tuning and slip analysis. Test-drive start/reposition and benchmarking are in the test/comparison panels.

Native references: [float setter](https://github.com/citizenfx/fivem/blob/master/ext/native-decls/SetVehicleHandlingFloat.md), [integer setter](https://github.com/citizenfx/fivem/blob/master/ext/native-decls/SetVehicleHandlingInt.md), [vector setter](https://github.com/citizenfx/fivem/blob/master/ext/native-decls/SetVehicleHandlingVector.md), [steering angle](https://github.com/citizenfx/fivem/blob/master/ext/native-decls/GetVehicleSteeringAngle.md), [normalized RPM](https://github.com/citizenfx/fivem/blob/master/ext/native-decls/GetVehicleCurrentRpm.md).

The [official handling loader](https://github.com/citizenfx/fivem/blob/master/code/components/handling-loader-five/src/HandlingLoader.cpp) supplies field-unit conversions, caps gear writes at 7 and snaps drive-bias values below 0.1 or above 0.9 to rear/front drive. Manual changes accept exactly representable drive layouts (0, 0.1–0.9, 1). Smart proposals snap into that representable set before showing the approval diff. Zero steering lock and submersion percentage are rejected because the setter derives reciprocal values. XML uses the native API field units; no extra conversion is applied in the editor.
