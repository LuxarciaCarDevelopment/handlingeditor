# LUXARCIA Handling Editor V2.0

Ultimate PRO + Optional AI — a standalone FiveM **GTA V Legacy** resource built from scratch. No framework, database, CDN, Node runtime, or AI service is required for PRO mode.

**Integration candidate:** source and automated checks are complete, but this resource has not been run on a real FiveM server. Complete [the acceptance checklist](docs/VERIFICATION.md) on your target server/build before selling or deploying publicly. Native readback tests do not certify physical behavior.

## Install

1. Extract `dist/luxarcia_handling_v2.zip` into your server's resources folder. Keep the extracted resource name `luxarcia_handling_v2` stable for persistence.
2. Edit `config.lua`. Put authorized Discord snowflake IDs in `AllowedDiscordIDs` **as strings**, without the `discord:` prefix. The default empty list denies everyone.
3. Add `ensure luxarcia_handling_v2` to `server.cfg` and start/restart the resource.
4. Ensure FiveM supplies the player's Discord identifier. Missing identifiers are denied; there is no client-side permission fallback.
5. Enter the driver's seat of a road vehicle and run `/handling`. ESC or × releases NUI focus. Close the editor to drive while recording.

```lua
Config.AllowedDiscordIDs = {
    '123456789012345678',
    '234567890123456789'
}
```

The editor captures the current effective handling, which can include modifications from other resources. Manual controls apply on input commit. Automatic tuning, imports, saved setups, backups and AI recommendations require a reviewed diff and approval. Successful readback is followed by a reminder to road-test behavior.

Closing the editor preserves the current vehicle's overrides. Leaving/changing the vehicle attempts to restore the captured values. Resource shutdown also attempts restoration by default; network ownership loss may prevent it. Export approved settings and integrate them into the vehicle resource manually for lasting changes. This editor never rewrites `handling.meta`.

## Türkçe hızlı kurulum

1. ZIP içindeki `luxarcia_handling_v2` klasörünü sunucunun resources klasörüne çıkarın.
2. `config.lua` içindeki `AllowedDiscordIDs` listesine Discord kimliklerini tırnak içinde ekleyin. Boş liste herkesi reddeder.
3. `server.cfg` dosyasına `ensure luxarcia_handling_v2` ekleyin.
4. Araç sürücüsüyken `/handling` yazın. EN/TR ve beş tema üst menüdedir. ESC veya × odağı bırakır.
5. Otomatik önerileri önizleyip onaylayın. Testi hazırladıktan sonra editörü kapatıp sürün; sonucu görmek için tekrar açın.
6. XML parçalarını doğru `handling.meta` öğesine elle birleştirin. Oyun içi doğrulamayı tamamlamadan ticari yayına çıkmayın.

## Included

- 46 typed `CHandlingData` fields, scalar/vector editors, sliders, search, explanations, reset, readback checks and undo/redo.
- 22 panels, five themes (Emerald, Neon, Midnight, Sunset, Arctic), Turkish and English UI.
- Race, Drift, Realistic, Sport and Comfort rule-based tuning; nine quick actions; optimizer, diagnostics, conflict warnings and heuristic stability score.
- Advanced category editors, suspension schematic, brake balance, gearing observations and center-of-mass analysis.
- Native speed/velocity/rotation sampling; 0–100, 0–200, 100–0 and 400 m path tests; G-force, lap checkpoints, recorded run comparisons and estimated inertial power.
- Account-scoped server persistence for presets, backups, history archives, runs, reports and feedback; previous-library recovery.
- XML/JSON preview/import/export, per-vehicle preset library and comparisons. Exports always expose copyable text because embedded-browser file downloads may be blocked.
- Optional authorized, rate-limited server-side Groq calls with timeout and validated proposals. Disabled by default.

## Documentation

- [Configuration, AI and Asset Escrow](docs/DEPLOYMENT.md)
- [Architecture, formulas and data lifecycle](docs/ARCHITECTURE.md)
- [46-field audit and native types](docs/PARAMETERS.md)
- [Verification checklist and local results](docs/VERIFICATION.md)
- [Security, performance and known limitations](docs/SECURITY-PERFORMANCE.md)
- [Development fixes and migration notes](docs/CHANGELOG.md)

## Developer checks

Node 20+ and Python 3 are development-only tools. Runtime files are plain Lua and NUI assets.

```text
npm ci
npm test
npm run test:browser
python tools/generate_schema.py
python tools/build.py
```

Browser tests use a headless installed Chrome on Windows. Set `CHROME_PATH` to another compatible Chromium executable if needed. Browser fixtures and mocked natives are in `tests/` only and are excluded from the distribution ZIP. They must not be mistaken for in-game measurements.
