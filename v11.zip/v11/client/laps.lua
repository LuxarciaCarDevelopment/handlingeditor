-- Ordered checkpoint lap timing over real recorded positions.
local P=Performance
local function distance(a,b) return math.sqrt((a.x-b.x)^2+(a.y-b.y)^2+(a.z-b.z)^2) end
function P.lapCommand(command)
    if command=='checkpoint' then
        if P.lap then return {ok=false,error='busy'} end
        if #P.checkpoints>=64 then return {ok=false,error='limit'} end
        local p=GetEntityCoords(Handling.vehicle)
        local point={x=p.x,y=p.y,z=p.z,radius=7}
        for _,gate in ipairs(P.checkpoints) do if distance(gate,point)<15 then return {ok=false,error='checkpointSpacing'} end end
        P.checkpoints[#P.checkpoints+1]=point
    elseif command=='clear' then P.checkpoints={};P.laps={};P.lap=nil
    elseif command=='start' then
        if #P.checkpoints<2 then return {ok=false,error='checkpointsRequired'} end
        local started=P.start();if not started.ok then return started end
        P.lap={next=1,inside=false,invalid=false}
    elseif command=='stop' then P.lap=nil
    elseif command=='invalidate' then if P.lap then P.lap.invalid=true end
    else return {ok=false,error='invalidValues'} end
    return {ok=true,checkpoints=P.checkpoints,laps=P.laps}
end
function P.lapSample(s,prev)
    local lap=P.lap;if not lap then return end
    if s.invalid then lap.invalid=true end
    local gate=P.checkpoints[lap.next];if not gate then P.lap=nil;return end
    local inside=distance(s,gate)<=gate.radius
    -- Segment/sphere entry catches gates crossed between samples.
    local fraction=1
    if prev and not s.invalid and not prev.invalid then
        local dx,dy,dz=s.x-prev.x,s.y-prev.y,s.z-prev.z
        local ox,oy,oz=prev.x-gate.x,prev.y-gate.y,prev.z-gate.z
        local a=dx*dx+dy*dy+dz*dz;local b=2*(dx*ox+dy*oy+dz*oz)
        local c=ox*ox+oy*oy+oz*oz-gate.radius^2
        local discriminant=b*b-4*a*c
        if a>0 and discriminant>=0 then
            local root=(-b-math.sqrt(discriminant))/(2*a)
            if root>=0 and root<=1 then inside=true;fraction=root end
        end
    end
    if inside and not lap.inside and not s.invalid then
        local time=prev and prev.time+(s.time-prev.time)*fraction or s.time
        if lap.next==1 then
            if lap.started then
                P.laps[#P.laps+1]={seconds=(time-lap.started)/1000,invalid=lap.invalid}
                if #P.laps>100 then table.remove(P.laps,1) end
            end
            lap.started=time;lap.invalid=false
        end
        lap.next=lap.next%#P.checkpoints+1;lap.inside=false
    else lap.inside=inside end
end
