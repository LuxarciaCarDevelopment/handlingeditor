Telemetry = Telemetry or {}
local telemetryData

local function captureTelemetry()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) then
        telemetryData = nil
        return nil
    end

    local modelHash = GetEntityModel(vehicle)
    telemetryData = {
        speed = GetEntitySpeed(vehicle) * 3.6,
        normalizedRpm = GetVehicleCurrentRpm(vehicle),
        gear = GetVehicleCurrentGear and GetVehicleCurrentGear(vehicle) or GetCurrentPedVehicleGear(ped),
        engineHealth = GetVehicleEngineHealth and GetVehicleEngineHealth(vehicle) or nil,
        modelHash = modelHash,
        modelName = GetDisplayNameFromVehicleModel(modelHash),
        class = GetVehicleClass(vehicle),
    }
    return telemetryData
end

function Telemetry.snapshot()
    local snapshot = captureTelemetry()
    if not snapshot then
        return nil
    end

    local copy = {}
    for key, value in pairs(snapshot) do
        copy[key] = value
    end
    return copy
end

function StartTelemetry()
    return Telemetry.snapshot()
end

function StopTelemetry()
    telemetryData = nil
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(250)
        local snapshot = captureTelemetry()
        if snapshot and IsNuiFocused and IsNuiFocused() then
            SendNUIMessage({ type = 'telemetry', data = snapshot })
        end
    end
end)

RegisterNUICallback('getTelemetry', function(_, cb)
    if cb then
        cb(Telemetry.snapshot() or {})
    end
end)