local HANDLING_CLASS = 'CHandlingData'
local IsEntityAVehicleNative = IsEntityAVehicle or function(vehicle)
    return type(vehicle) == 'number' and vehicle ~= 0
end

local function deepCopy(value)
    if type(value) ~= 'table' then
        return value
    end

    local out = {}
    for key, child in pairs(value) do
        out[key] = deepCopy(child)
    end
    return out
end

local function valueMatches(left, right)
    if type(left) ~= type(right) then
        return false
    end

    if type(left) == 'number' then
        return math.abs(left - right) <= 0.00001
    end

    if type(left) == 'table' then
        for _, axis in ipairs({ 'x', 'y', 'z' }) do
            if not valueMatches(left[axis], right[axis]) then
                return false
            end
        end
        return true
    end

    return left == right
end

local function getCurrentVehicle()
    local ped = PlayerPedId()
    if not ped then
        return 0
    end

    local vehicle = GetVehiclePedIsIn(ped, false)
    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) or not IsEntityAVehicleNative(vehicle) then
        return 0
    end

    return vehicle
end

local function readFieldValue(vehicle, fieldName, fieldSpec)
    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) or not IsEntityAVehicleNative(vehicle) then
        return nil, 'Invalid vehicle'
    end

    if not fieldName or type(fieldName) ~= 'string' then
        return nil, 'Invalid field name'
    end

    if not fieldSpec then
        return nil, 'Unsupported field'
    end

    if fieldSpec.type == 'float' then
        return GetVehicleHandlingFloat(vehicle, HANDLING_CLASS, fieldName)
    elseif fieldSpec.type == 'int' then
        return GetVehicleHandlingInt(vehicle, HANDLING_CLASS, fieldName)
    elseif fieldSpec.type == 'vector' then
        local vectorValue = GetVehicleHandlingVector(vehicle, HANDLING_CLASS, fieldName)
        local vectorType = type(vectorValue)
        if not vectorValue or (vectorType ~= 'vector3' and vectorType ~= 'table')
            or type(vectorValue.x) ~= 'number' or type(vectorValue.y) ~= 'number' or type(vectorValue.z) ~= 'number' then
            return nil, 'Unsupported vector field'
        end

        return { x = vectorValue.x, y = vectorValue.y, z = vectorValue.z }
    end

    return nil, 'Unsupported handling type'
end

local function canMutateVehicle(vehicle)
    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) or not IsEntityAVehicleNative(vehicle) then
        return false, 'Invalid vehicle'
    end

    local currentVehicle = getCurrentVehicle()
    if not currentVehicle or currentVehicle ~= vehicle or not Handling or Handling.vehicle ~= vehicle then
        return false, 'staleVehicle'
    end

    if (Handling.model and GetEntityModel(vehicle) ~= Handling.model)
        or (GetPedInVehicleSeat and GetPedInVehicleSeat(vehicle, -1) ~= PlayerPedId()) then
        return false, 'staleVehicle'
    end

    if type(NetworkHasControlOfEntity) ~= 'function' or not NetworkHasControlOfEntity(vehicle) then
        return false, 'noControl'
    end

    return true
end

local function writeFieldValue(vehicle, fieldName, fieldSpec, value)
    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) or not IsEntityAVehicleNative(vehicle) then
        return false, 'Invalid vehicle'
    end

    if not fieldName or type(fieldName) ~= 'string' then
        return false, 'Invalid field name'
    end

    if not fieldSpec then
        return false, 'Unsupported field'
    end

    if fieldSpec.type == 'float' then
        if type(value) ~= 'number' or value ~= value or value == math.huge or value == -math.huge then
            return false, 'Invalid numeric value'
        end
        local canWrite, writeError = canMutateVehicle(vehicle)
        if not canWrite then return false, writeError end
        SetVehicleHandlingFloat(vehicle, HANDLING_CLASS, fieldName, value)
        return true
    elseif fieldSpec.type == 'int' then
        if type(value) ~= 'number' or value % 1 ~= 0 or value ~= value then
            return false, 'Invalid integer value'
        end
        local canWrite, writeError = canMutateVehicle(vehicle)
        if not canWrite then return false, writeError end
        SetVehicleHandlingInt(vehicle, HANDLING_CLASS, fieldName, value)
        return true
    elseif fieldSpec.type == 'vector' then
        if type(value) ~= 'table' or type(value.x) ~= 'number' or type(value.y) ~= 'number' or type(value.z) ~= 'number' then
            return false, 'Invalid vector value'
        end
        local canWrite, writeError = canMutateVehicle(vehicle)
        if not canWrite then return false, writeError end
        SetVehicleHandlingVector(vehicle, HANDLING_CLASS, fieldName, vector3(value.x, value.y, value.z))
        return true
    end

    return false, 'Unsupported handling type'
end

Handling = Handling or {}
Handling.values = Handling.values or {}
Handling.original = Handling.original or {}
Handling.undoHistory = Handling.undoHistory or {}
Handling.redoHistory = Handling.redoHistory or {}
Handling.history = Handling.history or {}
Handling.cursor = Handling.cursor or 0
Handling.sessionBackup = Handling.sessionBackup or {}
Handling.limit = Handling.limit or 50
Handling.generation = Handling.generation or 1
Handling.vehicle = Handling.vehicle or 0

function Handling.validateMutationTarget(vehicle)
    return canMutateVehicle(vehicle or Handling.vehicle)
end

local function setHistoryBounds()
    while #Handling.undoHistory > Handling.limit do
        table.remove(Handling.undoHistory, 1)
    end

    while #Handling.redoHistory > Handling.limit do
        table.remove(Handling.redoHistory, 1)
    end
end

local function recordHistory(label)
    while #Handling.history > Handling.cursor do
        table.remove(Handling.history)
    end

    Handling.history[#Handling.history + 1] = {
        label = label,
        values = deepCopy(Handling.values),
        time = GetGameTimer and GetGameTimer() or 0,
    }

    while #Handling.history > Handling.limit do
        table.remove(Handling.history, 1)
    end
    Handling.cursor = #Handling.history
end

local rollbackChanges

local function restoreStateSnapshot(snapshot)
    local vehicle = Handling.vehicle or getCurrentVehicle()
    if not vehicle or vehicle == 0 then
        return false, 'Invalid vehicle'
    end

    if type(snapshot) ~= 'table' then
        return false, 'invalidState'
    end

    local validated, err = ValidateHandling(snapshot, true)
    if not validated then
        return false, err
    end

    local canWrite, writeError = canMutateVehicle(vehicle)
    if not canWrite then
        return false, writeError
    end

    local changed = {}
    for fieldName, fieldValue in pairs(validated) do
        local fieldSpec = HandlingFields and HandlingFields[fieldName]
        if fieldSpec and not valueMatches(Handling.values[fieldName], fieldValue) then
            changed[fieldName] = true
            local okWrite, errWrite = writeFieldValue(vehicle, fieldName, fieldSpec, fieldValue)
            if not okWrite then
                rollbackChanges(vehicle, changed, Handling.values)
                return false, errWrite
            end
            if not valueMatches(readFieldValue(vehicle,fieldName,fieldSpec),fieldValue) then
                rollbackChanges(vehicle,changed,Handling.values)
                return false,'runtimeRejected:' .. fieldName
            end
        end
    end

    Handling.values = deepCopy(validated)
    return true
end

rollbackChanges = function(vehicle, changes, before)
    for fieldName in pairs(changes) do
        local fieldSpec = HandlingFields and HandlingFields[fieldName]
        local originalValue = before[fieldName]
        if fieldSpec and originalValue ~= nil then
            local currentValue = readFieldValue(vehicle, fieldName, fieldSpec)
            if currentValue ~= nil and not valueMatches(currentValue, originalValue) then
                writeFieldValue(vehicle, fieldName, fieldSpec, originalValue)
            end
        end
    end
end

function Handling.capture(vehicleId, preserveSession)
    local vehicle = vehicleId or getCurrentVehicle()
    if not vehicle or vehicle == 0 then
        return false, 'Invalid vehicle'
    end
    if preserveSession and Handling.vehicle == vehicle and Handling.model == GetEntityModel(vehicle) then return true end

    local snapshot = {}
    local fields = HandlingSchema or {}
    for _, spec in ipairs(fields) do
        local value = readFieldValue(vehicle, spec.field, spec)
        if value ~= nil then
            snapshot[spec.field] = deepCopy(value)
        else
            return false, 'unsupportedField:' .. spec.field
        end
    end

    Handling.vehicle = vehicle
    Handling.model = GetEntityModel(vehicle)
    Handling.generation = Handling.generation + 1
    Handling.original = deepCopy(snapshot)
    Handling.values = deepCopy(snapshot)
    Handling.undoHistory = {}
    Handling.redoHistory = {}
    Handling.history = {}
    Handling.cursor = 0
    Handling.sessionBackup = deepCopy(snapshot)
    return true
end

function Handling.matches(currentValue, incomingValue)
    return valueMatches(currentValue, incomingValue)
end

function Handling.apply(changes, label)
    if type(changes) ~= 'table' then
        return { ok = false, error = 'invalidValues' }
    end

    local currentVehicle = getCurrentVehicle()
    if not currentVehicle or currentVehicle == 0 then
        return { ok = false, error = 'Invalid vehicle' }
    end
    if Handling.vehicle ~= 0 and currentVehicle ~= Handling.vehicle then
        return { ok = false, error = 'staleVehicle' }
    end
    if type(NetworkHasControlOfEntity) ~= 'function' or not NetworkHasControlOfEntity(currentVehicle) then
        return { ok = false, error = 'noControl' }
    end

    if Handling.vehicle == 0 or not Handling.values or not next(Handling.values) then
        local ok, err = Handling.capture(currentVehicle)
        if not ok then
            return { ok = false, error = err }
        end
    end

    local validated, err = ValidateHandling(changes, true)
    if not validated then
        return { ok = false, error = err }
    end
    if validated.nInitialDriveGears then
        local currentGears = Handling.values.nInitialDriveGears
        if validated.nInitialDriveGears > 7 and not valueMatches(currentGears, validated.nInitialDriveGears) then
            return { ok = false, error = 'invalidRange:nInitialDriveGears' }
        end
        if Handling.original.nInitialDriveGears > 7 and not valueMatches(currentGears, validated.nInitialDriveGears) then
            return { ok = false, error = 'unsupportedField:nInitialDriveGears' }
        end
    end

    local canWrite, writeError = canMutateVehicle(Handling.vehicle)
    if not canWrite then
        return { ok = false, error = writeError }
    end
    local vehicle = Handling.vehicle

    local before = deepCopy(Handling.values)
    local nextValues = deepCopy(Handling.values)
    for fieldName, fieldValue in pairs(validated) do
        nextValues[fieldName] = deepCopy(fieldValue)
    end
    if nextValues.fSuspensionUpperLimit <= nextValues.fSuspensionLowerLimit then
        return { ok = false, error = 'invalidRange:fSuspensionUpperLimit' }
    end

    for fieldName, fieldValue in pairs(validated) do
        local fieldSpec = HandlingFields and HandlingFields[fieldName]
        if fieldSpec and not valueMatches(before[fieldName], fieldValue) then
            local okWrite, errWrite = writeFieldValue(vehicle, fieldName, fieldSpec, fieldValue)
            if not okWrite then
                rollbackChanges(vehicle, validated, before)
                return { ok = false, error = errWrite }
            end

            local readback = readFieldValue(vehicle, fieldName, fieldSpec)
            if readback == nil or not valueMatches(readback, fieldValue) then
                rollbackChanges(vehicle, validated, before)
                return { ok = false, error = 'runtimeRejected:' .. fieldName }
            end

        end
    end

    Handling.values = deepCopy(nextValues)
    Handling.generation = (Handling.generation or 1) + 1
    Handling.undoHistory[#Handling.undoHistory + 1] = {
        before = before,
        after = deepCopy(Handling.values),
        label = label or 'manual',
    }
    Handling.redoHistory = {}
    Handling.sessionBackup = deepCopy(Handling.original)
    setHistoryBounds()
    recordHistory(label or 'manual')

    return { ok = true, generation = Handling.generation, changed = nextValues }
end

function Handling.undo()
    if #Handling.undoHistory == 0 then
        return { ok = false, error = 'No undo history available' }
    end

    local snapshot = Handling.undoHistory[#Handling.undoHistory]
    local canWrite, writeError = canMutateVehicle(Handling.vehicle)
    if not canWrite then
        return { ok = false, error = writeError }
    end

    local current = deepCopy(Handling.values)
    local restoreOk, restoreErr = restoreStateSnapshot(snapshot.before)
    if not restoreOk then
        return { ok = false, error = restoreErr }
    end

    table.remove(Handling.undoHistory)
    Handling.generation = (Handling.generation or 1) + 1
    Handling.cursor = math.max(0, Handling.cursor - 1)
    Handling.redoHistory[#Handling.redoHistory + 1] = {
        values = deepCopy(current),
        label = 'redo',
    }
    setHistoryBounds()
    return { ok = true, values = deepCopy(Handling.values), generation = Handling.generation }
end

function Handling.redo()
    if #Handling.redoHistory == 0 then
        return { ok = false, error = 'No redo history available' }
    end

    local snapshot = Handling.redoHistory[#Handling.redoHistory]
    local canWrite, writeError = canMutateVehicle(Handling.vehicle)
    if not canWrite then
        return { ok = false, error = writeError }
    end

    local current = deepCopy(Handling.values)
    local restoreOk, restoreErr = restoreStateSnapshot(snapshot.values)
    if not restoreOk then
        return { ok = false, error = restoreErr }
    end

    table.remove(Handling.redoHistory)
    Handling.generation = (Handling.generation or 1) + 1
    Handling.cursor = math.min(#Handling.history, Handling.cursor + 1)
    Handling.undoHistory[#Handling.undoHistory + 1] = {
        before = current,
        after = deepCopy(Handling.values),
        label = 'redo',
    }
    setHistoryBounds()
    return { ok = true, values = deepCopy(Handling.values), generation = Handling.generation }
end

function Handling.resetField(fieldName)
    if not fieldName or not Handling.original[fieldName] then
        return { ok = false, error = 'Unknown field' }
    end

    local fieldSpec = HandlingFields and HandlingFields[fieldName]
    if not fieldSpec then
        return { ok = false, error = 'Unsupported field' }
    end

    local canWrite, writeError = canMutateVehicle(Handling.vehicle)
    if not canWrite then
        return { ok = false, error = writeError }
    end
    local vehicle = Handling.vehicle

    local before = deepCopy(Handling.values)
    local okWrite, errWrite = writeFieldValue(vehicle, fieldName, fieldSpec, Handling.original[fieldName])
    if not okWrite then
        return { ok = false, error = errWrite }
    end

    Handling.values[fieldName] = deepCopy(Handling.original[fieldName])
    Handling.generation = (Handling.generation or 1) + 1
    Handling.undoHistory[#Handling.undoHistory + 1] = {
        before = before,
        after = deepCopy(Handling.values),
        label = 'reset:' .. fieldName,
    }
    Handling.redoHistory = {}
    setHistoryBounds()
    recordHistory('reset:' .. fieldName)
    return { ok = true, values = deepCopy(Handling.values), generation = Handling.generation }
end

function Handling.resetAll()
    local canWrite, writeError = canMutateVehicle(Handling.vehicle)
    if not canWrite then
        return { ok = false, error = writeError }
    end
    local vehicle = Handling.vehicle

    local before = deepCopy(Handling.values)
    local changes = {}
    for fieldName, fieldValue in pairs(Handling.original) do
        local fieldSpec = HandlingFields and HandlingFields[fieldName]
        if fieldSpec and not valueMatches(Handling.values[fieldName], fieldValue) then
            changes[fieldName] = true
            local okWrite, errWrite = writeFieldValue(vehicle, fieldName, fieldSpec, fieldValue)
            if not okWrite then
                rollbackChanges(vehicle, changes, before)
                return { ok = false, error = errWrite }
            end
        end
    end

    Handling.values = deepCopy(Handling.original)
    Handling.undoHistory[#Handling.undoHistory + 1] = {
        before = before,
        after = deepCopy(Handling.values),
        label = 'reset:all',
    }
    Handling.redoHistory = {}
    Handling.generation = (Handling.generation or 1) + 1
    setHistoryBounds()
    recordHistory('reset:all')
    return { ok = true, values = deepCopy(Handling.values), generation = Handling.generation }
end

function Handling.restoreOriginal()
    return Handling.resetAll()
end

function Handling.restore()
    return Handling.resetAll()
end

function Handling.serialize()
    return {
        vehicle = Handling.vehicle,
        generation = Handling.generation,
        values = deepCopy(Handling.values),
        original = deepCopy(Handling.original),
        history = deepCopy(Handling.history),
        cursor = Handling.cursor,
        schema = HandlingSchema or {},
    }
end

function Handling.isSupported(fieldName)
    return HandlingFields and HandlingFields[fieldName] ~= nil
end

function Handling.getValue(fieldName)
    if not fieldName then
        return nil
    end

    return deepCopy(Handling.values[fieldName])
end

if type(HandlingFields) ~= 'table' then
    HandlingFields = {}
end
