-- Actual native sampling; no synthetic performance metrics.
Performance = { active=false, samples={}, results={}, checkpoints={}, laps={} }
local P = Performance
local previous, target, model, generation, distance, test, lap
local longG, latG = 0, 0
local function copy(v)
    if type(v) ~= 'table' then return v end
    local out={} for k,x in pairs(v) do out[k]=copy(x) end return out
end
local function finite(v) return type(v)=='number' and v==v and math.abs(v)<1e12 end
local function metres(a,b) return math.sqrt((a.x-b.x)^2+(a.y-b.y)^2+(a.z-b.z)^2) end
local function invalid(reason)
    if test and (test.status=='armed' or test.status=='running') then test.status='invalid';test.reason=reason end
    if P.lap then P.lap.invalid=true end
end
function P.reset()
    P.active=false;P.samples={};P.results={};P.laps={};P.checkpoints={};P.lap=nil
    previous=nil;target=nil;model=nil;distance=0;test=nil;lap=nil;longG=0;latG=0
end
function P.start()
    local v=Handling.vehicle
    local ok,err=Handling.validateMutationTarget(v)
    if not ok then return {ok=false,error=err} end
    if target and (target~=v or model~=GetEntityModel(v) or generation~=Handling.generation) then P.reset() end
    target=v;model=GetEntityModel(v);generation=Handling.generation;P.active=true
    return {ok=true,active=true}
end
function P.arm(kind)
    if kind~='accel100' and kind~='accel200' and kind~='brake' and kind~='drag' then return {ok=false,error='invalidValues'} end
    if kind~='brake' and GetEntitySpeed(Handling.vehicle)*3.6>0.5 then return {ok=false,error='stopFirst'} end
    local result=P.start();if not result.ok then return result end
    test={kind=kind,status='armed',values=copy(Handling.values)}
    return {ok=true}
end
function P.snapshot()
    return {generation=generation,active=P.active,sample=copy(previous),results=copy(P.results),test=copy(test),
        laps=copy(P.laps),checkpoints=copy(P.checkpoints),lap=P.lap and {current=P.lap.started and (GetGameTimer()-P.lap.started)/1000 or 0} or nil}
end
function P.run()
    return {ok=true,samples=copy(P.samples),results=copy(P.results),laps=copy(P.laps),checkpoints=copy(P.checkpoints),values=copy(Handling.values)}
end
function P.cancel() test=nil end
local function interpolate(a,b,f) return a+(b-a)*math.max(0,math.min(1,f)) end
local function testSample(s,prev)
    if not test or not prev or test.status=='invalid' or test.status=='complete' then return end
    if test.status=='armed' then
        if test.kind=='brake' then
            if prev.speed>=100 and s.speed<100 then
                local f=(prev.speed-100)/(prev.speed-s.speed)
                test.started=interpolate(prev.time,s.time,f);test.origin=interpolate(prev.distance,s.distance,f);test.status='running'
            end
        elseif prev.speed<=0.5 and s.speed>0.5 then
            test.started=prev.time;test.origin=prev.distance;test.status='running'
        end
    end
    if test.status~='running' then return end
    if s.time-test.started>180000 then invalid('timeout');return end
    local f
    if test.kind=='drag' and s.distance-test.origin>=400 then f=(test.origin+400-prev.distance)/(s.distance-prev.distance)
    elseif test.kind=='brake' and s.speed<=0.5 and prev.speed>0.5 then f=(prev.speed-0.5)/(prev.speed-s.speed)
    elseif test.kind=='accel100' or test.kind=='accel200' then
        local threshold=test.kind=='accel100' and 100 or 200
        if prev.speed<threshold and s.speed>=threshold then f=(threshold-prev.speed)/(s.speed-prev.speed) end
    end
    if f then
        P.results[test.kind]={seconds=(interpolate(prev.time,s.time,f)-test.started)/1000,
            metres=interpolate(prev.distance,s.distance,f)-test.origin,measured=true,values=copy(test.values)}
        test.status='complete'
    end
end
function P.sample()
    if not P.active then return end
    if target~=GetVehiclePedIsIn(PlayerPedId(),false) or not DoesEntityExist(target) or GetEntityModel(target)~=model
        or generation~=Handling.generation or GetPedInVehicleSeat(target,-1)~=PlayerPedId() or not NetworkHasControlOfEntity(target) then
        invalid('staleVehicle');P.active=false;return
    end
    local pos,vel,rot,forward=GetEntityCoords(target),GetEntityVelocity(target),GetEntityRotation(target,2),GetEntityForwardVector(target)
    local s={time=GetGameTimer(),speed=GetEntitySpeed(target)*3.6,x=pos.x,y=pos.y,z=pos.z,vx=vel.x,vy=vel.y,vz=vel.z,
        yaw=rot.z,roll=rot.y,pitch=rot.x,steering=GetVehicleSteeringAngle(target),rpm=GetVehicleCurrentRpm(target),
        gear=GetVehicleCurrentGear(target),engineHealth=GetVehicleEngineHealth(target),bodyHealth=GetVehicleBodyHealth(target),
        distance=distance or 0,acceleration=0,longG=0,latG=0,invalid=false}
    for _,k in ipairs({'time','speed','x','y','z','vx','vy','vz','rpm','yaw','steering','engineHealth','bodyHealth'}) do
        if not finite(s[k]) then invalid('invalidSample');previous=nil;return end
    end
    local prev=previous
    if prev then
        local dt=(s.time-prev.time)/1000
        if dt<=0 then return end
        local step=metres(s,prev)
        s.invalid=dt>0.75 or step>math.max(8,((s.speed+prev.speed)/7.2)*dt*2+3)
        if not s.invalid then
            distance=(distance or 0)+step;s.distance=distance
            s.acceleration=(s.speed-prev.speed)/3.6/dt
            local ax,ay=(vel.x-prev.vx)/dt,(vel.y-prev.vy)/dt
            local alpha=1-math.exp(-dt/0.3)
            longG=longG+alpha*((ax*forward.x+ay*forward.y)/9.80665-longG)
            latG=latG+alpha*((ax*forward.y-ay*forward.x)/9.80665-latG)
            s.longG=longG;s.latG=latG
        end
    end
    s.invalid=s.invalid or IsEntityInAir(target) or HasEntityCollidedWithAnything(target)
    if s.invalid then invalid('invalidSample');longG=0;latG=0
    else
        P.results.maxSpeed=math.max(P.results.maxSpeed or 0,s.speed)
        P.results.peakAcceleration=math.max(P.results.peakAcceleration or 0,s.acceleration)
        P.results.peakBraking=math.max(P.results.peakBraking or 0,-s.acceleration)
        testSample(s,prev)
    end
    if P.lapSample then P.lapSample(s,prev) end
    P.samples[#P.samples+1]=s
    if #P.samples>1200 then invalid('limit');P.active=false end
    if #P.samples>1200 then table.remove(P.samples) end
    previous=s
end
function P.handlingChanged() invalid('setupChanged');generation=Handling.generation;P.active=false end
function P.stop() invalid('stopped');P.active=false end
P.reset()
CreateThread(function()
    while true do
        Wait(100)
        if P.active then P.sample() end
        if IsNuiFocused() and target then SendNUIMessage({type='performance',data=P.snapshot()}) end
    end
end)
