local editorState = {
    open = false,
    pendingAuth = nil,
    requestId = 0,
    awaitingReply = false,
    authorized = false,
    restoreAuthorized = false,
    vehicle = 0,
}

local function historyPayload()
    local history={{label='original',time=0,values=Handling.original}}
    for _,entry in ipairs(Handling.history) do history[#history+1]={label=entry.label,time=entry.time or 0,values=entry.values} end
    return history
end
local function buildEditorPayload()
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    if not vehicle or vehicle == 0 then
        return { ok = false, error = 'No vehicle detected' }
    end

    local modelHash = GetEntityModel(vehicle)
    local modelName = GetDisplayNameFromVehicleModel(modelHash) or 'Unknown vehicle'
    local classId = GetVehicleClass(vehicle)

    local ok, err = Handling.capture(vehicle, true)
    if not ok then
        return { ok = false, error = err }
    end

    return {
        ok = true,
        generation = Handling.generation,
        values = Handling.values,
        original = Handling.original,
        vehicle = {
            modelHash = modelHash,
            modelName = modelName,
            class = classId,
        },
        telemetry = Telemetry and Telemetry.snapshot and Telemetry.snapshot() or nil,
        schema = HandlingSchema or {},
        flags = editorState.flags,
        history = historyPayload(), cursor = Handling.cursor+1,
    }
end

local function CloseEditorUI()
    if not editorState.open then
        return
    end

    editorState.open = false
    editorState.authorized = false
    editorState.awaitingReply = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'closeEditor' })
end

local function OpenEditorUI(data)
    if editorState.open then
        return
    end

    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if not vehicle or vehicle == 0 then
        return
    end

    editorState.open = true
    editorState.vehicle = Handling.vehicle
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'openEditor',
        payload = data or {},
        type = 'open',
        telemetry = data and data.telemetry or Telemetry and Telemetry.snapshot and Telemetry.snapshot(),
    })
end

RegisterNetEvent('luxarcia:reply')
AddEventHandler('luxarcia:reply', function(requestId, payload)
    if editorState.pendingAuth and editorState.pendingAuth.requestId == requestId then
        editorState.pendingAuth.resolve(payload)
        editorState.pendingAuth = nil
    end
end)

local function requestServerAction(action, payload)
    if editorState.pendingAuth then return {ok=false,error='busy'} end
    editorState.requestId = (editorState.requestId or 0) + 1
    local requestId = editorState.requestId
    local promise = {
        requestId = requestId,
        resolved = false,
        value = nil,
    }
    promise.resolve = function(value)
        promise.resolved = true
        promise.value = value
    end

    editorState.pendingAuth = promise
    editorState.awaitingReply = true
    TriggerServerEvent('luxarcia:request', requestId, action, payload or {})

    local started = GetGameTimer()
    while not promise.resolved and editorState.awaitingReply and GetGameTimer()-started < 25000 do
        Wait(0)
    end

    if editorState.pendingAuth == promise then
        editorState.pendingAuth = nil
    end
    editorState.awaitingReply = false
    return promise.value
end

RegisterCommand('handling', function(source, args, rawCommand)
    if source ~= 0 then
        return
    end

    if editorState.awaitingReply then
        editorState.awaitingReply = false
        editorState.pendingAuth = nil
        return
    end

    if editorState.open then
        return
    end

    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if not vehicle or vehicle == 0 then
        return
    end

    local authResult = requestServerAction('authorize', {})
    if not authResult or not authResult.ok then
        editorState.authorized = false
        TriggerEvent('chat:addMessage', {
            color = { 255, 0, 0 },
            multiline = false,
            args = { 'Luxarcia Handling Editor', authResult and authResult.error or 'Authorization failed.' }
        })
        return
    end
    editorState.authorized = true
    editorState.restoreAuthorized = true
    editorState.flags = authResult.flags
    Handling.limit = math.max(1, math.min(499, (authResult.flags and authResult.flags.historyLimit or 100)-1))

    local payload = buildEditorPayload()
    if not payload.ok then
        editorState.authorized = false
        TriggerEvent('chat:addMessage', {
            color = { 255, 0, 0 },
            multiline = false,
            args = { 'Luxarcia Handling Editor', payload.error }
        })
        return
    end

    OpenEditorUI(payload)
end, false)

local function validateEditorMutation()
    if not editorState.open or not editorState.authorized then
        return false, 'unauthorized'
    end

    local ped = PlayerPedId()
    local vehicle = ped and GetVehiclePedIsIn(ped, false) or 0
    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) or vehicle ~= editorState.vehicle then
        return false, 'staleVehicle'
    end

    if not Handling or not Handling.validateMutationTarget then
        return false, 'Invalid vehicle'
    end

    return Handling.validateMutationTarget(vehicle)
end

local function rejectNuiCallback(cb, errorCode)
    if cb then
        cb({ ok = false, error = errorCode })
    end
end

RegisterNUICallback('closeEditor', function(_, cb)
    CloseEditorUI()
    if cb then
        cb('ok')
    end
end)

RegisterNUICallback('editorReady', function(_, cb)
    if cb then
        cb('ok')
    end
end)

RegisterNUICallback('loadHandling', function(_, cb)
    local allowed, err = validateEditorMutation()
    if not allowed then
        rejectNuiCallback(cb, err)
        return
    end

    local payload = buildEditorPayload()
    if cb then
        cb(payload)
    end
end)

RegisterNUICallback('applyHandling', function(data, cb)
    local allowed, accessError = validateEditorMutation()
    if not allowed then
        rejectNuiCallback(cb, accessError)
        return
    end

    if type(data) ~= 'table' then
        rejectNuiCallback(cb, 'invalidValues')
        return
    end

    local generation = data.generation or nil
    if generation and Handling.generation and generation ~= Handling.generation then
        rejectNuiCallback(cb, 'staleGeneration')
        return
    end

    local validation = requestServerAction('validate', {values=data.values or {}})
    local stillAllowed, changedError = validateEditorMutation()
    if not validation or not validation.ok or not stillAllowed or (generation and generation~=Handling.generation) then
        rejectNuiCallback(cb, changedError or validation and validation.error or 'staleGeneration');return
    end
    local result = Handling.apply(validation.values, data.label or 'manual')
    if result.ok and Performance then Performance.handlingChanged() end
    if cb then
        result.history=historyPayload();result.cursor=Handling.cursor+1
        cb(result)
    end
end)

RegisterNUICallback('undoHandling', function(_, cb)
    local allowed, err = validateEditorMutation()
    if not allowed then
        rejectNuiCallback(cb, err)
        return
    end
    local result = Handling.undo and Handling.undo() or { ok = false, error = 'unsupported' }
    if cb then
        result.history=historyPayload();result.cursor=Handling.cursor+1
        cb(result)
    end
end)

RegisterNUICallback('redoHandling', function(_, cb)
    local allowed, err = validateEditorMutation()
    if not allowed then
        rejectNuiCallback(cb, err)
        return
    end
    local result = Handling.redo and Handling.redo() or { ok = false, error = 'unsupported' }
    if cb then
        result.history=historyPayload();result.cursor=Handling.cursor+1
        cb(result)
    end
end)

RegisterNUICallback('resetField', function(data, cb)
    local allowed, err = validateEditorMutation()
    if not allowed then
        rejectNuiCallback(cb, err)
        return
    end
    local fieldName = data and data.fieldName or data and data.name
    local result = Handling.resetField and Handling.resetField(fieldName) or { ok = false, error = 'unsupported' }
    if cb then
        result.history=historyPayload();result.cursor=Handling.cursor+1
        cb(result)
    end
end)

RegisterNUICallback('resetAll', function(_, cb)
    local allowed, err = validateEditorMutation()
    if not allowed then
        rejectNuiCallback(cb, err)
        return
    end
    local result = Handling.resetAll and Handling.resetAll() or { ok = false, error = 'unsupported' }
    if cb then
        result.history=historyPayload();result.cursor=Handling.cursor+1
        cb(result)
    end
end)

RegisterNUICallback('saveHistory', function(data, cb)
    if not editorState.open or not editorState.authorized then
        rejectNuiCallback(cb, 'unauthorized')
        return
    end
    local request = data or {}
    local response = requestServerAction('saveHistory', { history = request.history or {} })
    if cb then
        cb(response or { ok = false, error = 'saveFailed' })
    end
end)

CreateThread(function()
    while true do
        Wait(100)

        if editorState.open then
            if IsControlJustPressed(0, 322) then
                CloseEditorUI()
            end

            local ped = PlayerPedId()
            local vehicle = GetVehiclePedIsIn(ped, false)
            if not vehicle or vehicle == 0 or vehicle ~= editorState.vehicle then
                CloseEditorUI()
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        SetNuiFocus(false, false)
        editorState.open = false
        if editorState.restoreAuthorized and Handling and Handling.restore then
            Handling.restore()
        end
    end
end)

-- Single adapter for the existing advanced screens; every call is authorized.
local function toolState()
    local history=historyPayload()
    return {generation=Handling.generation,model=tostring(GetEntityModel(Handling.vehicle)),
        name=GetDisplayNameFromVehicleModel(GetEntityModel(Handling.vehicle)),class=GetVehicleClass(Handling.vehicle),
        values=Handling.values,original=Handling.original,history=history,cursor=Handling.cursor+1}
end
RegisterNUICallback('action', function(data, cb)
    if type(data)~='table' or type(data.action)~='string' then cb({ok=false,error='invalidValues'});return end
    local action=data.action
    if action=='ready' then cb({ok=true});return end
    if action=='close' or action=='uiError' then CloseEditorUI();cb({ok=true});return end
    local ok,err=validateEditorMutation()
    if not ok then cb({ok=false,error=err});return end
    if data.generation~=Handling.generation then cb({ok=false,error='staleGeneration'});return end
    local result
    if action=='load' or action=='save' or action=='recover' or action=='saveHistory' or action=='ai' then
        result=requestServerAction(action,data)
    elseif action=='apply' then
        local checked=requestServerAction('validate',{values=data.values})
        local allowed,why=validateEditorMutation()
        if not allowed or data.generation~=Handling.generation then result={ok=false,error=why or 'staleGeneration'}
        elseif checked and checked.ok then result=Handling.apply(checked.values,type(data.label)=='string' and data.label:sub(1,120) or 'manual')
        else result=checked end
    elseif action=='history' then
        if data.index==Handling.cursor then result=Handling.undo()
        elseif data.index==Handling.cursor+2 then result=Handling.redo()
        else result={ok=false,error='invalidValues'} end
    elseif action=='telemetry' then
        if type(data.enabled)~='boolean' then result={ok=false,error='invalidValues'}
        elseif data.enabled then result=Performance.start() else Performance.stop();result={ok=true,active=false} end
    elseif action=='test' then result=Performance.arm(data.kind)
    elseif action=='cancelTest' then Performance.cancel();result={ok=true}
    elseif action=='resetStats' then Performance.reset();result={ok=true}
    elseif action=='run' then result=Performance.run()
    elseif action=='lap' then result=Performance.lapCommand(data.command)
    else result={ok=false,error='unsupportedRequest'} end
    result=result or {ok=false,error='timeout'}
    if result.ok and (action=='apply' or action=='history') then
        Performance.handlingChanged();result.state=toolState()
    end
    if action=='test' or action=='lap' or action=='resetStats' or action=='telemetry' then result.telemetry=Performance.snapshot() end
    cb(result)
end)

